package com.xsfuture.xsfuture2.database;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.xsfuture.xsfuture2.bean.ConversationItemInfo;

import java.util.ArrayList;
import java.util.List;

public class ConversationListInfoDBHelper {

    private static String TableName = "ConversationListInfoTable";

    public static void create(SQLiteDatabase paramSQLiteDatabase) {
        if (paramSQLiteDatabase != null)
            paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TableName
                    + "(id INTEGER PRIMARY KEY AUTOINCREMENT, " + " my_user_id INTEGER, "
                    + "em_id VARCHAR, " + "em_conversation_last_msg VARCHAR, "
                    + "from_user_name VARCHAR , " + "from_user_phone VARCHAR , " + "from_user_avatar_url VARCHAR, "
                    + "to_user_name VARCHAR, " + "to_user_phone VARCHAR, " + "to_user_avatar_url VARCHAR)");
    }

    public static synchronized void delAll(Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        if (sqlitedatabase != null) {
            sqlitedatabase.delete(TableName, "1=1", null);
        }
        DBHelperUtil.closeDatabase();
    }

    public static synchronized List<ConversationItemInfo> getAllConversationByMyId(int myUserId, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        List<ConversationItemInfo> infos = new ArrayList<>();
        if (sqlitedatabase != null) {
            Cursor c = sqlitedatabase.rawQuery("SELECT * FROM " + TableName + " where my_user_id = ? ORDER BY id DESC", new String[]{String.valueOf(myUserId)});
            while (c.moveToNext()) {
                ConversationItemInfo info = new ConversationItemInfo();
                info.setId(c.getInt(c.getColumnIndex("id")));
                info.setMy_user_id(c.getInt(c.getColumnIndex("my_user_id")));
                info.setEm_id(c.getString(c.getColumnIndex("em_id")));
                info.setEm_conversation_last_msg(c.getString(c.getColumnIndex("em_conversation_last_msg")));
                info.setFrom_user_name(c.getString(c.getColumnIndex("from_user_name")));
                info.setFrom_user_phone(c.getString(c.getColumnIndex("from_user_phone")));
                info.setFrom_user_avatar_url(c.getString(c.getColumnIndex("from_user_avatar_url")));
                info.setTo_user_name(c.getString(c.getColumnIndex("to_user_name")));
                info.setTo_user_phone(c.getString(c.getColumnIndex("to_user_phone")));
                info.setTo_user_avatar_url(c.getString(c.getColumnIndex("to_user_avatar_url")));
                infos.add(info);
            }
            if (c != null) {
                c.close();
            }
        }
        DBHelperUtil.closeDatabase();
        return infos;
    }

    public static synchronized ConversationItemInfo getConversationByEmId(String emId, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        ConversationItemInfo info = null;
        if (sqlitedatabase != null) {
            Cursor c = sqlitedatabase.rawQuery("SELECT * FROM " + TableName + " where em_id = ? ORDER BY id DESC", new String[]{emId});
            while (c.moveToNext()) {
                info = new ConversationItemInfo();
                info.setId(c.getInt(c.getColumnIndex("id")));
                info.setMy_user_id(c.getInt(c.getColumnIndex("my_user_id")));
                info.setEm_id(c.getString(c.getColumnIndex("em_id")));
                info.setEm_conversation_last_msg(c.getString(c.getColumnIndex("em_conversation_last_msg")));
                info.setFrom_user_name(c.getString(c.getColumnIndex("from_user_name")));
                info.setFrom_user_phone(c.getString(c.getColumnIndex("from_user_phone")));
                info.setFrom_user_avatar_url(c.getString(c.getColumnIndex("from_user_avatar_url")));
                info.setTo_user_name(c.getString(c.getColumnIndex("to_user_name")));
                info.setTo_user_phone(c.getString(c.getColumnIndex("to_user_phone")));
                info.setTo_user_avatar_url(c.getString(c.getColumnIndex("to_user_avatar_url")));
                break;
            }
            if (c != null) {
                c.close();
            }
        }
        DBHelperUtil.closeDatabase();
        return info;
    }

    public static synchronized void insertConversation(ConversationItemInfo info, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        if (sqlitedatabase != null) {
            sqlitedatabase.execSQL("INSERT INTO " + TableName + " VALUES(null,?,?,?,?,?,?,?,?,?)", new Object[]{
                    info.getMy_user_id(), info.getEm_id(), info.getEm_conversation_last_msg(), info.getFrom_user_name(), info.getFrom_user_phone(), info.getFrom_user_avatar_url()
                    , info.getTo_user_name(), info.getTo_user_phone(), info.getTo_user_avatar_url()});
        }
        DBHelperUtil.closeDatabase();
    }

    public static synchronized void deleteConversationById(int em_id, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        if (sqlitedatabase != null) {
            sqlitedatabase.execSQL("DELETE FROM " + TableName + " WHERE em_id = ? ", new Object[]{em_id});
        }
        DBHelperUtil.closeDatabase();
    }

    public static synchronized void updateConversationById(ConversationItemInfo info, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        if (sqlitedatabase != null) {
            ContentValues cv = new ContentValues();
            cv.put("my_user_id", info.getMy_user_id());
            cv.put("em_id", info.getEm_id());
            cv.put("em_conversation_last_msg", info.getEm_conversation_last_msg());
            cv.put("from_user_name", info.getFrom_user_name());
            cv.put("from_user_phone", info.getFrom_user_phone());
            cv.put("from_user_avatar_url", info.getFrom_user_avatar_url());
            cv.put("to_user_name", info.getTo_user_name());
            cv.put("to_user_phone", info.getTo_user_phone());
            cv.put("to_user_avatar_url", info.getTo_user_avatar_url());
            sqlitedatabase.update(TableName, cv, "em_id=? ", new String[]{String.valueOf(info.getEm_id())});
        }
        DBHelperUtil.closeDatabase();
    }

    public static void upgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 3) {
            db.execSQL("drop table if exists " + TableName);
            create(db);
        }
    }
}
