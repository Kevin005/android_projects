package com.xsfuture.xsfuture2.view;


import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.TextView;

import com.xsfuture.xsfuture2.R;

public class LoadingProgressDialog extends Dialog {
	private static LoadingProgressDialog loadingProgressDialog = null;

	public LoadingProgressDialog(Context context) {
		super(context);
	}

	public LoadingProgressDialog(Context context, int theme) {
		super(context, theme);
	}

	public static LoadingProgressDialog createDialog(Context context) {
		loadingProgressDialog = new LoadingProgressDialog(context, R.style.LoadingProgressDialog);
		loadingProgressDialog.setContentView(R.layout.view_loading_progress_dialog);
		loadingProgressDialog.getWindow().getAttributes().gravity = Gravity.CENTER;

		return loadingProgressDialog;
	}

	public void onWindowFocusChanged(boolean hasFocus) {

		if (loadingProgressDialog == null) {
			return;
		}

		ImageView imageView = (ImageView) loadingProgressDialog.findViewById(R.id.loading_img);
		AnimationDrawable animationDrawable = (AnimationDrawable) imageView.getBackground();
		animationDrawable.start();
	}

	/**
	 *
	 * [Summary] setTitile 标题
	 *
	 * @param strTitle
	 * @return
	 *
	 */
	public LoadingProgressDialog setTitile(String strTitle) {
		return loadingProgressDialog;
	}

	/**
	 *
	 * [Summary] setMessage 提示内容
	 *
	 * @param strMessage
	 * @return
	 *
	 */
	public LoadingProgressDialog setMessage(String strMessage) {
		TextView tvMsg = (TextView) loadingProgressDialog.findViewById(R.id.loading_msg);

		if (tvMsg != null) {
			tvMsg.setText(strMessage);
		}

		return loadingProgressDialog;
	}

	@Override
	public void dismiss() {
		if (getContext() != null) {
			super.dismiss();
		}
	}
}
