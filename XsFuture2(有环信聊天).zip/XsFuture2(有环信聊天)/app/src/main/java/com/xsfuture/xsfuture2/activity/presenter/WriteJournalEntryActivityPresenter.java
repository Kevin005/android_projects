package com.xsfuture.xsfuture2.activity.presenter;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;

import com.baidu.speech.VoiceRecognitionService;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.config.BaiduASRConstant;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by Kevin on 2017/4/24.
 */

public class WriteJournalEntryActivityPresenter {
    private SpeechRecognizer speechRecognizer;
    private Context context;

    public WriteJournalEntryActivityPresenter(Context context) {
        this.context = context;
    }

    //初始化及回调
    public void initASR(RecognitionListener recognitionListener) {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context, new ComponentName(context, VoiceRecognitionService.class));
        speechRecognizer.setRecognitionListener(recognitionListener);
    }

    //开始录音
    public void startRecord() {
        speechRecognizer.cancel();
        Intent intent = new Intent();
        bindParams(intent);
        intent.putExtra("vad", "input");
        speechRecognizer.startListening(intent);
    }

    //停止录音
    public void stopRecord() {
        speechRecognizer.stopListening();
    }

    //销毁录音实例，释放资源
    public void destoryRecord() {
        speechRecognizer.destroy();
    }

    private void bindParams(Intent intent) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        if (sp.getBoolean("tips_sound", true)) {
            intent.putExtra(BaiduASRConstant.EXTRA_SOUND_START, R.raw.bdspeech_recognition_start);
            intent.putExtra(BaiduASRConstant.EXTRA_SOUND_END, R.raw.bdspeech_speech_end);
            intent.putExtra(BaiduASRConstant.EXTRA_SOUND_SUCCESS, R.raw.bdspeech_recognition_success);
            intent.putExtra(BaiduASRConstant.EXTRA_SOUND_ERROR, R.raw.bdspeech_recognition_error);
            intent.putExtra(BaiduASRConstant.EXTRA_SOUND_CANCEL, R.raw.bdspeech_recognition_cancel);
        }
        if (sp.contains(BaiduASRConstant.EXTRA_INFILE)) {
            String tmp = sp.getString(BaiduASRConstant.EXTRA_INFILE, "").replaceAll(",.*", "").trim();
            intent.putExtra(BaiduASRConstant.EXTRA_INFILE, tmp);
        }
        if (sp.getBoolean(BaiduASRConstant.EXTRA_OUTFILE, false)) {
            intent.putExtra(BaiduASRConstant.EXTRA_OUTFILE, "sdcard/outfile.pcm");
        }
        if (sp.contains(BaiduASRConstant.EXTRA_SAMPLE)) {
            String tmp = sp.getString(BaiduASRConstant.EXTRA_SAMPLE, "").replaceAll(",.*", "").trim();
            if (null != tmp && !"".equals(tmp)) {
                intent.putExtra(BaiduASRConstant.EXTRA_SAMPLE, Integer.parseInt(tmp));
            }
        }
        if (sp.contains(BaiduASRConstant.EXTRA_LANGUAGE)) {
            String tmp = sp.getString(BaiduASRConstant.EXTRA_LANGUAGE, "").replaceAll(",.*", "").trim();
            if (null != tmp && !"".equals(tmp)) {
                intent.putExtra(BaiduASRConstant.EXTRA_LANGUAGE, tmp);
            }
        }
        if (sp.contains(BaiduASRConstant.EXTRA_NLU)) {
            String tmp = sp.getString(BaiduASRConstant.EXTRA_NLU, "").replaceAll(",.*", "").trim();
            if (null != tmp && !"".equals(tmp)) {
                intent.putExtra(BaiduASRConstant.EXTRA_NLU, tmp);
            }
        }

        if (sp.contains(BaiduASRConstant.EXTRA_VAD)) {
            String tmp = sp.getString(BaiduASRConstant.EXTRA_VAD, "").replaceAll(",.*", "").trim();
            if (null != tmp && !"".equals(tmp)) {
                intent.putExtra(BaiduASRConstant.EXTRA_VAD, tmp);
            }
        }
        String prop = null;
        if (sp.contains(BaiduASRConstant.EXTRA_PROP)) {
            String tmp = sp.getString(BaiduASRConstant.EXTRA_PROP, "").replaceAll(",.*", "").trim();
            if (null != tmp && !"".equals(tmp)) {
                intent.putExtra(BaiduASRConstant.EXTRA_PROP, Integer.parseInt(tmp));
                prop = tmp;
            }
        }
        // offline asr
        {
            intent.putExtra(BaiduASRConstant.EXTRA_OFFLINE_ASR_BASE_FILE_PATH, "/sdcard/easr/s_1");
            intent.putExtra(BaiduASRConstant.EXTRA_LICENSE_FILE_PATH, "/sdcard/easr/license-tmp-20150530.txt");
            if (null != prop) {
                int propInt = Integer.parseInt(prop);
                if (propInt == 10060) {
                    intent.putExtra(BaiduASRConstant.EXTRA_OFFLINE_LM_RES_FILE_PATH, "/sdcard/easr/s_2_Navi");
                } else if (propInt == 20000) {
                    intent.putExtra(BaiduASRConstant.EXTRA_OFFLINE_LM_RES_FILE_PATH, "/sdcard/easr/s_2_InputMethod");
                }
            }
            intent.putExtra(BaiduASRConstant.EXTRA_OFFLINE_SLOT_DATA, buildTestSlotData());
        }
    }

    private String buildTestSlotData() {
        JSONObject slotData = new JSONObject();
        JSONArray name = new JSONArray().put("李涌泉").put("郭下纶");
        JSONArray song = new JSONArray().put("七里香").put("发如雪");
        JSONArray artist = new JSONArray().put("周杰伦").put("李世龙");
        JSONArray app = new JSONArray().put("手机百度").put("百度地图");
        JSONArray usercommand = new JSONArray().put("关灯").put("开门");
        return slotData.toString();
    }

}
