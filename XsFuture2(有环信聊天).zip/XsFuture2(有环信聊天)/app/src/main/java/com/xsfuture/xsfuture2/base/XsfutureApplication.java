package com.xsfuture.xsfuture2.base;

import android.app.Activity;
import android.app.Application;
import android.os.Build;
import android.os.Environment;

import com.xsfuture.xsfuture2.activity.presenter.EMPresenter;
import com.xsfuture.xsfuture2.util.CrashHandlerUtils;
import com.xsfuture.xsfuture2.util.FileService;

import java.io.File;

public class XsfutureApplication extends Application {

    private ActivityHandlerInterface ahi;
    private static XsfutureApplication instance;

    @Override
    public void onCreate() {
        super.onCreate();
        final int sdkVersion = Build.VERSION.SDK_INT;
        if (sdkVersion <= Build.VERSION_CODES.GINGERBREAD_MR1) {
            try {
                Class.forName("android.os.AsyncTask");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        instance = this;
        CrashHandlerUtils.getInstance().init(this);//初始化接管crash初始化
        EMPresenter.init(this);//初始化环信
        startFolderSizeHolder();//清理SD卡缓存大小
    }

    private void startFolderSizeHolder() {
        new Thread() {
            @Override
            public void run() {
                try {
                    folderSizeHolder();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void folderSizeHolder() throws Exception {
        String default_local_url = Environment.getExternalStorageDirectory() + "/xsfuture/image/default/";
        File defaultFile = new File(default_local_url);
        if (defaultFile != null && defaultFile.length() > 0) {
            long defaultSize = FileService.getFolderSize(defaultFile);
            //30kb = 30720b
            if (defaultSize > 0) {
                if (defaultSize > 30720 || defaultFile.listFiles().length > 30) {
                    FileService.deleteFolderFile(default_local_url, true);
                }
            }
        }

        String crop_local_url = Environment.getExternalStorageDirectory() + "/xsfuture/image/crop/";
        File cropFile = new File(crop_local_url);
        if (cropFile != null && cropFile.length() > 0) {
            long cropSize = FileService.getFolderSize(cropFile);
            if (cropSize > 0) {
                //10mb = 10485760b
                if (cropSize > 10485760 || cropFile.listFiles().length > 30) {
                    FileService.deleteFolderFile(crop_local_url, true);
                }
            }
        }
    }

    public ActivityHandlerInterface getAhi() {
        return ahi;
    }

    public void setAhi(ActivityHandlerInterface ahi) {
        this.ahi = ahi;
    }

    public static XsfutureApplication getInstance() {
        return instance;
    }

    public static void setInstance(XsfutureApplication instance) {
        XsfutureApplication.instance = instance;
    }

    public Activity getCurrentActivity() {
        if (ahi != null) {
            return ahi.getCurrentActivity();
        } else {
            return null;
        }
    }

}
