package com.xsfuture.xsfuture2.bean;

import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.util.StringUtils;

public class ReaderResponseMessageInfo {
    private int msg_type;
    private int comment_total;
    private String user_name;
    private int readed_page_number;
    private String content;//rr content
    private String comment_content;
    private String nick_name;
    private int reader_response_id;
    private int favor_total;
    private String time_stamp;
    private boolean favored_flg;
    private String book_name;
    private int user_id;
    private int readed_days;
    private String user_image;

    public String getUser_image() {
        if (!StringUtils.isEmpty(user_image) && user_image.contains("http://115.28.56.168")) {
            return user_image;
        }
        return ConstHttpProp.img_base_url + user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getComment_content() {
        return comment_content;
    }

    public void setComment_content(String comment_content) {
        this.comment_content = comment_content;
    }

    public int getMsg_type() {
        return msg_type;
    }

    public void setMsg_type(int msg_type) {
        this.msg_type = msg_type;
    }

    public int getComment_total() {
        return comment_total;
    }

    public void setComment_total(int comment_total) {
        this.comment_total = comment_total;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public int getReaded_page_number() {
        return readed_page_number;
    }

    public void setReaded_page_number(int readed_page_number) {
        this.readed_page_number = readed_page_number;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getNick_name() {
        return nick_name;
    }

    public void setNick_name(String nick_name) {
        this.nick_name = nick_name;
    }

    public int getReader_response_id() {
        return reader_response_id;
    }

    public void setReader_response_id(int reader_response_id) {
        this.reader_response_id = reader_response_id;
    }

    public int getFavor_total() {
        return favor_total;
    }

    public void setFavor_total(int favor_total) {
        this.favor_total = favor_total;
    }

    public String getTime_stamp() {
        return time_stamp;
    }

    public void setTime_stamp(String time_stamp) {
        this.time_stamp = time_stamp;
    }

    public boolean isFavored_flg() {
        return favored_flg;
    }

    public void setFavored_flg(boolean favored_flg) {
        this.favored_flg = favored_flg;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getReaded_days() {
        return readed_days;
    }

    public void setReaded_days(int readed_days) {
        this.readed_days = readed_days;
    }


}
