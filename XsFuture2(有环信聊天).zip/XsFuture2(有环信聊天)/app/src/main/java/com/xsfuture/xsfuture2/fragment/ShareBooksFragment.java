package com.xsfuture.xsfuture2.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.base.FrameMainActivity;
import com.xsfuture.xsfuture2.activity.community_module.ShareBookDetailActivity;
import com.xsfuture.xsfuture2.adapter.ShareBookListAdapter;
import com.xsfuture.xsfuture2.bean.BookShareItemInfo;
import com.xsfuture.xsfuture2.view.xlistview.XListView;

import java.util.ArrayList;
import java.util.List;

public class ShareBooksFragment extends BaseFragment implements XListView.IXListViewListener {
    private XListView readed_books_list;
    private ShareBookListAdapter adapter;

    private final int offset = 0;
    private int limit = 1000;

    @Override
    protected View setCurrentContentView(LayoutInflater inflater, ViewGroup container) {
        View view = inflater.inflate(R.layout.fragment_share_books, container, false);
        setCurrentActivity((FrameMainActivity) getActivity());
        return view;
    }

    @Override
    protected void init(View view, Bundle savedInstanceState) {
        initView(view);
    }

    private void initView(View view) {
        readed_books_list = (XListView) view.findViewById(R.id.readed_books_list);
        readed_books_list.setOnItemClickListener(new XListView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getCurrentActivity(), ShareBookDetailActivity.class);
                intent.putExtra("sell_user_name", adapter.getItem(position).getSell_user_name());
                intent.putExtra("sell_user_phone_num", adapter.getItem(position).getSell_user_phone_num());
                startActivity(intent);
            }
        });
        readed_books_list.setPullLoadEnable(false);
        readed_books_list.setPullRefreshEnable(false);
        readed_books_list.setXListViewListener(this);
        adapter = new ShareBookListAdapter(getCurrentActivity());
        readed_books_list.setAdapter(adapter);
        addData();
    }

    private void addData() {
        List<BookShareItemInfo> infos = new ArrayList<>();
        BookShareItemInfo info = new BookShareItemInfo();
        info.setSell_user_phone_num("18717825632");
        info.setSell_user_name("kevin");
        infos.add(info);
        BookShareItemInfo info1 = new BookShareItemInfo();
        info1.setSell_user_phone_num("13816145039");
        info1.setSell_user_name("allen");
        infos.add(info1);

        adapter.setData(infos);
    }

    @Override
    public void onRefresh() {

    }

    @Override
    public void onLoadMore() {

    }

    @Override
    public void onXListViewStop() {
        readed_books_list.stopRefresh();
        readed_books_list.stopLoadMore();
    }
}
