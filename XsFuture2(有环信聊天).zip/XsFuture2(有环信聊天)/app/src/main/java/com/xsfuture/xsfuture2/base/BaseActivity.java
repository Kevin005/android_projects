package com.xsfuture.xsfuture2.base;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.http.HttpState;
import com.xsfuture.xsfuture2.util.DPIUtils;
import com.xsfuture.xsfuture2.util.Log;
import com.xsfuture.xsfuture2.util.PrefUtils;

import java.util.concurrent.ConcurrentHashMap;

public abstract class BaseActivity extends Activity implements ActivityHandlerInterface {
    public static final ConcurrentHashMap<Activity, HttpState> stateMap = new ConcurrentHashMap<Activity, HttpState>();
    private Handler handler;
    protected Button left_btn;
    protected Button right_btn;
    private TextView title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        XsfutureApplication.getInstance().setAhi(BaseActivity.this);
        if (DPIUtils.getDensity() == 0) {
            DPIUtils.setDensity(getResources().getDisplayMetrics().density);
        }
        if (DPIUtils.getDisplay() == null) {
            DPIUtils.setDefaultDisplay(getWindowManager().getDefaultDisplay());
        }

        handler = new Handler(getMainLooper());
        setCurrentContentView();
        initTitleBar();
        init(savedInstanceState);
        Log.d("ActivityName", getCurrentActivity().getLocalClassName());
    }

    @Override
    protected void onResume() {
        super.onResume();
        XsfutureApplication.getInstance().setAhi(BaseActivity.this);
    }

    public void post(Runnable action) {
        final Runnable ar = action;

        handler.post(new Runnable() {

            @Override
            public void run() {
                if (!isFinishing())
                    ar.run();
            }
        });
    }

    public void postDelayed(final Runnable action, int i) {
        long l = i;
        final Runnable ar = action;
        handler.postDelayed(new Runnable() {

            @Override
            public void run() {
                if (!isFinishing())
                    ar.run();
            }

        }, l);
    }

    @Override
    public Handler getHandler() {
        return handler;
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    @Override
    public BaseActivity getCurrentActivity() {
        return this;
    }

    @Override
    public HttpState getHttpState() {
        return stateMap.get(this);
    }

    @Override
    public void AddHttpState(HttpState state) {
        stateMap.put(this, state);
    }

    @Override
    public void RemoveHttpState() {
        stateMap.remove(this);
    }

    private void initTitleBar() {
        title = (TextView) findViewById(R.id.title_text);
        left_btn = (Button) findViewById(R.id.left_btn);
        right_btn = (Button) findViewById(R.id.right_btn);
    }

    /**
     * 设置左键文字与事件
     *
     * @param listener
     */
    public void setTitleLeftBtn(int stringId, View.OnClickListener listener) {
        // 先将该按钮设为可见
        left_btn.setVisibility(View.VISIBLE);

        if (stringId == R.string.back) {
            left_btn.setCompoundDrawables(getBtnCompoundDrawable(R.drawable.arrow_back), null, null, null);
        }
        // 设置按钮字符
        // left_btn.setText(stringId);
        // 设置点击事件
        left_btn.setOnClickListener(listener);
    }

    /**
     * 设置右键文字与事件
     *
     * @param stringId
     * @param listener
     */
    public void setTitleBtnRight(int stringId, int drawableId, View.OnClickListener listener) {
        // 先将该按钮设为可见
        right_btn.setVisibility(View.VISIBLE);
        if (drawableId == 0 && stringId != 0) {
            // 设置按钮字符
            right_btn.setText(stringId);
        } else {
            right_btn.setCompoundDrawables(getBtnCompoundDrawable(drawableId), null, null, null);
        }
        // 设置点击事件
        right_btn.setOnClickListener(listener);
    }

    public void setTitleTextClick(View.OnClickListener listener) {
        title.setOnClickListener(listener);
    }

    public void setTitleBtnRightVisibility(int visibility) {
        right_btn.setVisibility(visibility);
    }

    /**
     * 设置标题文字
     *
     * @param s
     */
    public void setTitleText(String s) {
        title.setText(s);
    }

    public void setTitleText(int id) {
        title.setText(id);
    }

    /**
     * 获取按钮的CompoundDrawable，以设置按钮图片
     *
     * @param id
     * @return
     */
    private Drawable getBtnCompoundDrawable(int id) {

        Drawable icon = getResources().getDrawable(id);
        icon.setBounds(0, 0, icon.getMinimumWidth(), icon.getMinimumHeight());

        return icon;
    }

    protected abstract void setCurrentContentView();

    protected abstract void init(Bundle savedInstanceState);

    public int getUser_id() {
        return PrefUtils.getUserId(this);
    }

    public String getUser_token() {
        return PrefUtils.getUserToken(this);
    }

    public void showShortToast(String str) {
        if (!TextUtils.isEmpty(str)) {
            Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
        }
    }

    public void showShortToast(int textId) {
        try {
            Toast.makeText(this, textId, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
        }
    }

    //手指上下滑动时的最小速度
    private static final int YSPEED_MIN = 1000;

    //手指向右滑动时的最小距离
    private static final int XDISTANCE_MIN = 50;

    //手指向上滑或下滑时的最小距离
    private static final int YDISTANCE_MIN = 100;

    //记录手指按下时的横坐标。
    private float xDown;

    //记录手指按下时的纵坐标。
    private float yDown;

    //记录手指移动时的横坐标。
    private float xMove;

    //记录手指移动时的纵坐标。
    private float yMove;

    //用于计算手指滑动的速度。
    private VelocityTracker mVelocityTracker;

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        createVelocityTracker(event);
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                xDown = event.getRawX();
                yDown = event.getRawY();
                break;
            case MotionEvent.ACTION_MOVE:
                xMove = event.getRawX();
                yMove = event.getRawY();
                //滑动的距离
                int distanceX = (int) (xMove - xDown);
                int distanceY = (int) (yMove - yDown);
                //获取顺时速度
                int ySpeed = getScrollVelocity();
                //关闭Activity需满足以下条件：
                //1.x轴滑动的距离>XDISTANCE_MIN
                //2.y轴滑动的距离在YDISTANCE_MIN范围内
                //3.y轴上（即上下滑动的速度）<XSPEED_MIN，如果大于，则认为用户意图是在上下滑动而非左滑结束Activity
                if (distanceX > XDISTANCE_MIN && (distanceY < YDISTANCE_MIN && distanceY > -YDISTANCE_MIN) && ySpeed < YSPEED_MIN) {
                    if (setGesturesTracker()) {
                        finish();
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                recycleVelocityTracker();
                break;
            default:
                break;
        }
        return super.dispatchTouchEvent(event);
    }

    /**
     * 创建VelocityTracker对象，并将触摸界面的滑动事件加入到VelocityTracker当中。
     *
     * @param event
     */
    private void createVelocityTracker(MotionEvent event) {
        if (mVelocityTracker == null) {
            mVelocityTracker = VelocityTracker.obtain();
        }
        mVelocityTracker.addMovement(event);
    }

    /**
     * 回收VelocityTracker对象。
     */
    private void recycleVelocityTracker() {
        mVelocityTracker.recycle();
        mVelocityTracker = null;
    }

    /**
     * @return 滑动速度，以每秒钟移动了多少像素值为单位。
     */
    private int getScrollVelocity() {
        mVelocityTracker.computeCurrentVelocity(2000);
        int velocity = (int) mVelocityTracker.getYVelocity();
        return Math.abs(velocity);
    }

    protected boolean setGesturesTracker() {
        return true;
    }

}
