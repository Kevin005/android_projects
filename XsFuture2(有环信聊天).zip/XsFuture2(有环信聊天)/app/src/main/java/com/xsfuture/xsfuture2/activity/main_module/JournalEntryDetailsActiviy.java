package com.xsfuture.xsfuture2.activity.main_module;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.JournalEntryDetailsAdapter;
import com.xsfuture.xsfuture2.bean.CommentsItemInfo;
import com.xsfuture.xsfuture2.bean.EventBusInfo;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.database.UserInfoDBHelper;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.activity.presenter.eventbus_module.CommandId;
import com.xsfuture.xsfuture2.util.DateUtils;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.view.CircularImage;
import com.xsfuture.xsfuture2.view.RichtextLinearlayout;
import com.xsfuture.xsfuture2.view.xlistview.XListView;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

public class JournalEntryDetailsActiviy extends BaseActivity implements XListView.IXListViewListener {
    private XListView xlistview_detail;
    private LinearLayout llyt_person_detail;
    private LinearLayout all_reading_detail;
    private TextView view_book_name;
    private TextView view_progress;
    private TextView view_reading_days;
    private TextView view_readerresponse_progress_detail;
    private TextView tv_punch_time;
    private TextView view_readerresponse_content_detail;
    private RichtextLinearlayout myline_reader_reponse;
    private TextView view_user_name;
    private TextView tv_athor;
    private TextView tv_favor_total;
    private TextView tv_comment_total;
    private CheckBox checkbox_is_on;
    private LinearLayout line_comment;
    private LinearLayout line_favor;
    private ImageView img_favor;
    private CircularImage icon_patient;
    private ImageView img_book;
    private JournalEntryDetailsAdapter adatper;
    // 人物信息
    private String nick_name;
    private String user_name;
    private boolean is_on;
    private int user_id;
    private String user_image;
    // 书籍信息
    private int post_id;
    private String book_name;
    private int reading_days;
    private String book_image;
    private double progress;
    private String author;
    // 读后感信息
    private int timestamp;
    private int readed_pagenumber;
    private String content;
    private int favor_tatal;
    private int comment_total;
    private int reader_response_id;
    private boolean is_favored;
    private String class_name_flag;
    //listivew
    private int current_page = 0;
    private int page_size = 50;
    private final int COMMENTBACK_RESULT_FLAG = 1;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_journal_entry_detail);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        initData();
        setTitleText("《" + book_name + "》");
        setTitleLeftBtn(R.string.back, new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initView();
    }

    private void initData() {
        // 用户信息
        nick_name = getIntent().getStringExtra("nick_name");
        user_name = getIntent().getStringExtra("user_name");
        is_on = getIntent().getBooleanExtra("is_on", false);
        user_id = getIntent().getIntExtra("user_id", 0);
        // 书籍信息
        post_id = getIntent().getIntExtra("post_id", 0);
        book_name = getIntent().getStringExtra("book_name");
        reading_days = getIntent().getIntExtra("reading_days", 0);
        author = getIntent().getStringExtra("author");
        // 读后感信息
        timestamp = getIntent().getIntExtra("timestamp", 0);
        readed_pagenumber = getIntent().getIntExtra("readed_pagenumber", 0);
        content = getIntent().getStringExtra("content");
        user_image = getIntent().getStringExtra("user_image");
        book_image = getIntent().getStringExtra("book_image");
        progress = getIntent().getDoubleExtra("progress", 0);
        favor_tatal = getIntent().getIntExtra("favor_tatal", 0);
        comment_total = getIntent().getIntExtra("comment_total", 0);
        reader_response_id = getIntent().getIntExtra("reader_response_id", 0);
        is_favored = getIntent().getBooleanExtra("is_favored", false);
        class_name_flag = getIntent().getStringExtra("class_name_flag");
    }

    private void initView() {
        all_reading_detail = (LinearLayout) findViewById(R.id.all_current_focus_on_reading_detail);
        all_reading_detail.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), AllJournalEntryActivity.class);
                // 书籍信息
                intent.putExtra("post_id", post_id);
                intent.putExtra("book_name", book_name);
                startActivity(intent);
            }
        });
        xlistview_detail = (XListView) findViewById(R.id.xlistview_detail);
        xlistview_detail.setPullRefreshEnable(false);
        xlistview_detail.setPullLoadEnable(false);
        xlistview_detail.setXListViewListener(this);
        View headerView = addListViewHeader();
        xlistview_detail.addHeaderView(headerView);
        adatper = new JournalEntryDetailsAdapter(getCurrentActivity());
        xlistview_detail.setAdapter(adatper);
        getComments();
    }

    private View addListViewHeader() {
        View headView = LayoutInflater.from(this).inflate(R.layout.headerview_journal_entry_detail, null);
        view_user_name = (TextView) headView.findViewById(R.id.view_user_name);
        checkbox_is_on = (CheckBox) headView.findViewById(R.id.checkbox_is_on);
        checkbox_is_on.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                focuson();
            }
        });
        llyt_person_detail = (LinearLayout) headView.findViewById(R.id.llyt_line_personal_details);
        llyt_person_detail.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), PersonalDetailsActivity.class);
                intent.putExtra("nick_name", nick_name);
                intent.putExtra("user_id", user_id);
                intent.putExtra("user_name", user_name);
                intent.putExtra("user_image", user_image);
                intent.putExtra("book_image", book_image);
                startActivity(intent);
            }
        });
        view_book_name = (TextView) headView.findViewById(R.id.book_name);
        view_progress = (TextView) headView.findViewById(R.id.progress);
        view_reading_days = (TextView) headView.findViewById(R.id.reading_days);
        view_readerresponse_progress_detail = (TextView) headView.findViewById(R.id.readerresponse_progress_detail);
        tv_punch_time = (TextView) headView.findViewById(R.id.tv_punch_time);
        view_readerresponse_content_detail = (TextView) headView.findViewById(R.id.readerresponse_content_detail);
        myline_reader_reponse = (RichtextLinearlayout) headView.findViewById(R.id.myline_reader_reponse);
        icon_patient = (CircularImage) headView.findViewById(R.id.icon_patient);
        icon_patient.setImageResource(R.drawable.avatar);
        img_book = (ImageView) headView.findViewById(R.id.img_book);
        tv_athor = (TextView) headView.findViewById(R.id.tv_athor);
        tv_favor_total = (TextView) headView.findViewById(R.id.tv_favor_total);
        tv_comment_total = (TextView) headView.findViewById(R.id.tv_comment_total);
        line_comment = (LinearLayout) headView.findViewById(R.id.line_comment);
        line_comment.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), CommentBackActivity.class);
                intent.putExtra("reader_response_id", reader_response_id);
                intent.putExtra("remind_sb", "");
                startActivityForResult(intent, COMMENTBACK_RESULT_FLAG);
            }
        });
        img_favor = (ImageView) headView.findViewById(R.id.img_favor);
        line_favor = (LinearLayout) headView.findViewById(R.id.line_favor);
        line_favor.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                favorOn();
            }
        });
        initHeaderViewData();
        return headView;
    }

    private void setFavorImage() {
        if (img_favor != null) {
            if (is_favored) {
                img_favor.setImageResource(R.drawable.favored);
                tv_favor_total.setTextColor(getResources().getColor(R.color.main_color));
            } else {
                img_favor.setImageResource(R.drawable.favor);
                tv_favor_total.setTextColor(getResources().getColor(R.color.item_text_color));
            }
        }
    }

    private void initHeaderViewData() {
        setFavorImage();
        if (is_on == false) {
            checkbox_is_on.setSelected(false);
            checkbox_is_on.setText("关注");
        } else {
            checkbox_is_on.setSelected(true);
            checkbox_is_on.setText("已关注");
        }
        view_user_name.setText(nick_name);
        view_book_name.setText("《" + book_name + "》");
        NumberFormat fmt = NumberFormat.getPercentInstance();
        fmt.setMaximumFractionDigits(2);
        String progressStr = fmt.format(progress);
        view_progress.setText("已读" + progressStr);
        view_reading_days.setText("第" + reading_days + "天");
        view_readerresponse_progress_detail.setText(DateUtils.TimeStamp2Date(String.valueOf(timestamp)));
        tv_punch_time.setText(readed_pagenumber + "页");
        view_readerresponse_content_detail.setText(content);
        myline_reader_reponse.removeAllViews();
        myline_reader_reponse.actionAddView(content);
        tv_athor.setText(author);
        tv_favor_total.setText(String.valueOf(favor_tatal));
        tv_comment_total.setText(String.valueOf(comment_total));
        Glide.with(getCurrentActivity())
                .load(user_image)
                .placeholder(R.drawable.avatar)
                .error(R.drawable.avatar)
                .skipMemoryCache(true)//跳过内存缓存
                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                .into(icon_patient);

        Glide.with(getCurrentActivity())
                .load(book_image)
                .placeholder(R.drawable.book_def)
                .error(R.drawable.book_def)
                .skipMemoryCache(true)//跳过内存缓存
                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                .into(img_book);
    }

    private synchronized void getComments() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("reader_response_id", reader_response_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                onXListViewStop();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        JSONArrayPoxy array = jSONObjectProxy.getJSONArrayOrNull("data");
                        if (array != null) {
                            Gson gson = new Gson();
                            List<CommentsItemInfo> datas = gson.fromJson(array.toString(),
                                    new TypeToken<List<CommentsItemInfo>>() {
                                    }.getType());
                            if (datas != null && datas.size() > 0 && current_page > 0) {
                                if (datas.size() < page_size) {
                                    xlistview_detail.setPullLoadEnable(false);
                                } else {
                                    xlistview_detail.setPullLoadEnable(true);
                                }
                                adatper.addData(datas);
                                current_page++;
                            } else if (datas != null && datas.size() > 0 && current_page == 0) {
                                if (datas.size() < page_size) {
                                    xlistview_detail.setPullLoadEnable(false);
                                } else {
                                    xlistview_detail.setPullLoadEnable(true);
                                }
                                adatper.setData(datas);
                                current_page++;
                            } else if (datas != null && datas.size() <= 0) {
                                xlistview_detail.setPullLoadEnable(false);
                            }
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_comment_get_comment_list + "?offset=" + current_page + "&limit="
                + page_size + "&order=desc");
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    private void focuson() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("friends_id", user_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONObjectProxy data = jSONObjectProxy.getJSONObjectOrNull("data");
                    if (success == 0) {
                        is_refresh = true;
                        if (is_on == false) {
                            is_on = true;
                        } else {
                            is_on = false;
                        }
                        initHeaderViewData();
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        if (is_on == true) {//已经关注，则取消关注
            httpSetting.setFunctionId(ConstFuncId.xiaoshi_friends_unon);
        } else {//没有关注，则关注
            httpSetting.setFunctionId(ConstFuncId.xiaoshi_friends_on);
        }
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    @Override
    public void onRefresh() {
    }

    @Override
    public void onLoadMore() {
        getComments();
    }

    @Override
    public void onXListViewStop() {
        xlistview_detail.stopLoadMore();
        xlistview_detail.stopRefresh();
    }

    private void favorOn() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("reader_response_id", reader_response_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                onXListViewStop();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        JSONObjectProxy obj = jSONObjectProxy.getJSONObjectOrNull("data");
                        if (obj == null) {
                            Toast.makeText(getCurrentActivity(), "已经点赞了哦", Toast.LENGTH_SHORT).show();
                        } else {
                            is_refresh = true;
                            is_favored = true;
                            setFavorImage();
                            tv_favor_total.setText(String.valueOf(Integer.valueOf(tv_favor_total.getText().toString()) + 1));
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_favor_on);
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    private void favorUnOn() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("reader_response_id", reader_response_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                onXListViewStop();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        JSONObjectProxy obj = jSONObjectProxy.getJSONObjectOrNull("data");
                        if (obj == null) {
                            Toast.makeText(getCurrentActivity(), "已经取消点赞了哦", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_favor_un_on);
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (RESULT_OK == resultCode) {
            switch (requestCode) {
                case COMMENTBACK_RESULT_FLAG:
                    String content = data.getStringExtra("content");
                    CommentsItemInfo info = new CommentsItemInfo();
                    info.setTime_stamp(System.currentTimeMillis());
                    info.setContent(content);
                    UserInfo user_info = UserInfoDBHelper.getUser(getUser_id(), getCurrentActivity());
                    info.setGender(user_info.getGender());
                    info.setNick_name(user_info.getNick_name());
                    info.setUser_image(user_info.getImage());
                    info.setReader_response_id(reader_response_id);
                    List<CommentsItemInfo> infos = new ArrayList<CommentsItemInfo>();
                    infos.add(0, info);
                    infos.addAll(adatper.getData());
                    adatper.setData(infos);
                    tv_comment_total.setText(String.valueOf(Integer.valueOf(tv_comment_total.getText().toString()) + 1));
                    is_refresh = true;
                    break;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private boolean is_refresh = false;

    @Override
    public void finish() {
        super.finish();
        if (is_refresh) {
            is_refresh = false;
            EventBusInfo info = new EventBusInfo();
            info.setIntentId(class_name_flag);
            info.setCommandId(CommandId.COMMAND_ID_1);
            EventBus.getDefault().post(info);
        }
    }
}