package com.xsfuture.xsfuture2.database;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.xsfuture.xsfuture2.bean.UserInfo;

public class UserInfoDBHelper {

    private static String TableName = "UserInfoTable";

    public static void create(SQLiteDatabase paramSQLiteDatabase) {
        if (paramSQLiteDatabase != null)
            paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TableName
                    + "(id INTEGER PRIMARY KEY AUTOINCREMENT, " + " UserId INTEGER, " + "UserName VARCHAR, "
                    + "Age INTEGER, " + "NickName VARCHAR, " + "PhoneNumber VARCHAR, " + "Password VARCHAR, "
                    + "Gender INTEGER, " + "GroupId INTEGER, " + "CreateTime VARCHAR," + "UpdateTime VARCHAR,"
                    + "Point INTEGER, " + "Token VARCHAR, " + "avatar_url VARCHAR, " + "Image VARCHAR )");
    }

    public static synchronized void delAll(Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        if (sqlitedatabase != null) {
            sqlitedatabase.delete(TableName, "1=1", null);
        }
        DBHelperUtil.closeDatabase();
    }

    public static synchronized UserInfo getUser(int user_id, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        UserInfo info = null;
        if (sqlitedatabase != null) {
            Cursor c = sqlitedatabase.rawQuery("SELECT * FROM " + TableName + " where UserId = ? ",
                    new String[]{String.valueOf(user_id)});
            while (c.moveToNext()) {
                info = new UserInfo();
                info.setUser_id(c.getInt(c.getColumnIndex("UserId")));
                info.setUser_name(c.getString(c.getColumnIndex("UserName")));
                info.setAge(c.getInt(c.getColumnIndex("Age")));
                info.setNick_name(c.getString(c.getColumnIndex("NickName")));
                info.setPhone_number(c.getString(c.getColumnIndex("PhoneNumber")));
                info.setPassword(c.getString(c.getColumnIndex("Password")));
                info.setGender(c.getInt(c.getColumnIndex("Gender")));
                info.setGroup_id(c.getInt(c.getColumnIndex("GroupId")));
                info.setCreate_time(c.getString(c.getColumnIndex("CreateTime")));
                info.setUpdate_time(c.getString(c.getColumnIndex("UpdateTime")));
                info.setPoint(c.getInt(c.getColumnIndex("Point")));
                info.setToken(c.getString(c.getColumnIndex("Token")));
                info.setAvatar_url(c.getString(c.getColumnIndex("avatar_url")));
                info.setImage(c.getString(c.getColumnIndex("Image")));
                break;
            }
            if (c != null) {
                c.close();
            }
        }
        DBHelperUtil.closeDatabase();
        return info;
    }

    public static synchronized void insertUser(UserInfo info, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        if (sqlitedatabase != null) {
            sqlitedatabase.delete(TableName, "1=1", null);
            sqlitedatabase.execSQL("INSERT INTO " + TableName + " VALUES(null,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", new Object[]{
                    info.getUser_id(), info.getUser_name(), info.getAge(), info.getNick_name(), info.getPhone_number(),
                    info.getPassword(), info.getGender(), info.getGroup_id(), info.getCreate_time(),
                    info.getUpdate_time(), info.getPoint(), info.getToken(), info.getAvatar_url(), info.getImage()});
        }
        DBHelperUtil.closeDatabase();
    }

    public static synchronized void updateUser(UserInfo info, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        if (sqlitedatabase != null) {
            ContentValues cv = new ContentValues();
            cv.put("UserId", info.getUser_id());
            cv.put("UserName", info.getUser_name());
            cv.put("Age", info.getAge());
            cv.put("NickName", info.getNick_name());
            cv.put("PhoneNumber", info.getPhone_number());
            cv.put("Password", info.getPassword());
            cv.put("Gender", info.getGender());
            cv.put("GroupId", info.getGroup_id());
            cv.put("CreateTime", info.getCreate_time());
            cv.put("UpdateTime", info.getUpdate_time());
            cv.put("Point", info.getPoint());
            cv.put("Token", info.getToken());
            cv.put("avatar_url", info.getAvatar_url());
            cv.put("Image", info.getImage());
            sqlitedatabase.update(TableName, cv, "UserId=? ", new String[]{String.valueOf(info.getUser_id())});
        }
        DBHelperUtil.closeDatabase();
    }

    public static void upgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}
