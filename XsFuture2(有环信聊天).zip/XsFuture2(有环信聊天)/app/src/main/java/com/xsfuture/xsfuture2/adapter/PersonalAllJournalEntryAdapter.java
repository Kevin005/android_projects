package com.xsfuture.xsfuture2.adapter;

import android.content.ClipboardManager;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.bean.MyReaderResponseDetails;
import com.xsfuture.xsfuture2.util.DateUtils;
import com.xsfuture.xsfuture2.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class PersonalAllJournalEntryAdapter extends BaseAdapter {

    private List<MyReaderResponseDetails> data;
    private LayoutInflater inflater;
    private ActivityHandlerInterface context;

    public PersonalAllJournalEntryAdapter(ActivityHandlerInterface c) {
        context = c;
        inflater = LayoutInflater.from(context.getCurrentActivity());
        data = new ArrayList<MyReaderResponseDetails>();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public MyReaderResponseDetails getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void setData(List<MyReaderResponseDetails> infos) {
        if (data == null) {
            data = new ArrayList<MyReaderResponseDetails>();
        } else {
            data.clear();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    public void addData(List<MyReaderResponseDetails> infos) {
        if (data == null) {
            data = new ArrayList<MyReaderResponseDetails>();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        final MyReaderResponseDetails item = data.get(position);
        holder = new ViewHolder();
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_personal_all_journal_entry, null);
            holder.response_date = (TextView) convertView.findViewById(R.id.response_date);
            holder.response_pagenum = (TextView) convertView.findViewById(R.id.response_pagenum);
//            holder.response_content = (TextView) convertView.findViewById(R.id.response_content);
            holder.img_item_img = (ImageView) convertView.findViewById(R.id.img_item_img);
            holder.love_content = (TextView) convertView.findViewById(R.id.love_content);
            holder.tv_favor_total = (TextView) convertView.findViewById(R.id.tv_favor_total);
            holder.tv_comment_total = (TextView) convertView.findViewById(R.id.tv_comment_total);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.response_date.setText(DateUtils.TimeStamp2Date(String.valueOf(item.getTime_stamp())));
        holder.response_pagenum.setText(item.getReaded_page_number() + "页");
//        holder.response_content.setText(item.getContent());
        List<String> img_list = new ArrayList<String>();
        StringBuffer txt_str = new StringBuffer();
        String[] str_array = item.getContent().split("@xiaoshi@");
        for (String str : str_array) {
            if (str.contains("http://115.28.56.168") || str.contains("https://115.28.56.168")) {
                if (StringUtils.isEmpty(str)) {
                    continue;
                } else {
                    img_list.add(str);
                }
            } else {
                if (StringUtils.isEmpty(str)) {
                    continue;
                } else {
                    txt_str.append(str);
                }
            }
        }
        //set img
        if (img_list != null && img_list.size() > 0) {
            holder.img_item_img.setVisibility(View.VISIBLE);
            Glide.with(context.getCurrentActivity())
                    .load(img_list.get(0))
                    .placeholder(R.mipmap.item_reader_response)
                    .error(R.mipmap.item_reader_response)
                    .skipMemoryCache(false)//跳过内存缓存
                    .diskCacheStrategy(DiskCacheStrategy.RESULT)
                    .into(holder.img_item_img);
        } else {
            holder.img_item_img.setVisibility(View.GONE);
        }
        //set txt
        holder.love_content.setText(txt_str.toString());
        final String content = holder.love_content.getText().toString();
        holder.love_content.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                ClipboardManager cmb = (ClipboardManager) context.getCurrentActivity().getSystemService(Context.CLIPBOARD_SERVICE);
                cmb.setText(content);
                Toast.makeText(context.getCurrentActivity(), "文字已复制", Toast.LENGTH_SHORT).show();
                return true;
            }
        });
        holder.tv_favor_total.setText(String.valueOf(item.getRr_favor_total()));
        holder.tv_comment_total.setText(String.valueOf(item.getRr_comment_total()));
        return convertView;
    }

    public class ViewHolder {
        TextView response_date;
        TextView response_pagenum;
        //        TextView response_content;
        ImageView img_item_img;
        TextView love_content;
        TextView tv_favor_total;
        TextView tv_comment_total;
    }

}
