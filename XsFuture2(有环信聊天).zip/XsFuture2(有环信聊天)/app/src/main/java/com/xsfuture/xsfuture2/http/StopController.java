package com.xsfuture.xsfuture2.http;

public interface StopController {
	public abstract boolean isStop();

	public abstract void stop();
}
