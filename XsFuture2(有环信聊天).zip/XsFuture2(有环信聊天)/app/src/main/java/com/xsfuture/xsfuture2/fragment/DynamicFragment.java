package com.xsfuture.xsfuture2.fragment;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.DynamicAdapter;
import com.xsfuture.xsfuture2.bean.EventBusInfo;
import com.xsfuture.xsfuture2.bean.SquareInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.base.FrameMainActivity;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.view.SwipeRefreshView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

public class DynamicFragment extends BaseFragment {
    private SwipeRefreshView sf_dynamic_list;
    private ListView lv_dynamic_list;
    private DynamicAdapter adapter;

    private int current_page = 0;
    private int page_size = 30;

    @Override
    protected View setCurrentContentView(LayoutInflater inflater, ViewGroup container) {
        View view = inflater.inflate(R.layout.fragment_dynamic, container, false);
        setCurrentActivity((FrameMainActivity) getActivity());
        return view;
    }

    @Override
    protected void init(View view, Bundle savedInstanceState) {
        initView(view);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)){
            EventBus.getDefault().register(this);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBusInfo info) {
//        if (info.getType() == ClassNameFlag.DYNAMIC_FRAGMENT_NAME_FLAG && info.getStatus() == ClassStatusFlag.REFRESH) {
            current_page = 0;
            loadDynamic();
//        }
    }

    private void initView(View view) {
        sf_dynamic_list = (SwipeRefreshView) view.findViewById(R.id.sf_dynamic_list);
        sf_dynamic_list.initTheme();
        sf_dynamic_list.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                current_page = 0;
                loadDynamic();
            }
        });
        sf_dynamic_list.setOnLoadListener(new SwipeRefreshView.OnLoadListener() {
            @Override
            public void onLoad() {
                loadDynamic();
            }
        });
        lv_dynamic_list = (ListView) view.findViewById(R.id.lv_dynamic_list);
        adapter = new DynamicAdapter(getCurrentActivity());
        lv_dynamic_list.setAdapter(adapter);
        loadDynamic();
    }

    private synchronized void loadDynamic() {
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                sf_dynamic_list.stopAllRoll();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        JSONArrayPoxy array = jSONObjectProxy.getJSONArrayOrNull("data");
                        if (array != null) {
                            Gson gson = new Gson();
                            List<SquareInfo> datas = gson.fromJson(array.toString(),
                                    new TypeToken<List<SquareInfo>>() {
                                    }.getType());
                            if (datas != null && datas.size() > 0 && current_page > 0) {
                                adapter.addData(datas);
                                current_page++;
                            } else if (datas != null && datas.size() > 0 && current_page == 0) {
                                adapter.setData(datas);
                                current_page++;
                            } else if (datas != null && datas.size() <= 0) {
                                sf_dynamic_list.stopAllRoll();
                            }
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_post_readlist_all + "?offset=" + current_page + "&limit="
                + page_size + "&sel=all");
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_GET);
        httpTask.executes(httpSetting);
    }

}
