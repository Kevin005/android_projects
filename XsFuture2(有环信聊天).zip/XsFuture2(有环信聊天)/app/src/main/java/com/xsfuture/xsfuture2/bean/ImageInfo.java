package com.xsfuture.xsfuture2.bean;

import android.os.Parcel;
import android.os.Parcelable;

import com.xsfuture.xsfuture2.util.Md5Encrypt;

public class ImageInfo implements Parcelable {

	public static final int SMALL_IMAGE = 1;
	public static final int MIDDLE_IMAGE = 2;
	public static final int BIT_IMAGE = 3;

	public static final String IMAGE_ROOT_PATH = "/image";
	public static final String SMALL_IMAGE_PATH = "/small";
	public static final String MIDDLE_IMAGE_PATH = "/middle";
	public static final String BIT_IMAGE_PATH = "/big";
	public static final String DEFAULT_IMAGE_PATH = "/default";

	private String id;
	private String name;
	private String url;
	private int type; // 0:小图片 1：大图片
	private int width;
	private int height;
	private int specify;// 0:未指定大小，1：指定大小

	public ImageInfo() {
	}

	public ImageInfo(String purl) {
		name = Md5Encrypt.md5(purl) + ".img";
		url = purl;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.name = url.substring(url.lastIndexOf("/") + 1);
		this.url = url;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getSpecify() {
		return specify;
	}

	public void setSpecify(int specify) {
		this.specify = specify;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		// TODO Auto-generated method stub
		dest.writeString(id);
		dest.writeString(name);
		dest.writeString(url);
		dest.writeInt(type);
		dest.writeInt(width);
		dest.writeInt(height);
		dest.writeInt(specify);
	}

	public static final Creator<ImageInfo> CREATOR = new Creator<ImageInfo>() {
		public ImageInfo createFromParcel(Parcel in) {
			return new ImageInfo(in);
		}

		public ImageInfo[] newArray(int size) {
			return new ImageInfo[size];
		}
	};

	private ImageInfo(Parcel in) {
		id = in.readString();
		name = in.readString();
		url = in.readString();
		type = in.readInt();
		width = in.readInt();
		height = in.readInt();
		specify = in.readInt();
	}

}
