package com.xsfuture.xsfuture2.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.EditText;

import com.xsfuture.xsfuture2.util.FileService;

/**
 * Created by Administrator on 2016/12/2.
 */
public class RichEditText extends EditText {
    private Context context;
    private float oldY;
    public RichEditText(Context context) {
        super(context);
        this.context = context;
    }

    public RichEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
    }

    //插入drawable
    public void insertDrawable(int id) {
        final SpannableString span_str = new SpannableString("img");
        //得到drawable对象，即所有插入的图片
        Drawable d = getResources().getDrawable(id);
        d.setBounds(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
        //用这个drawable对象代替字符串easy
        ImageSpan span = new ImageSpan(d, ImageSpan.ALIGN_BASELINE);
        //包括0但是不包括"easy".length()即：4。[0,4)
        span_str.setSpan(span, 0, "img".length(), Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        append(span_str);
    }

    //插入图片
    public void insertBitmap(String bitmap_src) {
        final SpannableString span_str = new SpannableString("@local" + bitmap_src);
        //拿到bitmap
        Bitmap bitmap = FileService.getImage(bitmap_src);
        //插入倒span中
        ImageSpan span = new ImageSpan(context, bitmap);
        //包括0但是不包括"easy".length()即：4。[0,4)
        span_str.setSpan(span, 0, ("@local" + bitmap_src).length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        append(span_str);
    }

    //插入文字
    public void insertText(String str){
        final SpannableString span_str = new SpannableString(str);
        append(span_str);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                oldY = event.getY();
                requestFocus();
                break;
            case MotionEvent.ACTION_MOVE:
                float newY = event.getY();
                if (Math.abs(oldY - newY) > 20) {
                    clearFocus();
                }
                break;
            case MotionEvent.ACTION_UP:
                break;
            default:
                break;
        }
        return super.onTouchEvent(event);
    }
}
