package com.xsfuture.xsfuture2.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.bean.TodayMainInfo;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.activity.account_module.LoginActivity;
import com.xsfuture.xsfuture2.activity.main_module.MyReadingDetailsActivity;
import com.xsfuture.xsfuture2.activity.main_module.ReleasePlanActivity;
import com.xsfuture.xsfuture2.util.PrefUtils;
import com.xsfuture.xsfuture2.util.StringUtils;
import com.xsfuture.xsfuture2.view.CircularImage;
import com.xsfuture.xsfuture2.view.GenderSelectorImage;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

public class TodayDetailsAdapter extends BaseAdapter {

    private List<TodayMainInfo> data;
    private LayoutInflater inflater;
    private ActivityHandlerInterface context;

    public TodayDetailsAdapter(ActivityHandlerInterface context) {
        this.context = context;
        inflater = LayoutInflater.from(context.getCurrentActivity());
        data = new ArrayList<TodayMainInfo>();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public TodayMainInfo getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getViewTypeCount() {
        return 4;
    }

    @Override
    public int getItemViewType(int position) {
        if (data.get(position).getInfo_type() == 1) {
            return 1;
        } else if (data.get(position).getInfo_type() == 2) {
            return 2;
        } else {
            return 3;
        }
    }

    public void addData(List<TodayMainInfo> new_data) {
        if (data == null) {
            data = new ArrayList<TodayMainInfo>();
        }
        if (new_data != null && new_data.size() > 0) {
            data.addAll(new_data);
            notifyDataSetChanged();
        }
    }

    public void setData(List<TodayMainInfo> list) {
        if (data == null) {
            data = new ArrayList<TodayMainInfo>();
        } else {
            data.clear();
        }
        if (list != null && list.size() > 0) {
            data.addAll(list);
        }
        notifyDataSetChanged();
    }

    public List<TodayMainInfo> getData() {
        return data;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        final TodayMainInfo item = data.get(position);
        if (getItemViewType(position) == 1) {
            if (convertView == null) {
                viewHolder = new ViewHolder();
                convertView = inflater.inflate(R.layout.item_reading_books, null);
                viewHolder.reading_book_for_line = (RelativeLayout) convertView.findViewById(R.id.reading_book_for_line);
                viewHolder.reading_text_add_plan = (LinearLayout) convertView.findViewById(R.id.reading_text_add_plan);
                viewHolder.reading_book_name = (TextView) convertView.findViewById(R.id.reading_book_name);
                viewHolder.reading_progress = (TextView) convertView.findViewById(R.id.reading_progress);
                viewHolder.reading_days = (TextView) convertView.findViewById(R.id.reading_days);
                viewHolder.reading_is_sign = (CheckBox) convertView.findViewById(R.id.reading_is_sign);
                viewHolder.tv_athor = (TextView) convertView.findViewById(R.id.tv_athor);
                viewHolder.img_book_cover = (ImageView) convertView.findViewById(R.id.img_book_cover);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            if (item != null) {// 读书计划为空
                if (item.isPlan_is_null()) {
                    viewHolder.reading_book_for_line.setVisibility(View.GONE);
                    viewHolder.reading_text_add_plan.setVisibility(View.VISIBLE);
                    viewHolder.reading_text_add_plan.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (isLogined()) {
                                Intent intent = new Intent(context.getCurrentActivity(), ReleasePlanActivity.class);
                                context.getCurrentActivity().startActivity(intent);
                            } else {
                                Intent intent = new Intent(context.getCurrentActivity(), LoginActivity.class);
                                context.getCurrentActivity().startActivity(intent);
                            }
                        }
                    });
                } else {
                    viewHolder.reading_book_name.setText("《" + item.getName() + "》");
                    NumberFormat fmt = NumberFormat.getPercentInstance();
                    fmt.setMaximumFractionDigits(2);
                    String progressStr = fmt.format(item.getProgress());
                    viewHolder.reading_progress.setText("已读" + progressStr);
                    viewHolder.reading_days.setText("第" + item.getRead_time() + "天");
                    Glide.with(context.getCurrentActivity())
                            .load(item.getImage())
                            .placeholder(R.drawable.book_def)
                            .error(R.drawable.book_def)
                            .skipMemoryCache(false)//跳过内存缓存
                            .diskCacheStrategy(DiskCacheStrategy.RESULT)
                            .into(viewHolder.img_book_cover);

                    viewHolder.reading_is_sign.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(context.getCurrentActivity(), MyReadingDetailsActivity.class);
                            intent.putExtra("post_id", item.getPost_id());
                            intent.putExtra("book_name", item.getName());
                            intent.putExtra("progress", item.getProgress());
                            intent.putExtra("reading_days", item.getRead_time());
                            intent.putExtra("is_signed", item.is_signed());
                            intent.putExtra("pagetotal", item.getPage_total());
                            intent.putExtra("image", item.getImage());
                            intent.putExtra("favor_total", item.getFavor_total());
                            context.getCurrentActivity().startActivityForResult(intent, 1);
                        }
                    });
                    if (item.is_signed() == false) {
                        viewHolder.reading_is_sign.setText("未打卡");
                        viewHolder.reading_is_sign.setSelected(false);
                    } else {
                        viewHolder.reading_is_sign.setText("已打卡");
                        viewHolder.reading_is_sign.setSelected(true);
                    }
                    viewHolder.reading_book_for_line.setVisibility(View.VISIBLE);
                    viewHolder.reading_text_add_plan.setVisibility(View.GONE);
                    viewHolder.reading_book_for_line.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(context.getCurrentActivity(), MyReadingDetailsActivity.class);
                            intent.putExtra("post_id", item.getPost_id());
                            intent.putExtra("book_name", item.getName());
                            intent.putExtra("progress", item.getProgress());
                            intent.putExtra("reading_days", item.getRead_time());
                            intent.putExtra("is_signed", item.is_signed());
                            intent.putExtra("pagetotal", item.getPage_total());
                            intent.putExtra("image", item.getImage());
                            intent.putExtra("author", item.getAuthor());
                            intent.putExtra("favor_total", item.getFavor_total());
                            context.getCurrentActivity().startActivityForResult(intent, 1);
                        }
                    });
                }
            }
        }

        return convertView;
    }

    public class ViewHolder {
        RelativeLayout reading_book_for_line;// 读书计划
        LinearLayout reading_text_add_plan;// 读书计划为空
        TextView reading_book_name;
        TextView reading_progress;
        TextView reading_days;
        CheckBox reading_is_sign;
        TextView tv_athor;
        ImageView img_book_cover;
        LinearLayout line_dynamic;// 关注的人动态
        TextView love_text_find_friends;// 关注的人动态为空
        CircularImage icon_patient;
        TextView love_name;
        TextView love_book_name;
        TextView love_progress;
        TextView love_content;
        TextView love_post_time;
        GenderSelectorImage img_gender_selector;
        TextView tv_favor_total;
        TextView tv_comment_total;
        ImageView img_favor;
        ImageView img_item_img;
    }

    private boolean isLogined() {
        String token = PrefUtils.getUserToken(context.getCurrentActivity());
        if (StringUtils.isEmpty(token)) {
            return false;
        }
        return true;
    }
}
