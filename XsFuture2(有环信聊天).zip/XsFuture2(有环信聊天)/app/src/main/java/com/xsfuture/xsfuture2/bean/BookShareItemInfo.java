package com.xsfuture.xsfuture2.bean;

/**
 * Created by Kevin on 2017/6/5.
 */
public class BookShareItemInfo {
    private String sell_user_phone_num;
    private String avatar_url;
    private String sell_user_name;
    private String book_cover_url;
    private String book_name;
    private String book_author;

    public String getSell_user_phone_num() {
        return sell_user_phone_num;
    }

    public void setSell_user_phone_num(String sell_user_phone_num) {
        this.sell_user_phone_num = sell_user_phone_num;
    }

    public String getSell_user_name() {
        return sell_user_name;
    }

    public void setSell_user_name(String sell_user_name) {
        this.sell_user_name = sell_user_name;
    }

    public String getAvatar_url() {
        return avatar_url;
    }

    public void setAvatar_url(String avatar_url) {
        this.avatar_url = avatar_url;
    }


    public String getBook_cover_url() {
        return book_cover_url;
    }

    public void setBook_cover_url(String book_cover_url) {
        this.book_cover_url = book_cover_url;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public String getBook_author() {
        return book_author;
    }

    public void setBook_author(String book_author) {
        this.book_author = book_author;
    }

}
