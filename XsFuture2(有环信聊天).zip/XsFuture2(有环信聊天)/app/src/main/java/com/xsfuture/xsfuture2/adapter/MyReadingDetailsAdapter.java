package com.xsfuture.xsfuture2.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.main_module.ReadingBookJournalEntryDetailsActiviy;
import com.xsfuture.xsfuture2.activity.main_module.WriteJournalEntryActivity;
import com.xsfuture.xsfuture2.bean.MyReaderResponseDetails;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.DateUtils;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.StringUtils;

import org.json.JSONException;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

public class MyReadingDetailsAdapter extends BaseAdapter {

    private List<MyReaderResponseDetails> data;
    private LayoutInflater inflater;
    private ActivityHandlerInterface context;
    private MyReadingRefresh myReadingRefresh;

    public interface MyReadingRefresh {
        void signInSuccess();
    }

    public MyReadingDetailsAdapter(ActivityHandlerInterface context, MyReadingRefresh myReadingRefresh) {
        this.context = context;
        inflater = LayoutInflater.from(context.getCurrentActivity());
        data = new ArrayList<MyReaderResponseDetails>();
        this.myReadingRefresh = myReadingRefresh;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public MyReaderResponseDetails getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getViewTypeCount() {
        return 2;
    }

    @Override
    public int getItemViewType(int position) {
        if (data.get(position).getInfo_type() == 0) {
            return 0;
        } else {
            return 1;
        }
    }

    public void addData(List<MyReaderResponseDetails> new_data) {
        if (data == null) {
            data = new ArrayList<MyReaderResponseDetails>();
        }
        if (new_data != null && new_data.size() > 0) {
            data.addAll(new_data);
            notifyDataSetChanged();
        }
    }

    public void setData(List<MyReaderResponseDetails> list) {
        if (data == null) {
            data = new ArrayList<MyReaderResponseDetails>();
        } else {
            data.clear();
        }
        if (list != null && list.size() > 0) {
            data.addAll(list);
        }
        notifyDataSetChanged();
    }

    public List<MyReaderResponseDetails> getData() {
        return data;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        final MyReaderResponseDetails item = data.get(position);
        if (getItemViewType(position) == 0) {
            if (convertView == null) {
                viewHolder = new ViewHolder();
                LayoutInflater layoutInflater = LayoutInflater.from(context.getCurrentActivity());
                convertView = layoutInflater.inflate(R.layout.item_reading_book_detail, null);
                viewHolder.tv_book_name = (TextView) convertView.findViewById(R.id.tv_book_name);
                viewHolder.tv_author = (TextView) convertView.findViewById(R.id.tv_author);
                viewHolder.progress = (TextView) convertView.findViewById(R.id.progress);
                viewHolder.tv_book_favor_total = (TextView) convertView.findViewById(R.id.tv_book_favor_total);
                viewHolder.reading_days = (TextView) convertView.findViewById(R.id.reading_days);
                viewHolder.pagetotal = (TextView) convertView.findViewById(R.id.pagetotal);
                viewHolder.img_book = (ImageView) convertView.findViewById(R.id.img_book);
                viewHolder.btn_write = (Button) convertView.findViewById(R.id.btn_write);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            viewHolder.tv_book_name.setText("《" + item.getBook_name() + "》");
            viewHolder.tv_author.setText(item.getAuthor());
            NumberFormat fmt = NumberFormat.getPercentInstance();
            fmt.setMaximumFractionDigits(2);
            String progressStr = fmt.format(item.getProgress());
            viewHolder.progress.setText("已读" + progressStr);
            viewHolder.tv_book_favor_total.setText(String.valueOf(item.getRr_favor_total()));
            viewHolder.reading_days.setText("第" + item.getReaded_days() + "天");
            viewHolder.pagetotal.setText("共" + item.getPage_total() + "页");
            Glide.with(context.getCurrentActivity())
                    .load(item.getBook_image())
                    .placeholder(R.drawable.book_def)
                    .error(R.drawable.book_def)
                    .skipMemoryCache(false)//跳过内存缓存
                    .diskCacheStrategy(DiskCacheStrategy.RESULT)
                    .into(viewHolder.img_book);

            if (item.is_signed() == false) {
                viewHolder.btn_write.setSelected(false);
                viewHolder.btn_write.setText("今日打卡");
                viewHolder.btn_write.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        signIn(item);
                    }
                });
            } else {
                viewHolder.btn_write.setSelected(true);
                viewHolder.btn_write.setText("继续记录");
                viewHolder.btn_write.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(context.getCurrentActivity(), WriteJournalEntryActivity.class);
                        intent.putExtra("post_id", item.getPost_id());
                        intent.putExtra("book_name", item.getBook_name());
                        context.getCurrentActivity().startActivity(intent);
                    }
                });
            }
        } else if (getItemViewType(position) == 1) {
            if (convertView == null) {
                viewHolder = new ViewHolder();
                LayoutInflater layoutInflater = LayoutInflater.from(context.getCurrentActivity());
                convertView = layoutInflater.inflate(R.layout.item_journal_entry_detail, null);
                viewHolder.response_date = (TextView) convertView.findViewById(R.id.response_date);
                viewHolder.response_pagenum = (TextView) convertView.findViewById(R.id.response_pagenum);
                viewHolder.response_content = (TextView) convertView.findViewById(R.id.response_content);
                viewHolder.img_item_img = (ImageView) convertView.findViewById(R.id.img_item_img);
                viewHolder.img_favor = (ImageView) convertView.findViewById(R.id.img_favor);
                viewHolder.tv_favor_total = (TextView) convertView.findViewById(R.id.tv_favor_total);
                viewHolder.tv_comment_total = (TextView) convertView.findViewById(R.id.tv_comment_total);
                viewHolder.line_raading_content = (LinearLayout) convertView.findViewById(R.id.line_raading_content);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            viewHolder.response_date.setText(DateUtils.TimeStamp2Date(String.valueOf(item.getTime_stamp())));
            viewHolder.response_pagenum.setText(item.getReaded_page_number() + "页");
            List<String> img_list = new ArrayList<String>();
            StringBuffer txt_str = new StringBuffer();
            String[] str_array = item.getContent().split("@xiaoshi@");
            for (String str : str_array) {
                if (str.contains("http://115.28.56.168") || str.contains("https://115.28.56.168")) {
                    if (StringUtils.isEmpty(str)) {
                        continue;
                    } else {
                        img_list.add(str);
                    }
                } else {
                    if (StringUtils.isEmpty(str)) {
                        continue;
                    } else {
                        txt_str.append(str);
                    }
                }
            }
            //set img
            if (img_list != null && img_list.size() > 0) {
                viewHolder.img_item_img.setVisibility(View.VISIBLE);
                Glide.with(context.getCurrentActivity())
                        .load(img_list.get(0))
                        .placeholder(R.mipmap.item_reader_response)
                        .error(R.mipmap.item_reader_response)
                        .skipMemoryCache(false)//跳过内存缓存
                        .diskCacheStrategy(DiskCacheStrategy.RESULT)
                        .into(viewHolder.img_item_img);
            } else {
                viewHolder.img_item_img.setVisibility(View.GONE);
            }
            //set txt
            viewHolder.response_content.setText(txt_str.toString());
            if (item.is_favored()) {
                viewHolder.img_favor.setImageResource(R.drawable.favored);
                viewHolder.tv_favor_total.setTextColor(context.getCurrentActivity().getResources().getColor(R.color.main_color));
            } else {
                viewHolder.img_favor.setImageResource(R.drawable.favor);
                viewHolder.tv_favor_total.setTextColor(context.getCurrentActivity().getResources().getColor(R.color.item_text_color));
            }
            viewHolder.tv_favor_total.setText(String.valueOf(item.getRr_favor_total()));
            viewHolder.tv_comment_total.setText(String.valueOf(item.getRr_comment_total()));
            viewHolder.line_raading_content.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context.getCurrentActivity(), ReadingBookJournalEntryDetailsActiviy.class);
                    intent.putExtra("time_stamp", item.getTime_stamp());
                    intent.putExtra("readed_page_number", item.getReaded_page_number());
                    intent.putExtra("content", item.getContent());
                    intent.putExtra("favor_total", item.getRr_favor_total());
                    intent.putExtra("comment_total", item.getRr_comment_total());
                    intent.putExtra("reader_response_id", item.getReader_response_id());
                    intent.putExtra("is_favored", item.is_favored());
//                    context.getCurrentActivity().startActivityForResult(intent, 1);
                    context.getCurrentActivity().startActivity(intent);
                }
            });
        }
        return convertView;
    }

    public class ViewHolder {
        TextView tv_book_name;
        TextView tv_author;
        TextView progress;
        TextView tv_book_favor_total;
        TextView reading_days;
        TextView response_date;
        TextView response_pagenum;
        TextView response_content;
        ImageView img_item_img;
        ImageView img_favor;
        TextView pagetotal;
        ImageView img_book;
        Button btn_write;
        TextView tv_favor_total;
        TextView tv_comment_total;
        LinearLayout line_raading_content;
    }

    private void signIn(final MyReaderResponseDetails item) {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("post_id", String.valueOf(item.getPost_id()));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(context) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONObjectProxy data = jSONObjectProxy.getJSONObjectOrNull("data");
                    if (success == 0) {
                        myReadingRefresh.signInSuccess();
                        Intent intent = new Intent(context.getCurrentActivity(), WriteJournalEntryActivity.class);
                        intent.putExtra("post_id", item.getPost_id());
                        intent.putExtra("book_name", item.getBook_name());
                        context.getCurrentActivity().startActivity(intent);
                    } else {
                        Toast.makeText(context.getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(context.getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_post_signIn);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

}
