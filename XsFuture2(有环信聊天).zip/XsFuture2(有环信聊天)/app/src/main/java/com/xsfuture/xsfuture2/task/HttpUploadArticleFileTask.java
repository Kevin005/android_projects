package com.xsfuture.xsfuture2.task;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;

import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.http.StopController;
import com.xsfuture.xsfuture2.util.BitmapUtils;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.Log;
import com.xsfuture.xsfuture2.view.LoadingProgressDialog;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

public abstract class HttpUploadArticleFileTask extends AsyncTask<String, Integer, JSONObjectProxy> implements StopController {

	private ActivityHandlerInterface ahi;
	private LoadingProgressDialog progressDialog;
	public static String TAG = "HttpUploadArticleFileTask";
	private String BOUNDARY; // 边界标识 随机生成
	private String PREFIX;
	private String LINE_END;
	private String CONTENT_TYPE; // 内容类型
	private File uploadFile;
	private long totalSize; // Get size of file, bytes
	private String filePath;
	private String key;
	private int post_id;

	public HttpUploadArticleFileTask(ActivityHandlerInterface ah, String file_path, String pkey,int post_id) {
		ahi = ah;
		key = pkey;
		this.post_id = post_id;
		filePath = file_path;
		uploadFile = new File(file_path);
		totalSize = uploadFile.length();
		BOUNDARY = UUID.randomUUID().toString();
		PREFIX = "--";
		LINE_END = "\r\n";
		CONTENT_TYPE = "multipart/form-data";
	}

	@Override
	protected void onPreExecute() {
		// 此时显示progressbar
		showModal();
		onStart();
	}

	@Override
	protected JSONObjectProxy doInBackground(String... params) {
		String actionUrl = params[0];
		String result = "";
		long length = 0;
		int progress;
		int bytesRead, bytesAvailable, bufferSize;
		byte[] buffer;
		int maxBufferSize = 10 * 1024;// 10KB

		try {
			URL url = new URL(actionUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			// Set size of every block for post
			// conn.setChunkedStreamingMode(1024 * 1024 * 6);// 128KB
			conn.setReadTimeout(3600);
			conn.setConnectTimeout(3600);
			conn.setDoInput(true); // 允许输入流
			conn.setDoOutput(true); // 允许输出流
			conn.setUseCaches(false); // 不允许使用缓存
			conn.setRequestMethod("POST"); // 请求方式
			conn.setRequestProperty("Charset", "UTF-8"); // 设置编码
			conn.setRequestProperty("connection", "keep-alive");
			conn.setRequestProperty("Content-Type", CONTENT_TYPE + ";boundary=" + BOUNDARY);
			conn.setRequestProperty("Accept", "application/json;charset=utf-8");
			conn.setRequestProperty("X-AccessToken", ahi.getUser_token());
			if (uploadFile != null) {
				DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
				StringBuffer sb = new StringBuffer();
				//第一个参数
				sb.append(PREFIX);
				sb.append(BOUNDARY);
				sb.append(LINE_END);
				sb.append("Content-Disposition: form-data; name=\""
						+ "post_id" + "\"" + LINE_END);
				sb.append(LINE_END);
				sb.append(post_id + LINE_END);
				//第二个参数
				sb.append(PREFIX);
				sb.append(BOUNDARY);
				sb.append(LINE_END);
				/**
				 * 这里重点注意： name里面的值为服务端需要key 只有这个key 才可以得到对应的文件
				 * filename是文件的名字，包含后缀名的 比如:abc.png
				 */
				sb.append("Content-Disposition: form-data; name=\"" + key + "\"; filename=\""
						+ java.net.URLEncoder.encode(uploadFile.getName(), "UTF-8") + "\"" + LINE_END);
				if (uploadFile.getName().endsWith("jpg")) {
					sb.append("Content-Type: image/jpeg" + LINE_END);
				} else if (uploadFile.getName().endsWith("png")) {
					sb.append("Content-Type: image/x-png" + LINE_END);
				}
				sb.append(LINE_END);

				dos.write(sb.toString().getBytes());

//				Bitmap bm = getSmallBitmap(filePath);
				Bitmap bm = BitmapUtils.getBitmap(filePath);
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				if (uploadFile.getName().endsWith("jpg")) {
					bm.compress(Bitmap.CompressFormat.JPEG, 25, baos);
				} else if (uploadFile.getName().endsWith("png")) {
					bm.compress(Bitmap.CompressFormat.PNG, 25, baos);
				} else {
					bm.compress(Bitmap.CompressFormat.JPEG, 25, baos);
				}

				InputStream in = new ByteArrayInputStream(baos.toByteArray());

				// InputStream is = new FileInputStream(uploadFile);
				bytesAvailable = in.available();
				bufferSize = Math.min(bytesAvailable, maxBufferSize);// 设置每次写入的大小
				buffer = new byte[bufferSize];
				// Read file
				bytesRead = in.read(buffer, 0, bufferSize);
				while (bytesRead > 0) {
					dos.write(buffer, 0, bufferSize);
					length += bufferSize;
					progress = (int) ((length * 100) / totalSize);
					publishProgress(progress);

					bytesAvailable = in.available();
					bufferSize = Math.min(bytesAvailable, maxBufferSize);
					bytesRead = in.read(buffer, 0, bufferSize);
				}
				byte[] bytes = new byte[1024];
				int len = 0;
				while ((len = in.read(bytes)) != -1) {
					dos.write(bytes, 0, len);
				}
				in.close();
				baos.close();
				dos.write(LINE_END.getBytes());
				// 请求结束标志
				byte[] end_data = (PREFIX + BOUNDARY + PREFIX + LINE_END).getBytes();
				dos.write(end_data);
				dos.flush();
				publishProgress(100);
				/**
				 * 获取响应码 200=成功 当响应成功，获取响应的流
				 */
				int res = conn.getResponseCode();
				if (res == 200) {
					InputStream input = conn.getInputStream();
					StringBuffer sb1 = new StringBuffer();
					int ss;
					while ((ss = input.read()) != -1) {
						sb1.append((char) ss);
					}
					result = sb1.toString();
					if (result.indexOf('{') >= 0) {
						String s2 = result.substring(result.indexOf('{'));
						JSONObject json = (JSONObject) new JSONTokener(s2).nextValue();
						JSONObjectProxy jsonobjectproxy = new JSONObjectProxy(json);
						return jsonobjectproxy;
					}
				} else {
					Log.e("FileUploadTask", "request error");
				}
			}
		} catch (Exception e) {
			Log.e("FileUploadTask", e.toString());
		}
		return null;
	}

	@Override
	protected void onProgressUpdate(Integer... progress) {
		if (progress != null && progress.length == 2)
			onProgress(progress[0], progress[1]);

	}

	@Override
	protected void onPostExecute(JSONObjectProxy result) {
		onEnd(result);
		hideModal();
	}

	// 计算图片的缩放值
	public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {
			final int heightRatio = Math.round((float) height / (float) reqHeight);
			final int widthRatio = Math.round((float) width / (float) reqWidth);
			inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
		}
		return inSampleSize;
	}

	public static Bitmap getSmallBitmap(String filePath) {
		final BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeFile(filePath, options);

		// Calculate inSampleSize
		options.inSampleSize = calculateInSampleSize(options, 480, 800);

		// Decode bitmap with inSampleSize set
		options.inJustDecodeBounds = false;

		return BitmapFactory.decodeFile(filePath, options);
	}

	// private void showModal() {
	// try {
	// if (ahi != null) {
	// HttpState state = ahi.getHttpState();
	// if (state == null) {
	// state = new HttpState(ahi.getCurrentActivity());
	// ahi.AddHttpState(state);
	// }
	// state.show();
	// }
	// } catch (Exception e) {
	// if (Log.E) {
	// Log.e("HttpTask showModal", e.toString());
	// }
	// }
	// }
	//
	// private void hideModal() {
	// if (ahi != null) {
	// HttpState state = ahi.getHttpState();
	// if (state != null) {
	// if (state.remove())
	// ahi.RemoveHttpState();
	// }
	// }
	// }
	private void showModal() {
		if (ahi != null) {
			if (progressDialog == null) {
				progressDialog = LoadingProgressDialog.createDialog(ahi.getCurrentActivity());
				progressDialog.setMessage("正在上传，请稍后！");
			}
			progressDialog.setCancelable(false);
			progressDialog.show();
		}

	}

	private void hideModal() {
		if (ahi != null && ahi.getCurrentActivity() != null) {
			if (progressDialog != null) {
				progressDialog.dismiss();
				progressDialog = null;
			}
		}
	}

	public void executes(String url) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.GINGERBREAD_MR1)
			executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, url);
		else
			execute(url);
	}

	public abstract void onError();

	public abstract void onStart();

	public abstract void onEnd(JSONObjectProxy result);

	public abstract void onProgress(int i, int j);
}
