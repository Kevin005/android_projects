package com.xsfuture.xsfuture2.util;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.text.TextUtils;

import com.xsfuture.xsfuture2.bean.CacheFileItem;
import com.xsfuture.xsfuture2.bean.ImageInfo;
import com.xsfuture.xsfuture2.cache.ImageCache;
import com.xsfuture.xsfuture2.config.ConstFileProp;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.database.CacheFileTableDBHelper;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class FileService {

    // 判断外部存储设备是否可用
    public static boolean externalMemoryAvailable() {
        return Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
    }

    public static String formatSize(long paramLong) {
        String str1 = null;
        if (paramLong >= 1024L) {
            str1 = "KiB";
            paramLong /= 1024L;
            if (paramLong >= 1024L) {
                str1 = "MiB";
                paramLong /= 1024L;
            }
        }
        String str2 = Long.toString(paramLong);
        StringBuilder localStringBuilder1 = new StringBuilder(str2);
        int i = localStringBuilder1.length() - 3;
        do {
            if (i <= 0) {
                if (str1 != null)
                    localStringBuilder1.append(str1);
                return localStringBuilder1.toString();
            }
            localStringBuilder1.insert(i, ',');

            i -= 3;
        } while (true);
    }

    public static String formatSize2(long paramLong) {
        String str1 = null;
        float f = Long.valueOf(paramLong).floatValue();
        if (f >= 1024.0F) {
            str1 = "KB";
            f /= 1024.0F;
            if (f >= 1024.0F) {
                str1 = "MB";
                f /= 1024.0F;
            }
        }
        DecimalFormat localDecimalFormat = new DecimalFormat(".00");
        double d = f;
        String str2 = localDecimalFormat.format(d);
        StringBuilder localStringBuilder1 = new StringBuilder(str2);
        int i = localStringBuilder1.indexOf(".") - 3;
        do {
            if (i <= 0) {
                if (str1 != null)
                    localStringBuilder1.append(str1);
                return localStringBuilder1.toString();
            }
            localStringBuilder1.insert(i, ',');
            i += -3;
        } while (true);
    }

    public static Directory getDirectory(int paramInt) {
        Directory directory = null;
        switch (paramInt) {
            case ConstHttpProp.TYPE_JSON:
                directory = getJsonDirectory();
                break;
            case ConstHttpProp.TYPE_IMAGE:
                directory = getImageDirectory();
                break;
        }

        return directory;
    }

    private static Directory getJsonDirectory() {
        Directory directory = null;
        if (externalMemoryAvailable()) {
            File josnFile = getExternalDirectory("/json");
            directory = new Directory(josnFile);

        } else {

        }

        return directory;
    }

    private static Directory getImageDirectory() {
        Directory directory = null;
        if (externalMemoryAvailable()) {
            File josnFile = getExternalDirectory("/image");
            directory = new Directory(josnFile);

        } else {

        }

        return directory;
    }

    public static FileOutputStream openFileOutput(FileGuider fileguider, Context context) throws FileNotFoundException {
        FileOutputStream fileoutputstream = null;
        FileGuider.StorageType space = fileguider.getSpace();
        if (space == FileGuider.StorageType.STORAGE_INTERNAL) {
            String name = fileguider.getFileName();
            int mode = fileguider.getMode();
            fileoutputstream = context.openFileOutput(name, mode);
        } else {
            Directory dir = fileguider.getDir();
            String filename = fileguider.getFileName();
            File file = null;
            if (dir != null && dir.getPath() != null && !dir.getPath().trim().equals("")) {
                file = new File(dir.getPath(), filename);
            } else {
                file = new File(Environment.getExternalStorageDirectory(), filename);
            }
            if (file.exists()) {
                file.delete();
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    if (Log.E) {
                        Log.e("FileService.openFileOutput", e.toString());
                    }
                    return null;
                }
            }
            fileoutputstream = new FileOutputStream(file);
        }
        return fileoutputstream;
    }

    public static FileInputStream openFileInput(FileGuider fileguider, Context context) throws FileNotFoundException {
        FileInputStream fileInputStream = null;
        FileGuider.StorageType space = fileguider.getSpace();
        if (space == FileGuider.StorageType.STORAGE_INTERNAL) {
            String name = fileguider.getFileName();
            fileInputStream = context.openFileInput(name);
        } else {
            Directory dir = fileguider.getDir();
            String filename = fileguider.getFileName();
            File file = new File(dir.getPath(), filename);
            if (file.exists()) {
                fileInputStream = new FileInputStream(file);
            }
        }
        return fileInputStream;
    }

    public static FileInputStream openFileInput(String filename, Context context) throws FileNotFoundException {
        FileInputStream fileInputStream = null;
        File file = new File(filename);
        if (file.exists()) {
            fileInputStream = new FileInputStream(file);
        }
        return fileInputStream;
    }

    public static byte[] readInputStream(FileInputStream fileInputStream) throws Exception {
        if (fileInputStream != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] arrayOfByte = new byte[1024];
            do {
                int len = fileInputStream.read(arrayOfByte);
                if (len <= 0) {
                    fileInputStream.close();
                    byte[] bytes = byteArrayOutputStream.toByteArray();
                    byteArrayOutputStream.close();
                    return bytes;
                }
                byteArrayOutputStream.write(arrayOfByte, 0, len);
            } while (true);
        } else {
            return null;
        }
    }

    public static Directory getExternalImageDirectory(ImageInfo imageinfo) {
        if (externalMemoryAvailable()) {
            StringBuilder stringbuilder = new StringBuilder(ImageInfo.IMAGE_ROOT_PATH);
            if (imageinfo != null) {
                switch (imageinfo.getType()) {
                    case ImageInfo.SMALL_IMAGE:
                        stringbuilder.append(ImageInfo.SMALL_IMAGE_PATH);
                        break;
                    case ImageInfo.MIDDLE_IMAGE:
                        stringbuilder.append(ImageInfo.MIDDLE_IMAGE_PATH);
                        break;
                    case ImageInfo.BIT_IMAGE:
                        stringbuilder.append(ImageInfo.BIT_IMAGE_PATH);
                        break;
                    default:
                        stringbuilder.append(ImageInfo.DEFAULT_IMAGE_PATH);
                        break;
                }
            } else {
                stringbuilder.append(ImageInfo.DEFAULT_IMAGE_PATH);
            }

            File newfile = getExternalDirectory(stringbuilder.toString());
            Directory newDirectory = new Directory(newfile);
            return newDirectory;
        } else {
            return null;
        }
    }

    //本地读取图片
    public static Bitmap getImage(boolean isCompress, ImageInfo image, Context context)
            throws IOException {
        if (!isCompress) {
            if (!image.getUrl().contains("big")) {
                String new_url = image.getUrl().substring(0, image.getUrl().lastIndexOf("/")) + "/big" + image.getUrl().substring(image.getUrl().lastIndexOf("/") + 1);
                image.setUrl(new_url);
            }
        }
        return getImage(image, context, false);
    }

    // 本地读取图片
    public static Bitmap getImage(ImageInfo image, Context context) throws IOException {
        return getImage(image, context, false);
    }

    public static Bitmap getImage(ImageInfo image, Context context, boolean isLocal) throws IOException {
        FileInputStream fileInputStream = null;
        if (isLocal) {
            fileInputStream = FileService.openFileInput(image.getUrl(), context);
        } else {
            Directory imageDir = getExternalImageDirectory(image);
            if (imageDir != null) {
                FileGuider fileguider = new FileGuider();
                fileguider.setSpace(FileGuider.StorageType.STORAGE_EXTERNAL);
                fileguider.setFileName(image.getName());
                fileguider.setDir(imageDir);
                fileInputStream = FileService.openFileInput(fileguider, context);
            }
        }
        if (fileInputStream != null) {
            Bitmap bitmap = BitmapFactory.decodeStream(fileInputStream);
            fileInputStream.close();
            return bitmap;
        } else {
            return null;
        }
    }

    public static Bitmap getThumbImage(ImageInfo image, Context context) throws IOException {
        Directory imageDir = getExternalImageDirectory(image);
        if (imageDir != null) {
            FileGuider fileguider = new FileGuider();
            fileguider.setSpace(FileGuider.StorageType.STORAGE_EXTERNAL);
            fileguider.setFileName(image.getName());
            fileguider.setDir(imageDir);
            FileInputStream fileInputStream = FileService.openFileInput(fileguider, context);
            if (fileInputStream != null) {
                Bitmap bitmap = BitmapFactory.decodeStream(fileInputStream);
                fileInputStream.close();
                return bitmap;
            } else {
                return null;
            }

        } else {
            return null;
        }
    }

    public static Bitmap getImage(String path) {
        if (path != null) {
            try {
                File file = new File(path);
                FileInputStream fileInputStream = new FileInputStream(file);
                Bitmap bitmap = BitmapFactory.decodeStream(fileInputStream);
                fileInputStream.close();
                return bitmap;

            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                return null;
            } catch (IOException e) {
                // TODO Auto-generated catch block
                return null;
            }

        } else {
            return null;
        }
    }

    public static Drawable getDrawable(String url, Resources res, String path) {
        if (path != null) {
            try {
                File file = new File(path);
                FileInputStream fileInputStream = new FileInputStream(file);
                Bitmap bitmap = BitmapFactory.decodeStream(fileInputStream);
                fileInputStream.close();
                ImageCache.putBitmap(Md5Encrypt.md5(url), bitmap);
                BitmapDrawable bd = new BitmapDrawable(res, bitmap);
                return bd;

            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                return null;
            } catch (IOException e) {
                // TODO Auto-generated catch block
                return null;
            }

        } else {
            return null;
        }
    }

    public static void saveImage(ImageInfo image, InputStream is, Context context) throws IOException {
        Directory imageDir = FileService.getExternalImageDirectory(image);
        if (imageDir != null) {
            FileGuider fileguider = new FileGuider();
            fileguider.setSpace(FileGuider.StorageType.STORAGE_EXTERNAL);
            fileguider.setFileName(image.getName());
            fileguider.setDir(imageDir);
            FileOutputStream fileoutputstream = openFileOutput(fileguider, context);
            byte abyte0[] = new byte[16384];
            int len = 0;
            if (is != null && fileoutputstream != null) {
                while (true) {
                    len = is.read(abyte0);
                    if (len == -1) {
                        break;
                    } else {
                        fileoutputstream.write(abyte0, 0, len);
                    }
                }
                if (fileoutputstream != null)
                    fileoutputstream.close();
            }
        }
    }

    public static String saveImage(String filename, InputStream is) {
        File imgFile = new File(filename);
        String path = imgFile.getAbsolutePath();
        if (imgFile.exists()) {
            imgFile.delete();
        }
        FileOutputStream fileoutputstream;

        try {
            fileoutputstream = new FileOutputStream(imgFile);

            byte abyte0[] = new byte[16384];
            int len = 0;
            if (is != null && fileoutputstream != null) {
                while (true) {
                    len = is.read(abyte0);
                    if (len == -1) {
                        break;
                    } else {
                        fileoutputstream.write(abyte0, 0, len);
                    }
                }
                if (fileoutputstream != null)
                    fileoutputstream.close();
            }

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block

        } catch (IOException e) {
            // TODO Auto-generated catch block

        }
        return path;
    }

    public static String saveDrawable(CompressFormat format, Drawable drawable, String filename) {

        File imgFile = new File(filename);
        String path = imgFile.getAbsolutePath();
        if (imgFile.exists()) {
            imgFile.delete();
        }

        if (drawable != null) {
            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
            FileOutputStream out;
            try {
                out = new FileOutputStream(imgFile);
                bitmap.compress(format, 80, out);
                out.flush();
                out.close();
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block

            } catch (IOException e) {
                // TODO Auto-generated catch block

            }
        }
        return path;
    }

    /*
    * 图片压缩方法一
    *
    * 计算 bitmap大小，如果超过64kb，则进行压缩
    *
    * @param bitmap
    * @return
    */
//    private static Bitmap imageCompressL(Bitmap bitmap) {
//        double targetwidth = Math.sqrt(64.00 * 1000);
//        if (bitmap.getWidth() > targetwidth || bitmap.getHeight() > targetwidth) {
//            // 创建操作图片用的matrix对象
//            Matrix matrix = new Matrix();
//            // 计算宽高缩放率
//            double x = Math.max(targetwidth / bitmap.getWidth(), targetwidth / bitmap.getHeight());
//            // 缩放图片动作
//            matrix.postScale((float) x, (float) x);
//            bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(),
//                    bitmap.getHeight(), matrix, true);
//        }
//        return bitmap;
//    }

    public static String saveBitmap(Bitmap bitmap, String relativePath, String filename) {
//        Bitmap bitmap1 = imageCompressL(bitmap);
        File imgFilePath = getExternalDirectory("/image" + relativePath);
        File imgFile = new File(imgFilePath, filename);
        String path = imgFile.getAbsolutePath();
        if (imgFile.exists()) {
            imgFile.delete();
        }
        FileOutputStream out;
        try {
            out = new FileOutputStream(imgFile);
            bitmap.compress(CompressFormat.PNG, 100, out);
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block

        } catch (IOException e) {
            // TODO Auto-generated catch block

        }

        return path;
    }

    public static String saveBitmap(Bitmap bitmap, String filename) {
        File imgFile = new File(filename);
        String path = imgFile.getAbsolutePath();
        if (imgFile.exists()) {
            imgFile.delete();
        }
        FileOutputStream out;
        try {
            out = new FileOutputStream(imgFile);
            bitmap.compress(CompressFormat.PNG, 60, out);
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block

        } catch (IOException e) {
            // TODO Auto-generated catch block

        }

        return path;
    }

    /*
     * 获取指定的外部存储路劲 参数：String dir 存储路劲 返回值：该存储路劲的文件句柄
     */
    public static File getExternalDirectory(String dir) {
        File rootFile = Environment.getExternalStorageDirectory();
        StringBuilder stringbuilder = new StringBuilder(ConstSysConfig.rootFilePath);
        String s1;
        if (dir != null) {
            s1 = dir;
        } else {
            s1 = "";
        }
        String newdir = stringbuilder.append(s1).toString();
        File newFile = new File(rootFile, newdir);
        if (!newFile.exists())
            newFile.mkdirs();
        return newFile;
    }

    public static byte[] readInInternal(String filename, Context context) throws Exception {
        FileInputStream fileInputStream = context.openFileInput(filename);
        return readInputStream(fileInputStream);
    }

    public static boolean saveToSDCard(Directory directory, String filename, byte[] bytes) {
        File dirfile = directory.getDir();
        File file = new File(dirfile, filename);
        FileOutputStream fileoutputstream = null;
        try {
            fileoutputstream = new FileOutputStream(file);
            if (fileoutputstream != null) {
                fileoutputstream.write(bytes);
                fileoutputstream.close();
            }
        } catch (IOException ioexception2) {
            try {
                if (fileoutputstream != null)
                    fileoutputstream.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                return false;
            }

            return false;
        }

        return true;
    }

    public void saveToInternal(String filename, String content, Context context) throws Exception {
        FileOutputStream fileOutputStream = context.openFileOutput(filename, Context.MODE_PRIVATE);
        byte[] bytes = content.getBytes();
        fileOutputStream.write(bytes);
        fileOutputStream.close();
    }

    // 删除所有过期文件
    public static void clearCacheFiles(Context context) {
        ArrayList<CacheFileItem> clearList = CacheFileTableDBHelper.getListByClean(context);
        boolean available = externalMemoryAvailable();
        for (CacheFileItem item : clearList) {
            Directory directory = item.getDirectory();
            if ((directory.getSpace() == ConstFileProp.STORAGE_INTERNAL)
                    || ((directory.getSpace() == ConstFileProp.STORAGE_EXTERNAL) && (available))) {
                if (item.getFile().delete())
                    CacheFileTableDBHelper.delete(context, item);
            }
        }
    }

    public static String getTempPath() {
        File rootFile = Environment.getExternalStorageDirectory();
        StringBuilder stringbuilder = new StringBuilder(ConstSysConfig.rootFilePath);
        String s1 = "/image/temp/";
        String newdir = stringbuilder.append(s1).toString();
        File newFile = new File(rootFile, newdir);
        if (!newFile.exists())
            newFile.mkdirs();
        return newFile.getAbsolutePath();
    }

    public static String getAdvPath() {
        File rootFile = Environment.getExternalStorageDirectory();
        StringBuilder stringbuilder = new StringBuilder(ConstSysConfig.rootFilePath);
        String s1 = "/image/adv/";
        String newdir = stringbuilder.append(s1).toString();
        File newFile = new File(rootFile, newdir);
        if (!newFile.exists())
            newFile.mkdirs();
        return newFile.getAbsolutePath();
    }

    public static Bitmap safeDecodeStream(Context ctx, Uri uri, int width, int height) {
        try {
            int scale = 1;
            BitmapFactory.Options options = new BitmapFactory.Options();
            android.content.ContentResolver resolver = ctx.getContentResolver();
            if (width > 0 || height > 0) {
                // Decode image size without loading all data into memory
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeStream(new BufferedInputStream(resolver.openInputStream(uri), 16 * 1024), null,
                        options);

                int w = options.outWidth;
                int h = options.outHeight;
                while (true) {
                    if ((width > 0 && w / 2 < width) || (height > 0 && h / 2 < height)) {
                        break;
                    }
                    w /= 2;
                    h /= 2;
                    scale *= 2;
                }
            }
            // Decode with inSampleSize option
            options.inJustDecodeBounds = false;
            options.inSampleSize = scale;

            return BitmapFactory.decodeStream(new BufferedInputStream(resolver.openInputStream(uri), 16 * 1024), null,
                    options);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            return null;
        }
    }

    public static Bitmap safeDecodeStream(InputStream is, int width, int height) throws FileNotFoundException {
        int scale = 1;
        BitmapFactory.Options options = new BitmapFactory.Options();
        // android.content.ContentResolver resolver =
        // this.ctx.getContentResolver();
        if (width > 0 || height > 0) {
            // Decode image size without loading all data into memory
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(new BufferedInputStream(is, 16 * 1024), null, options);
            int w = options.outWidth;
            int h = options.outHeight;
            while (true) {
                if ((width > 0 && w / 2 < width) || (height > 0 && h / 2 < height)) {
                    break;
                }
                w /= 2;
                h /= 2;
                scale *= 2;
            }
        }
        // Decode with inSampleSize option
        options.inJustDecodeBounds = false;
        options.inSampleSize = scale;
        return BitmapFactory.decodeStream(new BufferedInputStream(is, 16 * 1024), null, options);
    }

    public static Bitmap safeDecodeStream(String url, int width, int height) throws FileNotFoundException {
        int scale = 1;
        BitmapFactory.Options options = new BitmapFactory.Options();
        File file = new File(url);
        if (width > 0 || height > 0) {
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(new BufferedInputStream(new FileInputStream(file), 16 * 1024), null, options);
            int w = options.outWidth;
            int h = options.outHeight;
            while (true) {
                if ((width > 0 && w / 2 < width) || (height > 0 && h / 2 < height)) {
                    break;
                }
                w /= 2;
                h /= 2;
                scale *= 2;
            }
        }
        // Decode with inSampleSize option
        options.inJustDecodeBounds = false;
        options.inSampleSize = scale;
        return BitmapFactory.decodeStream(new BufferedInputStream(new FileInputStream(file), 16 * 1024), null, options);
    }

    public static void deleteSubFile(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            if (file.isFile()) {
                file.delete();
            } else if (file.isDirectory()) {
                File files[] = file.listFiles();
                for (int i = 0; i < files.length; i++) {
                    deleteSubFile(files[i].getAbsolutePath());
                }
            }
        }
    }

    /**
     * 获取文件夹大小
     * 1兆字节(mb)=1048576字节(b)
     *
     * @param file File实例
     * @return long
     */
    public static long getFolderSize(java.io.File file) {
        long size = 0;
        try {
            java.io.File[] fileList = file.listFiles();
            for (int i = 0; i < fileList.length; i++) {
                if (fileList[i].isDirectory()) {
                    size = size + getFolderSize(fileList[i]);
                } else {
                    size = size + fileList[i].length();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //return size/1048576;
        return size;
    }

    /**
     * 删除指定目录下文件及目录
     *
     * @param deleteThisPath
     * @param filePath
     * @return
     */
    public static void deleteFolderFile(String filePath, boolean deleteThisPath) {
        if (!TextUtils.isEmpty(filePath)) {
            try {
                File file = new File(filePath);
                if (file.isDirectory()) {// 处理目录
                    File files[] = file.listFiles();
                    for (int i = 0; i < files.length; i++) {
                        deleteFolderFile(files[i].getAbsolutePath(), true);
                    }
                }
                if (deleteThisPath) {
                    if (!file.isDirectory()) {// 如果是文件，删除
                        file.delete();
                    } else {// 目录
                        if (file.listFiles().length == 0) {// 目录下没有文件或者目录，删除
                            file.delete();
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
