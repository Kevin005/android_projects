package com.xsfuture.xsfuture2.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.me_module.ReadedBooksAllReaderResponseActivity;
import com.xsfuture.xsfuture2.bean.BookItemInfo;
import com.xsfuture.xsfuture2.util.DateUtils;
import com.xsfuture.xsfuture2.view.CircularImage;

import java.util.ArrayList;
import java.util.List;


public class MeReadedBooksAdapter extends BaseAdapter {

    private List<BookItemInfo> data;
    private LayoutInflater inflater;
    private ActivityHandlerInterface context;

    public MeReadedBooksAdapter(ActivityHandlerInterface c) {
        context = c;
        inflater = LayoutInflater.from(context.getCurrentActivity());
        data = new ArrayList<BookItemInfo>();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public BookItemInfo getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void setData(List<BookItemInfo> infos) {
        if (data == null) {
            data = new ArrayList<BookItemInfo>();
        } else {
            data.clear();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    public void addData(List<BookItemInfo> infos) {
        if (data == null) {
            data = new ArrayList<BookItemInfo>();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        final BookItemInfo item = data.get(position);
        holder = new ViewHolder();
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_me_reaed_books, null);
            holder.user_icon = (CircularImage) convertView.findViewById(R.id.user_icon);
            holder.tv_book_name = (TextView) convertView.findViewById(R.id.tv_book_name);
            holder.tv_readed_days = (TextView) convertView.findViewById(R.id.tv_readed_days);
            holder.tv_is_end = (TextView) convertView.findViewById(R.id.tv_is_end);
            holder.tv_date = (TextView) convertView.findViewById(R.id.tv_date);
            holder.img_book = (ImageView) convertView.findViewById(R.id.img_book);
            holder.line_detail = (LinearLayout) convertView.findViewById(R.id.line_detail);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.tv_book_name.setText("《" + item.getBook_name() + "》");
        holder.tv_readed_days.setText("共阅读" + String.valueOf(item.getReaded_days()) + "天");
        if (item.getProgress() == 1) {
            holder.tv_is_end.setText("完结");
        } else {
            holder.tv_is_end.setText("未完结");
        }
        holder.tv_date.setText(DateUtils.TimeStamp2MD(String.valueOf(item.getLast_date())));
        Glide.with(context.getCurrentActivity())
                .load(item.getImage())
                .placeholder(R.drawable.book_def)
                .error(R.drawable.book_def)
                .skipMemoryCache(true)//跳过内存缓存
                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                .into(holder.img_book);

        holder.line_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context.getCurrentActivity(), ReadedBooksAllReaderResponseActivity.class);
                intent.putExtra("post_id", item.getPost_id());
                intent.putExtra("book_name", item.getBook_name());
                intent.putExtra("author", item.getAuthor());
                intent.putExtra("readed_days", item.getReaded_days());
                intent.putExtra("progress", item.getProgress());
                intent.putExtra("book_img_url", item.getImage());
                context.getCurrentActivity().startActivity(intent);
            }
        });
        return convertView;
    }

    public class ViewHolder {
        public CircularImage user_icon;
        public ImageView img_book;
        public TextView tv_book_name;
        public TextView tv_readed_days;
        public TextView tv_is_end;
        public TextView tv_date;
        public LinearLayout line_detail;
    }
}
