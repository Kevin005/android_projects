package com.xsfuture.xsfuture2.base;

import android.app.Activity;
import android.os.Handler;

import com.xsfuture.xsfuture2.http.HttpState;

/**
 * BaseActivity实现的接口
 */
public interface ActivityHandlerInterface {
	Handler getHandler();
	Activity getCurrentActivity();
	HttpState getHttpState();
	void AddHttpState(HttpState state);
	void RemoveHttpState();
	int getUser_id();
	String getUser_token();
}
