package com.xsfuture.xsfuture2.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.account_module.RegisteredActivity;

@Deprecated
public class EditReadingBookInfoActivity extends FragmentActivity implements OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_edit_reading_book_info);
		initView();
	}

	private void initView(){
		Toast.makeText(this, "编辑正在读的书", Toast.LENGTH_SHORT).show();
		findViewById(R.id.login).setOnClickListener(this);
		findViewById(R.id.registered).setOnClickListener(this);
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.login:
			break;
		case R.id.registered:
			Intent intent = new Intent(this,RegisteredActivity.class);
			startActivity(intent);
			break;
		default:
			break;
		}
	}

}