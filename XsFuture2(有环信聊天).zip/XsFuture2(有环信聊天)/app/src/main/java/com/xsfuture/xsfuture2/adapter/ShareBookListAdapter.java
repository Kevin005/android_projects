package com.xsfuture.xsfuture2.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.bean.BookShareItemInfo;

import java.util.ArrayList;
import java.util.List;

public class ShareBookListAdapter extends BaseAdapter {

    private List<BookShareItemInfo> data;
    private LayoutInflater inflater;
    private Activity context;

    public ShareBookListAdapter(Activity c) {
        context = c;
        inflater = LayoutInflater.from(context);
        data = new ArrayList<BookShareItemInfo>();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public BookShareItemInfo getItem(int position) {
        return data.get(position - 1);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void setData(List<BookShareItemInfo> infos) {
        if (data == null) {
            data = new ArrayList<BookShareItemInfo>();
        } else {
            data.clear();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    public void addData(List<BookShareItemInfo> infos) {
        if (data == null) {
            data = new ArrayList<BookShareItemInfo>();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        final BookShareItemInfo itemInfo = data.get(position);
        holder = new ViewHolder();
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_share_book, null);
            holder.book_name = (TextView) convertView.findViewById(R.id.tv_book_name);
            holder.tv_author = (TextView) convertView.findViewById(R.id.tv_author);
            holder.img_book = (ImageView) convertView.findViewById(R.id.img_book);
            holder.love_name = (TextView) convertView.findViewById(R.id.love_name);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.love_name.setText(itemInfo.getSell_user_name());
        holder.book_name.setText(itemInfo.getBook_name());
        holder.tv_author.setVisibility(View.VISIBLE);
        Glide.with(context)
                .load(itemInfo.getBook_cover_url())
                .placeholder(R.drawable.book_def)
                .error(R.drawable.book_def)
                .skipMemoryCache(false)//跳过内存缓存
                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                .into(holder.img_book);
        return convertView;
    }

    public class ViewHolder {
        public TextView book_name;
        public TextView tv_author;
        public ImageView img_book;
        public TextView love_name;
    }
}
