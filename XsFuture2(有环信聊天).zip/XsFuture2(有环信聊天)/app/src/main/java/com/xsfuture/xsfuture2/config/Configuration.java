package com.xsfuture.xsfuture2.config;

import com.xsfuture.xsfuture2.util.Log;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


public class Configuration

{
	public static final String APPLICATION_SHORTCUT = "applicationShortcut";
	public static final String APPLICATION_UPGRADE = "applicationUpgrade";
	public static final String ATTEMPTS = "attempts";
	public static final String ATTEMPTS_TIME = "attemptsTime";
	public static final String CONNECT_TIMEOUT = "connectTimeout";
	public static final String COST_HINT = "costHint";
	public static final String DEBUG_LOG = "debugLog";
	public static final String DISCUSSUPLOADIMAGE_HEIGHT = "discussUploadImageHeight";
	public static final String DISCUSSUPLOADIMAGE_QUALITY = "discussUploadImageQuality";
	public static final String DISCUSSUPLOADIMAGE_WIDTH = "discussUploadImageWidth";
	public static final String ERROR_LOG = "errorLog";
	public static final String HOST = "host";
	public static final String MAINSERVER = "mainserver";
	public static final String INFO_LOG = "infoLog";
	public static final String INIT_POOL_SIZE = "initPoolSize";
	public static final String LEAVE_TIME_GAP = "leaveTimeGap";
	public static final String LOCAL_FILE_CACHE = "localFileCache";
	public static final String LOCAL_MEMORY_CACHE = "localMemoryCache";
	public static final String MAX_POOL_SIZE = "maxPoolSize";
	public static final String PARTNER = "partner";
	public static final String PRINT_LOG = "printLog";
	public static final String READ_TIMEOUT = "readTimeout";
	public static final String REQUEST_METHOD = "requestMethod";
	public static final String ROUTINE_CHECK_DELAY_TIME = "routineCheckDelayTime";
	public static final String SUB_UNION_ID = "subunionId";
	public static final String TEST_MODE = "testMode";
	public static final String UNION_ID = "unionId";
	public static final String VIEW_LOG = "viewLog";
	public static final String WARN_LOG = "warnLog";
	public static final String TEST_LOG = "testLog";
	public static final String POST = "post";

	public static final String GUANYI_URL = "guanyi_url";

	private static Map<String, String> localProperties = new HashMap<String, String>();
	private static Properties properties;

	static {
		localProperties.put("host", "10.0.18.188:8080");
		localProperties.put("mainserver", "/MassageServerService");
		// localProperties.put("mainserver", "");

		localProperties.put("connectTimeout", "20000");
		localProperties.put("readTimeout", "20000");
		localProperties.put("attempts", "2");
		localProperties.put("attemptsTime", "0");
		localProperties.put("requestMethod", "post");
		localProperties.put("localMemoryCache", "false");
		localProperties.put("localFileCache", "false");
		localProperties.put("initPoolSize", "5");
		localProperties.put("maxPoolSize", "5");
		localProperties.put("discussUploadImageWidth", "500");
		localProperties.put("discussUploadImageHeight", "500");
		localProperties.put("discussUploadImageQuality", "80");
		localProperties.put("routineCheckDelayTime", "2000");
		localProperties.put("leaveTimeGap", "3600000");
		localProperties.put("printLog", "true");
		localProperties.put("debugLog", "true");
		localProperties.put("viewLog", "true");
		localProperties.put("errorLog", "true");
		localProperties.put("infoLog", "true");
		localProperties.put("warnLog", "false");
		localProperties.put("testLog", "false");
		localProperties.put("testMode", "false");
		localProperties.put("partner", "guanyi");
		localProperties.put("unionId", null);
		localProperties.put("subunionId", null);
		localProperties.put("applicationUpgrade", "true");
		localProperties.put("applicationShortcut", "false");
		localProperties.put("costHint", "false");
		try {
			InputStream localInputStream = Configuration.class.getClassLoader()
					.getResourceAsStream("config.properties");
			if (localInputStream != null) {
				properties = new Properties();
				properties.load(localInputStream);
			}
		} catch (Exception e) {
			if (Log.E)
				Log.e("", e.toString());
		}
	}

	public static Boolean getBooleanProperty(String paramString) {
		return getBooleanProperty(paramString, null);
	}

	public static Boolean getBooleanProperty(String name, Boolean paramBoolean) {
		String str = getProperty(name);
		Boolean localBoolean = null;
		if (str == null) {
			localBoolean = paramBoolean;
		} else {
			try {
				localBoolean = Boolean.valueOf(str);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return localBoolean;
	}

	public static Integer getIntegerProperty(String paramString) {
		return getIntegerProperty(paramString, null);
	}

	public static Integer getIntegerProperty(String name, Integer paramInteger) {
		String str = getProperty(name);
		Integer localInteger = null;
		if (str == null) {
			localInteger = paramInteger;
		} else {
			try {
				localInteger = Integer.valueOf(str);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return localInteger;
	}

	public static String getProperty(String name) {
		return getProperty(name, null);
	}

	public static String getProperty(String name, String dafaultName) {
		String str = null;
		if (properties != null)
			str = properties.getProperty(name);
		if (str == null)
			str = (String) localProperties.get(name);
		if (str == null)
			str = dafaultName;
		return str;
	}
}
