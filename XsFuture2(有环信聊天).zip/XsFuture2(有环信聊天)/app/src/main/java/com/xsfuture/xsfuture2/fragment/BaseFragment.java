package com.xsfuture.xsfuture2.fragment;


import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.xsfuture.xsfuture2.base.FrameMainActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.config.ConstSysConfig;

public abstract class BaseFragment extends Fragment {
	private FrameMainActivity currentActivity;
	private TextView tvPageTitle;
	protected Button btnTitleRight;
	protected TextView new_message_num;

	private SharedPreferences sharedPreferences;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = setCurrentContentView(inflater, container);
		sharedPreferences = view.getContext().getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0);
		initTitleBar(view);
		init(view, savedInstanceState);
		return view;
	}

	private void initTitleBar(View view) {
		tvPageTitle = (TextView) view.findViewById(R.id.title_text);
		btnTitleRight = (Button) view.findViewById(R.id.right_btn);
		new_message_num = (TextView) view.findViewById(R.id.new_message_num);
	}

	public void setPageTitle(String s) {
		tvPageTitle.setText(s);
	}

	public void setPageTitle(int id) {
		tvPageTitle.setText(id);
	}

	public String getPageTitle() {
		return tvPageTitle.getText().toString().trim();
	}

	/**
	 * 设置右键类型与事件，用于非文字的图标按钮
	 *
	 * @param listener
	 */
	public void setImageTitleBtnRight(int imageId, View.OnClickListener listener) {
		// 先将该按钮设为可见
		btnTitleRight.setVisibility(View.VISIBLE);
		Drawable drawable = getCurrentActivity().getResources().getDrawable(imageId);
		drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
		btnTitleRight.setCompoundDrawables(drawable, null, null, null);
		// 设置点击事件
		btnTitleRight.setOnClickListener(listener);
	}

	protected abstract View setCurrentContentView(LayoutInflater inflater, ViewGroup container);

	protected abstract void init(View view, Bundle savedInstanceState);

	public boolean getBooleanFromPreference(String s) {
		return sharedPreferences.getBoolean(s, false);
	}

	public boolean getBooleanFromPreference(String s, boolean flag) {
		return sharedPreferences.getBoolean(s, flag);
	}

	public String getStringFromPreference(String s) {
		return sharedPreferences.getString(s, "");
	}

	public void removeStringFromPreference(String s) {
		sharedPreferences.edit().remove(s);
	}

	public String getStringFromPreference(String s, String defaultValue) {
		return sharedPreferences.getString(s, defaultValue);
	}

	public void putBooleanToPreference(String s, Boolean boolean1) {
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putBoolean(s, boolean1.booleanValue()).commit();
	}

	public void putStringToPreference(String s, String s1) {
		sharedPreferences.edit().putString(s, s1).commit();
	}

	/** 返回FraeActivity是因为它实现了ActivityHandlerInterface */
	public FrameMainActivity getCurrentActivity() {
		return currentActivity;
	}

	/** 返回FraeActivity是因为它实现了ActivityHandlerInterface */
	public void setCurrentActivity(FrameMainActivity currentActivity) {
		this.currentActivity = currentActivity;
	}

}
