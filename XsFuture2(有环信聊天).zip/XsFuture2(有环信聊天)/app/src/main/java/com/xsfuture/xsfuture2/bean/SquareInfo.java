package com.xsfuture.xsfuture2.bean;

import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.util.StringUtils;

/**
 * Created by Kevin on 2016/10/10.
 */
public class SquareInfo {
    private int readed_page_number;
    private boolean is_on;
    private String book_name;
    private int user_id;
    private int time_stamp;
    private String nick_name;
    private int post_id;
    private double progress;
    private int reader_response_id;
    private int readed_days;
    private String content;
    private String user_name;
    private String push_time;
    private int gender;
    private String user_image;
    private String book_image;
    private int rr_favor_total;
    private int rr_comment_total;
    private String author;
    private boolean is_favored;

    public boolean is_favored() {
        return is_favored;
    }

    public void setIs_favored(boolean is_favored) {
        this.is_favored = is_favored;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getRr_favor_total() {
        return rr_favor_total;
    }

    public void setRr_favor_total(int rr_favor_total) {
        this.rr_favor_total = rr_favor_total;
    }

    public int getRr_comment_total() {
        return rr_comment_total;
    }

    public void setRr_comment_total(int rr_comment_total) {
        this.rr_comment_total = rr_comment_total;
    }

    public boolean is_on() {
        return is_on;
    }

    public void setIs_on(boolean is_on) {
        this.is_on = is_on;
    }

    public int getReaded_page_number() {
        return readed_page_number;
    }

    public void setReaded_page_number(int readed_page_number) {
        this.readed_page_number = readed_page_number;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getTime_stamp() {
        return time_stamp;
    }

    public void setTime_stamp(int time_stamp) {
        this.time_stamp = time_stamp;
    }

    public String getNick_name() {
        return nick_name;
    }

    public void setNick_name(String nick_name) {
        this.nick_name = nick_name;
    }

    public int getPost_id() {
        return post_id;
    }

    public void setPost_id(int post_id) {
        this.post_id = post_id;
    }

    public double getProgress() {
        return progress;
    }

    public void setProgress(double progress) {
        this.progress = progress;
    }

    public int getReader_response_id() {
        return reader_response_id;
    }

    public void setReader_response_id(int reader_response_id) {
        this.reader_response_id = reader_response_id;
    }

    public int getReaded_days() {
        return readed_days;
    }

    public void setReaded_days(int readed_days) {
        this.readed_days = readed_days;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getPush_time() {
        return push_time;
    }

    public void setPush_time(String push_time) {
        this.push_time = push_time;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }


    public String getUser_image() {
        if (!StringUtils.isEmpty(user_image) && user_image.contains("http://115.28.56.168")) {
            return user_image;
        }
        return ConstHttpProp.img_base_url + user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getBook_image() {
        return book_image;
    }

    public void setBook_image(String book_image) {
        this.book_image = book_image;
    }


}
