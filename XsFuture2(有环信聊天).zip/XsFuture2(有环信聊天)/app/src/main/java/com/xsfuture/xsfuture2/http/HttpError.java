package com.xsfuture.xsfuture2.http;

public class HttpError {
	
	public static final int NONetworkError = 101;
	public static final int RequestError = 102;
	private int errorCode;
	private String message;

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
