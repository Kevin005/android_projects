package com.xsfuture.xsfuture2.task;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.google.gson.Gson;
import com.xsfuture.xsfuture2.bean.BookInfo;
import com.xsfuture.xsfuture2.bean.BookListInfo;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class LoadDoubanBookInfoTask {
    public static String Download(String urlstr) {
        String result = "";
        try {
            URL url = new URL(urlstr);
            URLConnection connection = url.openConnection();

            String line;
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public BookInfo parseBookInfo(String str) {
        BookInfo info = null;
        try {
            info = new Gson().fromJson(str, BookInfo.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return info;
    }

    public BookListInfo parseBookListInfo(String str) {
        BookListInfo info = null;
        try {
            info = new Gson().fromJson(str, BookListInfo.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return info;
    }
}
