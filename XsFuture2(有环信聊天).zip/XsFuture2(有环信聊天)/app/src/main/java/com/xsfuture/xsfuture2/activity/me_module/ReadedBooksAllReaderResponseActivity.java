package com.xsfuture.xsfuture2.activity.me_module;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.adapter.PersonalAllJournalEntryAdapter;
import com.xsfuture.xsfuture2.bean.MyReaderResponseDetails;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.view.xlistview.XListView;

import org.json.JSONException;

import java.text.NumberFormat;
import java.util.List;

public class ReadedBooksAllReaderResponseActivity extends BaseActivity implements XListView.IXListViewListener {
    private XListView xlV_personal_all_journal_entry;
    private PersonalAllJournalEntryAdapter adapter;

    private int post_id;
    private String book_name;
    private String author;
    private int readed_days;
    private double progress;
    private String book_img_url;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_readed_books_all_reader_response);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        initData();
        setTitleText("《" + book_name + "》");
        setTitleLeftBtn(R.string.back, new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        setTitleBtnRight(R.string.setting, 0, new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), ReadedBookStateSettingActivity.class);
                intent.putExtra("book_name", book_name);
                intent.putExtra("post_id", post_id);
                startActivity(intent);
            }
        });
        initView();
    }

    private void initData() {
        post_id = getIntent().getIntExtra("post_id", 0);
        book_name = getIntent().getStringExtra("book_name");
        author = getIntent().getStringExtra("author");
        readed_days = getIntent().getIntExtra("readed_days", 0);
        progress = getIntent().getDoubleExtra("progress", 0);
        book_img_url = getIntent().getStringExtra("book_img_url");
    }

    private void initView() {
        xlV_personal_all_journal_entry = (XListView) findViewById(R.id.xlV_personal_all_journal_entry);
        xlV_personal_all_journal_entry.setPullRefreshEnable(true);
        xlV_personal_all_journal_entry.setPullLoadEnable(false);
        xlV_personal_all_journal_entry.setXListViewListener(this);
        adapter = new PersonalAllJournalEntryAdapter(getCurrentActivity());
        xlV_personal_all_journal_entry.setAdapter(adapter);
        View headerView = addListViewHeader();
        xlV_personal_all_journal_entry.addHeaderView(headerView);
        readerResponse("desc", true);
    }

    private View addListViewHeader() {
        View headView = LayoutInflater.from(this).inflate(R.layout.headerview__basic_info_of_book, null);
        ImageView img_book = (ImageView) headView.findViewById(R.id.img_book);
        Glide.with(getCurrentActivity())
                .load(book_img_url)
                .placeholder(R.drawable.book_def)
                .error(R.drawable.book_def)
                .skipMemoryCache(true)//跳过内存缓存
                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                .into(img_book);
        TextView tv_book_name = (TextView) headView.findViewById(R.id.tv_book_name);
        tv_book_name.setText("《" + book_name + "》");
        TextView tv_athor = (TextView) headView.findViewById(R.id.tv_athor);
        tv_athor.setText(author);
        TextView tv_reading_days = (TextView) headView.findViewById(R.id.tv_reading_days);
        tv_reading_days.setText("共阅读" + readed_days + "天");
        TextView tv_progress = (TextView) headView.findViewById(R.id.tv_progress);
        NumberFormat fmt = NumberFormat.getPercentInstance();
        fmt.setMaximumFractionDigits(2);
        String progressStr = fmt.format(progress);
        tv_progress.setText("已读" + progressStr);
        return headView;
    }

    private void readerResponse(String order, boolean is_show) {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("post_id", post_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                onXListViewStop();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONArrayPoxy data = jSONObjectProxy.getJSONArrayOrNull("data");
                    if (success == 0 && data != null) {
                        if (data.length() > 0) {
                            Gson gson = new Gson();
                            List<MyReaderResponseDetails> datas = gson.fromJson(data.toString(),
                                    new TypeToken<List<MyReaderResponseDetails>>() {
                                    }.getType());
                            adapter.setData(datas);
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), "网络连接错误，请稍后再试！", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(is_show);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_post_getReaderResponseList + "?order=" + order);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    @Override
    public void onRefresh() {
        readerResponse("desc", false);
    }

    @Override
    public void onLoadMore() {
    }

    @Override
    public void onXListViewStop() {
        xlV_personal_all_journal_entry.stopLoadMore();
        xlV_personal_all_journal_entry.stopRefresh();
    }
}