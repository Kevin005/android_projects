package com.xsfuture.xsfuture2.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.bean.SquareInfo;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.activity.account_module.LoginActivity;
import com.xsfuture.xsfuture2.activity.main_module.JournalEntryDetailsActiviy;
import com.xsfuture.xsfuture2.activity.presenter.eventbus_module.IntentId;
import com.xsfuture.xsfuture2.util.DateUtils;
import com.xsfuture.xsfuture2.util.StringUtils;
import com.xsfuture.xsfuture2.view.CircularImage;
import com.xsfuture.xsfuture2.view.GenderSelectorImage;
import com.xsfuture.xsfuture2.view.RoundImageView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;


public class FollowAnotherAdapter extends BaseAdapter {

    private List<SquareInfo> data;
    private LayoutInflater inflater;
    private ActivityHandlerInterface context;

    public FollowAnotherAdapter(ActivityHandlerInterface context) {
        this.context = context;
        inflater = LayoutInflater.from(context.getCurrentActivity());
        data = new ArrayList<SquareInfo>();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public SquareInfo getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void addData(List<SquareInfo> new_data) {
        if (data == null) {
            data = new ArrayList<SquareInfo>();
        }
        if (new_data != null && new_data.size() > 0) {
            data.addAll(new_data);
            notifyDataSetChanged();
        }
    }

    public void setData(List<SquareInfo> new_data) {
        if (data == null) {
            data = new ArrayList<SquareInfo>();
        } else {
            data.clear();
        }
        if (new_data != null && new_data.size() > 0) {
            data.addAll(new_data);
        }
        notifyDataSetChanged();
    }

    public List<SquareInfo> getData() {
        return data;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        final SquareInfo item = data.get(position);
        holder = new ViewHolder();
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_follow_another, null);
            holder.line_dynamic = (LinearLayout) convertView.findViewById(R.id.line_dynamic);
            holder.love_name = (TextView) convertView.findViewById(R.id.love_name);
            holder.love_book_name = (TextView) convertView.findViewById(R.id.love_book_name);
            holder.love_progress = (TextView) convertView.findViewById(R.id.love_progress);
            holder.love_content = (TextView) convertView.findViewById(R.id.love_content);
            holder.love_post_time = (TextView) convertView.findViewById(R.id.love_post_time);
            holder.cirimg_icon_patient = (CircularImage) convertView.findViewById(R.id.cirimg_icon_patient);
            holder.img_gender_selector = (GenderSelectorImage) convertView.findViewById(R.id.img_gender_selector);
            holder.tv_favor_total = (TextView) convertView.findViewById(R.id.tv_favor_total);
            holder.tv_comment_total = (TextView) convertView.findViewById(R.id.tv_comment_total);
            holder.img_favor = (ImageView) convertView.findViewById(R.id.img_favor);
            holder.img_item_img = (RoundImageView) convertView.findViewById(R.id.img_item_img);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        if (item != null) {
            if (item.getGender() == 1) {
                holder.img_gender_selector.setWomanMark();
            } else {
                holder.img_gender_selector.setManMark();
            }
            if (item.is_favored()) {
                holder.img_favor.setImageResource(R.drawable.favored);
                holder.tv_favor_total.setTextColor(context.getCurrentActivity().getResources().getColor(R.color.main_color));
            } else {
                holder.img_favor.setImageResource(R.drawable.favor);
                holder.tv_favor_total.setTextColor(context.getCurrentActivity().getResources().getColor(R.color.item_text_color));
            }
            Glide.with(context.getCurrentActivity())
                    .load(item.getUser_image())
                    .placeholder(R.drawable.avatar)
                    .error(R.drawable.avatar)
                    .skipMemoryCache(true)//跳过内存缓存
                    .diskCacheStrategy(DiskCacheStrategy.RESULT)
                    .into(holder.cirimg_icon_patient);

            holder.love_name.setText(item.getNick_name());
            holder.love_book_name.setText("《" + item.getBook_name() + "》");
            NumberFormat fmt = NumberFormat.getPercentInstance();
            String progressStr = fmt.format(item.getProgress());
            fmt.setMaximumFractionDigits(2);
            holder.love_progress.setText(progressStr + "已读/第" + item.getReaded_days() + "天");

            List<String> img_list = new ArrayList<String>();
            StringBuffer txt_str = new StringBuffer();
            String[] str_array = item.getContent().split("@xiaoshi@");
            for (String str : str_array) {
                if (str.contains("http://115.28.56.168") || str.contains("https://115.28.56.168")) {
                    if (StringUtils.isEmpty(str)) {
                        continue;
                    } else {
                        img_list.add(str);
                    }
                } else {
                    if (StringUtils.isEmpty(str)) {
                        continue;
                    } else {
                        txt_str.append(str);
                    }
                }
            }
            //set img
            if (img_list != null && img_list.size() > 0) {
                holder.img_item_img.setVisibility(View.VISIBLE);
                Glide.with(context.getCurrentActivity())
                        .load(img_list.get(0))
                        .placeholder(R.mipmap.item_reader_response)
                        .error(R.mipmap.item_reader_response)
                        .skipMemoryCache(true)//跳过内存缓存
                        .diskCacheStrategy(DiskCacheStrategy.RESULT)
                        .into(holder.img_item_img);
            } else {
                holder.img_item_img.setVisibility(View.GONE);
            }
            //set txt
            holder.love_content.setText(txt_str.toString());
            holder.love_post_time.setText(DateUtils.TimeStamp2Date(String.valueOf(item.getTime_stamp())));
            holder.tv_favor_total.setText(String.valueOf(item.getRr_favor_total()));
            holder.tv_comment_total.setText(String.valueOf(item.getRr_comment_total()));
        }
        holder.line_dynamic.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLogined()) {
                    Intent intent = new Intent(context.getCurrentActivity(), JournalEntryDetailsActiviy.class);
                    // 用户信息
                    intent.putExtra("user_name", item.getNick_name());
                    intent.putExtra("is_on", item.is_on());
                    intent.putExtra("user_id", item.getUser_id());
                    // 书籍信息
                    intent.putExtra("post_id", item.getPost_id());
                    intent.putExtra("book_name", item.getBook_name());
                    intent.putExtra("progress", item.getProgress());
                    intent.putExtra("reading_days", item.getReaded_days());
                    intent.putExtra("author", item.getAuthor());
                    // 读后感信息
                    intent.putExtra("timestamp", item.getTime_stamp());
                    intent.putExtra("readed_pagenumber", item.getReaded_page_number());
                    intent.putExtra("content", item.getContent());
                    intent.putExtra("user_image", item.getUser_image());
                    intent.putExtra("book_image", item.getBook_image());
                    intent.putExtra("nick_name", item.getNick_name());
                    intent.putExtra("favor_tatal", item.getRr_favor_total());
                    intent.putExtra("comment_total", item.getRr_comment_total());
                    intent.putExtra("reader_response_id", item.getReader_response_id());
                    intent.putExtra("is_favored", item.is_favored());
                    intent.putExtra("class_name_flag", IntentId.INTENT_TO_FOLLOW_FRAGMENT);
                    context.getCurrentActivity().startActivity(intent);
                } else {
                    Intent intent = new Intent(context.getCurrentActivity(), LoginActivity.class);
                    context.getCurrentActivity().startActivity(intent);
                }
            }
        });
        return convertView;
    }

    public class ViewHolder {
        LinearLayout line_dynamic;// 关注的人动态
        TextView love_name;
        TextView love_book_name;
        TextView love_progress;
        TextView love_content;
        TextView love_post_time;
        CircularImage cirimg_icon_patient;
        GenderSelectorImage img_gender_selector;
        TextView tv_favor_total;
        TextView tv_comment_total;
        ImageView img_favor;
        RoundImageView img_item_img;
    }

    private boolean isLogined() {
        String token = context.getCurrentActivity().getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0).getString("token", "");
        if (StringUtils.isEmpty(token)) {
            return false;
        }
        return true;
    }

}
