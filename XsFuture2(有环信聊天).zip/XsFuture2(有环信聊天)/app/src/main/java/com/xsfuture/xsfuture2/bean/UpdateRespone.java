package com.xsfuture.xsfuture2.bean;

/**
 * Created by changtaoxie on 16/10/29.
 */
public class UpdateRespone {
    /**
     * release_note : 1.亲爱的书友们，这次我们增加了升级功能
     * version_name : 1.2.6
     * download_url : http://115.28.56.168:8000/media/apk/xiaoshi__1__1.2.6.apk
     * package_size : 0
     * is_force_update : true
     */

    private String release_note;
    private String version_name;
    private String download_url;
    private String package_size;
    private boolean is_force_update;

    public String getRelease_note() {
        return release_note;
    }

    public void setRelease_note(String release_note) {
        this.release_note = release_note;
    }

    public String getVersion_name() {
        return version_name;
    }

    public void setVersion_name(String version_name) {
        this.version_name = version_name;
    }

    public String getDownload_url() {
        return download_url;
    }

    public void setDownload_url(String download_url) {
        this.download_url = download_url;
    }

    public String getPackage_size() {
        return package_size;
    }

    public void setPackage_size(String package_size) {
        this.package_size = package_size;
    }

    public boolean isIs_force_update() {
        return is_force_update;
    }

    public void setIs_force_update(boolean is_force_update) {
        this.is_force_update = is_force_update;
    }

    @Override
    public String toString() {
        return "UpdateRespone{" +
                "release_note='" + release_note + '\'' +
                ", version_name='" + version_name + '\'' +
                ", download_url='" + download_url + '\'' +
                ", package_size='" + package_size + '\'' +
                ", is_force_update=" + is_force_update +
                '}';
    }
}
