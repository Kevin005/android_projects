package com.xsfuture.xsfuture2.config;

public class ConstSysConfig {

	public static final String dbName = "xsfuture.db";
	public static final String rootFilePath = "xsfuture";
	public static final String baseUrl = "";
	/** mob app sms key */
	public static final String MOB_APP_KEY = "142a2638de420";
	/** mob app sms secret */
	public static final String MOB_APP_SECRET = "7b21825e908d9fb718eb4aec8e108090";
	/** baidu push API KEY TODO 临时 */
	public static final String BAIDU_PUSH_API_KEY = "Bea5Bd81MbtEUTyxEWcI8G6b";
	/** baidu character recognize AK */
	public static final String BAIDU_CHARACTER_RECOGNIZE_AK = "Ql0Oae0Lw8PmvmYGQ61N6B81";
	/** baidu character recognize SK */
	public static final String BAIDU_CHARACTER_RECOGNIZE_SK = "ULkm6hcnlKwRXWLEZ8noP0pfbuFX3hX8";

	public static final String KEY_DEVICE_ID = "device_id";
	public static final String SYS_CUST_CLIENT = "androidClient";//about general parameters
	public static final String UPDATE_PLATFORM = "downloadplato";//about update parameters
	public static final String SYS_MESSAGE = "system_message";//about message parameters

	/** allow{@link ConstSysConfig#SYS_CUST_CLIENT} */
	public static final String SOFTWARE_UPDATE = "software_update";// 检查版本时间，版本检查规则，自动登录，每天检查一次，登录的时候强制检查一次
    /** allow{@link ConstSysConfig#SYS_MESSAGE} */
    public static final String IS_NO_READ_COMMENT_MESSAGE = "is_no_read_comment_message";
	/** allow{@link ConstSysConfig#SYS_MESSAGE} */
	public static final String BAIDU_PUSH_CHANNLE_ID = "baidu_push_channle_id";
    //param end
}
