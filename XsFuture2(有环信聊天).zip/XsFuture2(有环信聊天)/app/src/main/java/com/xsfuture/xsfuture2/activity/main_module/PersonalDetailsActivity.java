package com.xsfuture.xsfuture2.activity.main_module;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.PersonalDetailMyBooksAdapter;
import com.xsfuture.xsfuture2.adapter.PersonalDetailMyFansAdapter;
import com.xsfuture.xsfuture2.adapter.PersonalDetailPagerAdapter;
import com.xsfuture.xsfuture2.bean.BookItemInfo;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.view.xlistview.XListView;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class PersonalDetailsActivity extends BaseActivity {
    private ImageView user_avatar;
    private ViewPager mPager;
    private ArrayList<View> viewsList;
    private XListView listView1;
    private XListView listView2;
    private XListView listView3;
    private PersonalDetailMyBooksAdapter adapter1;
    private PersonalDetailMyBooksAdapter adapter2;
    private PersonalDetailMyFansAdapter adapter3;
    private ImageView ivBottomLine;
    private TextView tv_tab_1;
    private TextView tv_tab_2;
    private TextView tv_tab_3;
    private TextView userName;

    public final static int num = 3;
    private int bmpW;// 动画图片宽度
    private int currIndex = 0;
    private int offset = 0;
    private String user_name;
    private String nick_name;
    private String user_image;
    private int user_id;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_personal_details);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleText(user_name);
        setTitleLeftBtn(R.string.back, new OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initExtraData();
        initView();
    }

    private void initExtraData() {
        user_id = getIntent().getIntExtra("user_id", 0);
        user_name = getIntent().getStringExtra("user_name");
        nick_name = getIntent().getStringExtra("nick_name");
        user_image = getIntent().getStringExtra("user_image");
    }

    private void initView() {
        userName = (TextView) findViewById(R.id.userName);
        userName.setText(nick_name);
        user_avatar = (ImageView) findViewById(R.id.user_avatar);
        Glide.with(getCurrentActivity())
                .load(user_image)
                .placeholder(R.drawable.avatar)
                .error(R.drawable.avatar)
                .skipMemoryCache( true )//跳过内存缓存
                .diskCacheStrategy( DiskCacheStrategy.RESULT )
                .into(user_avatar);

        InitWidth();
        InitTextView();
        InitViewPager();
    }

    private void InitTextView() {
        tv_tab_1 = (TextView) findViewById(R.id.reading_book);
        tv_tab_2 = (TextView) findViewById(R.id.readed_book);
        tv_tab_3 = (TextView) findViewById(R.id.personal_fans);
        tv_tab_1.setOnClickListener(new MyOnClickListener(0));
        tv_tab_2.setOnClickListener(new MyOnClickListener(1));
        tv_tab_3.setOnClickListener(new MyOnClickListener(2));
    }

    private void InitViewPager() {
        mPager = (ViewPager) findViewById(R.id.viewpager_person_tab);
        viewsList = new ArrayList<View>();
        listView1 = (XListView) getLayoutInflater().inflate(R.layout.view_personal_detail_viewpager_list, null);
        listView2 = (XListView) getLayoutInflater().inflate(R.layout.view_personal_detail_viewpager_list, null);
        listView3 = (XListView) getLayoutInflater().inflate(R.layout.view_personal_detail_viewpager_list, null);
        initListView();
        viewsList.add(listView1);
        viewsList.add(listView2);
        viewsList.add(listView3);

        mPager.setAdapter(new PersonalDetailPagerAdapter(viewsList));
        mPager.setOnPageChangeListener(new MyOnPageChangeListener());
        mPager.setCurrentItem(0);
        tv_tab_1.setTextColor(getResources().getColor(R.color.title_main_text_color));
    }

    private void initListView() {
        listView1.setPullRefreshEnable(true);
        listView1.setPullLoadEnable(false);
        listView1.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                onXListViewStop();
            }

            @Override
            public void onLoadMore() {
            }

            @Override
            public void onXListViewStop() {
                listView1.stopRefresh();
                listView1.stopLoadMore();
            }
        });
        adapter1 = new PersonalDetailMyBooksAdapter(getCurrentActivity());
        listView1.setAdapter(adapter1);
        readingBooks();

        listView2.setPullRefreshEnable(true);
        listView2.setPullLoadEnable(false);
        listView2.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                onXListViewStop();
            }

            @Override
            public void onLoadMore() {
            }

            @Override
            public void onXListViewStop() {
                listView2.stopRefresh();
                listView2.stopLoadMore();
            }
        });
        adapter2 = new PersonalDetailMyBooksAdapter(getCurrentActivity());
        listView2.setAdapter(adapter2);

        listView3.setPullRefreshEnable(true);
        listView3.setPullLoadEnable(false);
        listView3.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                onXListViewStop();
            }

            @Override
            public void onLoadMore() {
            }

            @Override
            public void onXListViewStop() {
                listView3.stopRefresh();
                listView3.stopLoadMore();
            }
        });
        adapter3 = new PersonalDetailMyFansAdapter(getCurrentActivity());
        listView3.setAdapter(adapter3);
    }

    private void InitWidth() {
        ivBottomLine = (ImageView) findViewById(R.id.personal_details_bottom_line);
        bmpW = ivBottomLine.getLayoutParams().width;// 获取图片宽度
        DisplayMetrics dm = new DisplayMetrics();
        getCurrentActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenW = dm.widthPixels;// 获取分辨率宽度
        offset = (screenW / 3 - bmpW) / 2;// 计算偏移量
        TranslateAnimation animation = new TranslateAnimation(offset, offset, 0, 0);
        animation.setFillAfter(true);
        animation.setDuration(0);
        ivBottomLine.startAnimation(animation);
    }

    public class MyOnClickListener implements OnClickListener {
        private int index = 0;

        public MyOnClickListener(int i) {
            index = i;
        }

        @Override
        public void onClick(View v) {
            mPager.setCurrentItem(index);
        }
    }

    ;

    public class MyOnPageChangeListener implements OnPageChangeListener {

        int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量
        int two = one * 2;// 页卡1 -> 页卡3 偏移量

        public void onPageScrollStateChanged(int arg0) {
        }

        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        @Override
        public void onPageSelected(final int arg0) {
            switch (arg0) {
                case 0:
                    readingBooks();
                    break;
                case 1:
                    finishReaded();
                    break;
                case 2:
                    fans();
                    break;
                default:
                    break;
            }
            Animation animation = new TranslateAnimation(one * currIndex + offset, one * arg0 + offset, 0, 0);
            currIndex = arg0;
            animation.setFillAfter(true);// true:图片停在动画结束位置
            animation.setDuration(150);
            ivBottomLine.startAnimation(animation);
            animation.setAnimationListener(new AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                }

                @Override
                public void onAnimationRepeat(Animation animation) {
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    setTextColor(arg0);
                }
            });
        }
    }

    private void setTextColor(int selectTag) {
        switch (selectTag) {
            case 0:
                tv_tab_1.setTextColor(getResources().getColor(R.color.title_main_text_color));
                tv_tab_2.setTextColor(getResources().getColor(R.color.item_text_color));
                tv_tab_3.setTextColor(getResources().getColor(R.color.item_text_color));
                break;
            case 1:
                tv_tab_1.setTextColor(getResources().getColor(R.color.item_text_color));
                tv_tab_2.setTextColor(getResources().getColor(R.color.title_main_text_color));
                tv_tab_3.setTextColor(getResources().getColor(R.color.item_text_color));
                break;
            case 2:
                tv_tab_1.setTextColor(getResources().getColor(R.color.item_text_color));
                tv_tab_2.setTextColor(getResources().getColor(R.color.item_text_color));
                tv_tab_3.setTextColor(getResources().getColor(R.color.title_main_text_color));
                break;
            default:
                break;
        }
    }

    private void readingBooks() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("user_id", user_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                listView1.stopRefresh();
                listView1.stopLoadMore();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONArrayPoxy data = jSONObjectProxy.getJSONArrayOrNull("data");
                    if (success == 0 && data != null) {
                        List<BookItemInfo> infos = new Gson().fromJson(data.toString(), new TypeToken<List<BookItemInfo>>() {
                        }.getType());
                        adapter1.setData(infos);
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_post_getreadedbooks + "?offset=" + 0 + "&limit=" + 1000
                + "&is_finished=" + 0);
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpTask.executes(httpSetting);
    }

    private void finishReaded() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("user_id", user_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                listView2.stopRefresh();
                listView2.stopLoadMore();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONArrayPoxy data = jSONObjectProxy.getJSONArrayOrNull("data");
                    if (success == 0 && data != null) {
                        List<BookItemInfo> infos = new Gson().fromJson(data.toString(), new TypeToken<List<BookItemInfo>>() {
                        }.getType());
                        adapter2.setData(infos);
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_post_getreadedbooks + "?offset=" + 0 + "&limit=" + 1000
                + "&is_finished=yes");
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpTask.executes(httpSetting);
    }

    private void fans() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("user_id", user_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                listView3.stopRefresh();
                listView3.stopLoadMore();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONArrayPoxy data = jSONObjectProxy.getJSONArrayOrNull("data");
                    if (success == 0 && data != null) {
                        List<UserInfo> infos = new Gson().fromJson(data.toString(), new TypeToken<List<UserInfo>>() {
                        }.getType());
                        adapter3.setData(infos);
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_friends_fans + "?on_type=fans");
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpTask.executes(httpSetting);
    }

    @Override
    protected boolean setGesturesTracker() {
        return false;
    }
}
