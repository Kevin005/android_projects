package com.xsfuture.xsfuture2.bean;

import android.text.TextUtils;

import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.util.StringUtils;

public class UserInfo {
    private int user_id;
    private String user_name;
    private int age;
    private String nick_name;
    private String phone_number;
    private String password;
    private int gender;
    private int group_id;
    private String create_time;
    private String update_time;
    private int point;
    private String token;
    private String avatar_url;
    private String image;//人物头像

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getNick_name() {
        if (TextUtils.isEmpty(nick_name))
            return "";
        return nick_name;
    }

    public void setNick_name(String nick_name) {
        this.nick_name = nick_name;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public int getGroup_id() {
        return group_id;
    }

    public void setGroup_id(int group_id) {
        this.group_id = group_id;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public int getPoint() {
        return point;
    }

    public void setPoint(int point) {
        this.point = point;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getAvatar_url() {
        return avatar_url;
    }

    public void setAvatar_url(String avatar_url) {
        this.avatar_url = avatar_url;
    }

    public String getImage() {
        if (!StringUtils.isEmpty(image) && image.contains("http://115.28.56.168")) {//full path
            return image;
        }
        return ConstHttpProp.img_base_url + image;
    }

    public void setImage(String image) {
        this.image = image;
    }


}
