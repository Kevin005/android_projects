package com.xsfuture.xsfuture2.activity.presenter;

import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hyphenate.EMCallBack;
import com.hyphenate.chat.EMClient;
import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.main_module.MainActivity;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.database.UserInfoDBHelper;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.EncodeUtils;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.Log;

import org.json.JSONException;

/**
 * Created by Kevin on 2016/11/22.
 */
public class LoginActivityPresenter {
    private final String TAG = LoginActivityPresenter.class.getName();
    private ActivityHandlerInterface context;

    public LoginActivityPresenter(ActivityHandlerInterface context) {
        this.context = context;
    }

    public void login(LoginInfo info) {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("phone_number", info.getPhone_input());
            obj.put("user_name", info.getPhone_input());
            String sha1Str = EncodeUtils.shaEncrypt(info.getPwd_input());//sha1密文
            obj.put("password", sha1Str);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(context) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONObjectProxy data = jSONObjectProxy.getJSONObjectOrNull("data");
                    if (success == 0 && data != null) {
//                        em_loagin(data.toString());
                        final UserInfo userInfo = new Gson().fromJson(data.toString(), new TypeToken<UserInfo>() {
                        }.getType());
                        UserInfoDBHelper.insertUser(userInfo, context.getCurrentActivity());// 初始化user表
                        insertUserShare(userInfo);// 初始化share值
                        Intent intent = new Intent(context.getCurrentActivity(), MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        context.getCurrentActivity().startActivity(intent);
                        context.getCurrentActivity().finish();
                    } else {
                        Toast.makeText(context.getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(context.getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.user_login);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    public class LoginInfo {
        public String getPhone_input() {
            return phone_input;
        }

        public void setPhone_input(String phone_input) {
            this.phone_input = phone_input;
        }

        public String getPwd_input() {
            return pwd_input;
        }

        public void setPwd_input(String pwd_input) {
            this.pwd_input = pwd_input;
        }

        public String phone_input;
        public String pwd_input;
    }

    private void em_loagin(final String data) {
        final UserInfo userInfo = new Gson().fromJson(data.toString(), new TypeToken<UserInfo>() {
        }.getType());
        EMClient.getInstance().login(userInfo.getPhone_number(), "123456", new EMCallBack() {//回调
            @Override
            public void onSuccess() {
                EMClient.getInstance().groupManager().loadAllGroups();
                EMClient.getInstance().chatManager().loadAllConversations();
                Log.d(TAG, "登录聊天服务器成功！");

                UserInfoDBHelper.insertUser(userInfo, context.getCurrentActivity());// 初始化user表
                insertUserShare(userInfo);// 初始化share值
                Intent intent = new Intent(context.getCurrentActivity(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                context.getCurrentActivity().startActivity(intent);
                context.getCurrentActivity().finish();
            }

            @Override
            public void onProgress(int progress, String status) {

            }

            @Override
            public void onError(int code, String message) {
                Log.d(TAG, "登录聊天服务器失败！");
                if (code == 200){
                    EMClient.getInstance().groupManager().loadAllGroups();
                    EMClient.getInstance().chatManager().loadAllConversations();
                    Log.d(TAG, "登录聊天服务器成功！");

                    UserInfoDBHelper.insertUser(userInfo, context.getCurrentActivity());// 初始化user表
                    insertUserShare(userInfo);// 初始化share值
                    Intent intent = new Intent(context.getCurrentActivity(), MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    context.getCurrentActivity().startActivity(intent);
                    context.getCurrentActivity().finish();
                }
            }
        });
    }

    private void insertUserShare(UserInfo userInfo) {
        SharedPreferences sharedPreferences = context.getCurrentActivity().getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0);
        sharedPreferences.edit().putInt("userId", userInfo.getUser_id()).commit();
        sharedPreferences.edit().putString("token", userInfo.getToken()).commit();
    }
}
