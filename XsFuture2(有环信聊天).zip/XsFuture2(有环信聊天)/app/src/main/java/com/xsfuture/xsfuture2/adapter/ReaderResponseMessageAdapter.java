package com.xsfuture.xsfuture2.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.main_module.PersonalDetailsActivity;
import com.xsfuture.xsfuture2.activity.main_module.ReadingBookJournalEntryDetailsActiviy;
import com.xsfuture.xsfuture2.bean.ReaderResponseMessageInfo;
import com.xsfuture.xsfuture2.util.DateUtils;

import java.util.ArrayList;
import java.util.List;

public class ReaderResponseMessageAdapter extends BaseAdapter {

    private List<ReaderResponseMessageInfo> data;
    private LayoutInflater inflater;
    private ActivityHandlerInterface context;

    public ReaderResponseMessageAdapter(ActivityHandlerInterface c) {
        context = c;
        inflater = LayoutInflater.from(context.getCurrentActivity());
        data = new ArrayList<ReaderResponseMessageInfo>();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public ReaderResponseMessageInfo getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getViewTypeCount() {
        return 2;
    }

    @Override
    public int getItemViewType(int position) {
        if (data.get(position).getMsg_type() == 0) {
            return 0;
        } else {
            return 1;
        }
    }

    public void setData(List<ReaderResponseMessageInfo> infos) {
        if (data == null) {
            data = new ArrayList<ReaderResponseMessageInfo>();
        } else {
            data.clear();
        }
        if (infos != null && infos.size() > 0) {
            data.addAll(infos);
        }
        notifyDataSetChanged();
    }

    public void addData(List<ReaderResponseMessageInfo> infos) {
        if (data == null) {
            data = new ArrayList<ReaderResponseMessageInfo>();
        }
        if (infos != null && infos.size() > 0) {
            data.addAll(infos);
        }
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        final ReaderResponseMessageInfo item = data.get(position);
        if (getItemViewType(position) == 0) {
            if (convertView == null) {
                viewHolder = new ViewHolder();
                LayoutInflater layoutInflater = LayoutInflater.from(context.getCurrentActivity());
                convertView = layoutInflater.inflate(R.layout.item_reader_response_message_like, null);
                viewHolder.tv_name = (TextView) convertView.findViewById(R.id.tv_name);
                viewHolder.tv_book = (TextView) convertView.findViewById(R.id.tv_book);
                viewHolder.tv_time = (TextView) convertView.findViewById(R.id.tv_time);
                viewHolder.line_message = (LinearLayout) convertView.findViewById(R.id.line_message);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            viewHolder.tv_name.setText(item.getNick_name());
            viewHolder.tv_name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context.getCurrentActivity(), PersonalDetailsActivity.class);
                    intent.putExtra("user_id", item.getUser_id());
                    intent.putExtra("user_name", item.getUser_name());
                    intent.putExtra("nick_name", item.getNick_name());
                    intent.putExtra("user_image", item.getUser_image());
                    context.getCurrentActivity().startActivity(intent);
                }
            });
            viewHolder.tv_book.setText("《" + item.getBook_name() + "》" + "已读第" + item.getReaded_days() + "天");
            viewHolder.tv_time.setText(DateUtils.TimeStamp2Date(String.valueOf(item.getTime_stamp())));
            viewHolder.line_message.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context.getCurrentActivity(), ReadingBookJournalEntryDetailsActiviy.class);
                    intent.putExtra("time_stamp", item.getTime_stamp());
                    intent.putExtra("readed_page_number", item.getReaded_page_number());
                    intent.putExtra("content", item.getContent());
                    intent.putExtra("favor_total", item.getFavor_total());
                    intent.putExtra("comment_total", item.getComment_total());
                    intent.putExtra("reader_response_id", item.getReader_response_id());
                    intent.putExtra("is_favored", item.isFavored_flg());
                    context.getCurrentActivity().startActivity(intent);
                }
            });
        } else if (getItemViewType(position) == 1) {
            if (convertView == null) {
                viewHolder = new ViewHolder();
                LayoutInflater layoutInflater = LayoutInflater.from(context.getCurrentActivity());
                convertView = layoutInflater.inflate(R.layout.item_reader_response_message_comment, null);
                viewHolder.tv_name = (TextView) convertView.findViewById(R.id.tv_name);
                viewHolder.tv_book = (TextView) convertView.findViewById(R.id.tv_book);
                viewHolder.tv_comment_content = (TextView) convertView.findViewById(R.id.tv_comment_content);
                viewHolder.tv_time = (TextView) convertView.findViewById(R.id.tv_time);
                viewHolder.line_message = (LinearLayout) convertView.findViewById(R.id.line_message);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            viewHolder.tv_name.setText(item.getNick_name());
            viewHolder.tv_name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context.getCurrentActivity(), PersonalDetailsActivity.class);
                    intent.putExtra("user_id", item.getUser_id());
                    intent.putExtra("user_name", item.getUser_name());
                    intent.putExtra("nick_name", item.getNick_name());
                    intent.putExtra("user_image", item.getUser_image());
                    context.getCurrentActivity().startActivity(intent);
                }
            });
            viewHolder.tv_book.setText("《" + item.getBook_name() + "》" + "已读第" + item.getReaded_days() + "天");
            viewHolder.tv_comment_content.setText(item.getComment_content());
            viewHolder.tv_time.setText(DateUtils.TimeStamp2Date(String.valueOf(item.getTime_stamp())));
            viewHolder.line_message.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context.getCurrentActivity(), ReadingBookJournalEntryDetailsActiviy.class);
                    intent.putExtra("time_stamp", item.getTime_stamp());
                    intent.putExtra("readed_page_number", item.getReaded_page_number());
                    intent.putExtra("content", item.getContent());
                    intent.putExtra("favor_total", item.getFavor_total());
                    intent.putExtra("comment_total", item.getComment_total());
                    intent.putExtra("reader_response_id", item.getReader_response_id());
                    intent.putExtra("is_favored", item.isFavored_flg());
                    context.getCurrentActivity().startActivity(intent);
                }
            });
        }
        return convertView;
    }

    public class ViewHolder {
        TextView tv_name;
        TextView tv_book;
        TextView tv_time;
        TextView tv_comment_content;
        LinearLayout line_message;
    }
}
