package com.xsfuture.xsfuture2.cache;

import java.lang.ref.SoftReference;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

import android.graphics.Bitmap;

public class ImageCache {

	private static ConcurrentHashMap<String, SoftReference<Bitmap>> imageCache = new ConcurrentHashMap<String, SoftReference<Bitmap>>();

	public static void clearAllImage() {
		Iterator<String> iterator = imageCache.keySet().iterator();
		while (iterator.hasNext()) {
			String key = (String) iterator.next();
			SoftReference<Bitmap> softreference = (SoftReference<Bitmap>) imageCache.get(key);
			if (softreference != null && softreference.get() != null) {
				((Bitmap) softreference.get()).recycle();
			}
		}
	}

	public static boolean containsKey(String key) {
		if (imageCache.containsKey(key)) {
			return true;
		} else {
			return false;
		}
	}

	public static Bitmap getBitmap(String key) {
		Bitmap bitmap = null;
		if (key != null) {
			if (imageCache != null && imageCache.containsKey(key)) {
				SoftReference<Bitmap> soft_bitmap = imageCache.get(key);
				bitmap = soft_bitmap.get();
			}
			if (bitmap == null) {
				imageCache.remove(key);
			}
		}
		return bitmap;
	}

	public static void putBitmap(String key, Bitmap bitmap) {
		if (key != null && bitmap != null) {
			if (imageCache != null) {
				if (!imageCache.containsKey(key)) {
					imageCache.put(key, new SoftReference<Bitmap>(bitmap));
				}
			} else {
				imageCache = new ConcurrentHashMap<String, SoftReference<Bitmap>>();
				imageCache.put(key, new SoftReference<Bitmap>(bitmap));
			}
		}

	}
}
