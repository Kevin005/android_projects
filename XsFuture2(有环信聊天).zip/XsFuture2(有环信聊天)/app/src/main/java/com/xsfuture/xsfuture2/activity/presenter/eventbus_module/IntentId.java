package com.xsfuture.xsfuture2.activity.presenter.eventbus_module;

import com.xsfuture.xsfuture2.fragment.DynamicFragment;
import com.xsfuture.xsfuture2.fragment.FollowFragment;
import com.xsfuture.xsfuture2.fragment.TodayFragment;

/**
 * Created by Kevin on 2017/6/14.
 */

public class IntentId {
    public static final String INTENT_TO_TODAY_FRAGMENT = TodayFragment.class.getSimpleName();
    public static final String INTENT_TO_DYNAMIC_FRAGMENT = DynamicFragment.class.getSimpleName();
    public static final String INTENT_TO_FOLLOW_FRAGMENT = FollowFragment.class.getSimpleName();
}
