package com.xsfuture.xsfuture2.activity.main_module;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.bean.EventBusInfo;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.presenter.eventbus_module.CommandId;
import com.xsfuture.xsfuture2.activity.presenter.eventbus_module.IntentId;
import com.xsfuture.xsfuture2.adapter.MyReadingDetailsAdapter;
import com.xsfuture.xsfuture2.bean.MyReaderResponseDetails;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.Log;
import com.xsfuture.xsfuture2.view.xlistview.XListView;


import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class MyReadingDetailsActivity extends BaseActivity implements XListView.IXListViewListener, MyReadingDetailsAdapter.MyReadingRefresh {
    private XListView my_reading_details;
    private MyReadingDetailsAdapter adapter;

    private List<MyReaderResponseDetails> infos;
    private int post_id;
    private String book_name;
    private double progress;
    private int reading_days;
    private String pagetotal;
    private String image;
    private String author;
    private int favor_total;
    private boolean is_signed;//是否打卡
    private boolean refreshTodayFragment = false;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_my_reading_details);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        initData();
        setTitleText("《" + book_name + "》");
        setTitleLeftBtn(R.string.back, new OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.e("TAG", refreshTodayFragment ? "true" : "false");
                if (refreshTodayFragment) {
                    Intent intent = new Intent();
                    intent.putExtra("", "");
                    setResult(Activity.RESULT_OK, intent);
                    finish();
                } else {
                    finish();
                }
            }
        });
        setTitleBtnRight(0, R.drawable.right_setting, new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), BookStateSettingActivity.class);
                intent.putExtra("book_name", book_name);
                intent.putExtra("post_id", post_id);
                startActivity(intent);
            }
        });
        initView();
    }

    private void initData() {
        post_id = getIntent().getIntExtra("post_id", 0);
        book_name = getIntent().getStringExtra("book_name");
        progress = getIntent().getDoubleExtra("progress", 0);
        reading_days = getIntent().getIntExtra("reading_days", 0);
        is_signed = getIntent().getBooleanExtra("is_signed", false);
        pagetotal = getIntent().getStringExtra("pagetotal");
        image = getIntent().getStringExtra("image");
        author = getIntent().getStringExtra("author");
        favor_total = getIntent().getIntExtra("favor_total", 0);
        infos = new ArrayList<MyReaderResponseDetails>();
    }

    private void initView() {
        my_reading_details = (XListView) findViewById(R.id.my_reading_details);
        my_reading_details.setPullRefreshEnable(false);
        my_reading_details.setPullLoadEnable(false);
        my_reading_details.setXListViewListener(this);
        adapter = new MyReadingDetailsAdapter(getCurrentActivity(), this);
        my_reading_details.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        infos.clear();
        detailsView();
        readerResponseView();
        super.onResume();
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if (RESULT_OK == resultCode) {
//            switch (requestCode) { //resultCode为回传的标记，我在B中回传的是RESULT_OK
//                case 1://refresh current activity
//                    infos.clear();
//                    detailsView();
//                    readerResponseView();
//                    break;
//                default:
//                    break;
//            }
//        }
//    }

    private void detailsView() {
        MyReaderResponseDetails info = new MyReaderResponseDetails();
        info.setInfo_type(0);
        info.setBook_name(book_name);
        info.setBook_image(image);
        info.setProgress(progress);
        info.setReaded_days(reading_days);
        info.setPage_total(pagetotal);
        info.setIs_signed(is_signed);
        info.setPost_id(post_id);
        info.setAuthor(author);
        info.setRr_favor_total(favor_total);
        infos.add(info);
    }

    private void readerResponseView() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("post_id", post_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                onXListViewStop();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONArrayPoxy data = jSONObjectProxy.getJSONArrayOrNull("data");
                    if (success == 0 && data != null) {
                        if (data.length() > 0) {
                            Gson gson = new Gson();
                            List<MyReaderResponseDetails> datas = gson.fromJson(data.toString(),
                                    new TypeToken<List<MyReaderResponseDetails>>() {
                                    }.getType());
                            for (MyReaderResponseDetails info : datas) {
                                info.setInfo_type(1);
                            }
                            infos.addAll(datas);
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                    adapter.setData(infos);
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    adapter.setData(infos);
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_post_getReaderResponseList + "?order=desc");
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    @Override
    public void onRefresh() {
    }

    @Override
    public void onLoadMore() {
    }

    @Override
    public void onXListViewStop() {
        my_reading_details.stopRefresh();
        my_reading_details.stopLoadMore();
    }

    @Override
    public void signInSuccess() {
        is_signed = true;
        refreshTodayFragment = true;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (refreshTodayFragment) {
            EventBusInfo info = new EventBusInfo();
            info.setIntentId(IntentId.INTENT_TO_TODAY_FRAGMENT);
            info.setCommandId(CommandId.COMMAND_ID_1);
            EventBus.getDefault().post(info);
            finish();
        } else {
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}