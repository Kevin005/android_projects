package com.xsfuture.xsfuture2.activity.account_module;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.main_module.MainActivity;
import com.xsfuture.xsfuture2.activity.tool.SelectPicActivity;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.database.UserInfoDBHelper;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.http.HttpUploadFileTask;
import com.xsfuture.xsfuture2.util.EncodeUtils;
import com.xsfuture.xsfuture2.util.FileService;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.PrefUtils;
import com.xsfuture.xsfuture2.util.StringUtils;
import com.xsfuture.xsfuture2.view.CircularImage;

import org.json.JSONException;

import java.io.File;

public class WriteBasicInfoActivity extends BaseActivity {
    private EditText edttxt_nickname;
    private EditText edttxt_pwd_input;
    private RadioGroup group_gender;
    private Button btn_register_complete;
    private CircularImage cirimg_reader_avatar;

    private final int TO_SELECT_PHOTO = 1;
    private final int PHOTO_REQUEST_CUT = 2;
    private String file_path;
    private String end_name;
    private String phone;
    /**
     * man:1,woman:0
     */
    private int sex = 0;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_write_basic_info);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleText("基本信息");
        setTitleLeftBtn(R.string.back, new OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initExtraData();
        initView();
    }

    private void initExtraData() {
        phone = getIntent().getStringExtra("phone");
    }

    private void initView() {
        cirimg_reader_avatar = (CircularImage) findViewById(R.id.cirimg_reader_avatar);
        cirimg_reader_avatar.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), SelectPicActivity.class);
                startActivityForResult(intent, TO_SELECT_PHOTO);
            }
        });
        edttxt_nickname = (EditText) findViewById(R.id.edttxt_nickname);
        group_gender = (RadioGroup) findViewById(R.id.group_gender);
        group_gender.setOnCheckedChangeListener(new OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rdobtn_man_gender:
                        sex = 0;
                        break;
                    case R.id.rdobtn_woman_gender:
                        sex = 1;
                        break;
                    default:
                        break;
                }
            }
        });
        btn_register_complete = (Button) findViewById(R.id.btn_register_complete);
        btn_register_complete.setEnabled(true);
        btn_register_complete.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check()) {
                    register();
                }
            }
        });
        edttxt_pwd_input = (EditText) findViewById(R.id.edttxt_pwd_input);
    }

    private boolean check() {
        String nickname = edttxt_nickname.getText().toString();
        String pwdinput = edttxt_pwd_input.getText().toString();
        if (StringUtils.isEmpty(nickname)) {
            Toast.makeText(getCurrentActivity(), "请填写昵称", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (StringUtils.isEmpty(pwdinput)) {
            Toast.makeText(getCurrentActivity(), "请设置密码", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void register() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("phone_number", phone);
            obj.put("user_name", phone);
            String sha1Str = EncodeUtils.shaEncrypt(edttxt_pwd_input.getText().toString());//sha1密文
            obj.put("password", sha1Str);
            obj.put("nick_name", edttxt_nickname.getText().toString());
            obj.put("gender", sex);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        // String infoStr = new Gson().toJson(info);
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONObjectProxy data = jSONObjectProxy.getJSONObjectOrNull("data");
                    if (success == 0 && data != null) {
                        UserInfo userInfo = new Gson().fromJson(data.toString(), new TypeToken<UserInfo>() {
                        }.getType());
                        UserInfoDBHelper.insertUser(userInfo, getCurrentActivity());// 初始化user表
                        insertUserShare(userInfo);// 初始化share值
                        sendFile(file_path);//传送图像
                        Intent intent = new Intent(getCurrentActivity(), MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.user_register);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    private void insertUserShare(UserInfo userInfo) {
        PrefUtils.putUserId(getCurrentActivity(),userInfo.getUser_id());
        PrefUtils.putUserToken(getCurrentActivity(),userInfo.getToken());
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == TO_SELECT_PHOTO) {
                String picPath = data.getStringExtra(SelectPicActivity.KEY_PHOTO_PATH);
                if (picPath != null) {
                    int i = picPath.lastIndexOf(".");
                    if (i > 0 && i < picPath.length()) {
                        end_name = picPath.substring(i);
                    }
                    crop(Uri.fromFile(new File(picPath)));
                }
            } else if (requestCode == PHOTO_REQUEST_CUT) {
                Bitmap bitmap = data.getParcelableExtra("data");
                file_path = FileService.getTempPath() + "/" + "temp" + end_name;
                file_path = FileService.saveBitmap(bitmap, file_path);
                cirimg_reader_avatar.setImageBitmap(bitmap);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void crop(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        // 裁剪框的比例，1：1
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // 裁剪后输出图片的尺寸大小
        intent.putExtra("outputX", 250);
        intent.putExtra("outputY", 250);
        intent.putExtra("outputFormat", "JPEG");
        // 取消人脸识别
        intent.putExtra("noFaceDetection", true);
        // true:不返回uri，false：返回uri
        intent.putExtra("return-data", true);
        startActivityForResult(intent, PHOTO_REQUEST_CUT);
    }

    private void sendFile(String picPath) {
        if (StringUtils.isEmpty(picPath)) {
            return;
        }
        HttpUploadFileTask fileTask = new HttpUploadFileTask(getCurrentActivity(), picPath, "image") {

            @Override
            public boolean isStop() {
                return false;
            }

            @Override
            public void stop() {
            }

            @Override
            public void onError() {
            }

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(JSONObjectProxy result) {
                if (result != null) {
                    int success = result.getIntOrNull("success");
                    String message = result.getStringOrNull("message");
                    String data = result.getStringOrNull("data");
                    if (success == 0) {
                        UserInfo info = UserInfoDBHelper.getUser(getCurrentActivity().getUser_id(), getCurrentActivity());
                        info.setAvatar_url(ConstHttpProp.base_url + data);
                        UserInfoDBHelper.updateUser(info, getCurrentActivity());
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        fileTask.executes(ConstHttpProp.base_url + ConstFuncId.xiaoshi_image_upload_p + "?image_type=p");
    }

}