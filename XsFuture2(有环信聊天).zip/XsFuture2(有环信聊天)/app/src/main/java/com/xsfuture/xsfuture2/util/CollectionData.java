package com.xsfuture.xsfuture2.util;

import android.support.annotation.Nullable;

import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by kevin on 17-4-3.
 */

public class CollectionData<T> {

    public List<T> dataDuplicateRemovalAndReture(@Nullable List<T> objs) {
        Set<T> setDatas = new LinkedHashSet<T>();
        setDatas.addAll(objs);
        objs.clear();
        objs.addAll(setDatas);
        return objs;
    }

    @Deprecated
    private void abcd(Object obj) {
        if (obj instanceof Integer) {
            String a = "";
        } else if (obj instanceof String) {
            String a = "";
//            String s = (String) param;
//            prepStatement.setString(i + 1, s);
        } else if (obj instanceof Double) {
            String a = "";
//            double d = ((Double) param).doubleValue();
//            prepStatement.setDouble(i + 1, d);
        } else if (obj instanceof Float) {
            String a = "";
//            float f = ((Float) param).floatValue();
//            prepStatement.setFloat(i + 1, f);
        } else if (obj instanceof Long) {
            String a = "";
//            long l = ((Long) param).longValue();
//            prepStatement.setLong(i + 1, l);
        } else if (obj instanceof Boolean) {
            String a = "";
//            boolean b = ((Boolean) param).booleanValue();
//            prepStatement.setBoolean(i + 1, b);
        } else if (obj instanceof Date) {
            String a = "";
//            Date d = (Date) param;
//            prepStatement.setDate(i + 1, (Date) param);
        }
    }
}
