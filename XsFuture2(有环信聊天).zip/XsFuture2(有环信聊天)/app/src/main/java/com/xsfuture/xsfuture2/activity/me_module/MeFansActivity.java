package com.xsfuture.xsfuture2.activity.me_module;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.MeFansAdapter;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.view.xlistview.XListView;

import org.json.JSONException;

import java.util.List;

public class MeFansActivity extends BaseActivity implements XListView.IXListViewListener {
	private XListView me_fans_list;
	private MeFansAdapter adapter;

	@Override
	protected void setCurrentContentView() {
		setContentView(R.layout.activity_me_fans);
	}

	@Override
	protected void init(Bundle savedInstanceState) {
		setTitleText("粉丝");
		setTitleLeftBtn(R.string.back, new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		initView();
	}

	private void initView() {
		me_fans_list = (XListView) findViewById(R.id.me_fans_list);
		me_fans_list.setPullLoadEnable(false);
		me_fans_list.setPullRefreshEnable(true);
		me_fans_list.setXListViewListener(this);
		adapter = new MeFansAdapter(getCurrentActivity());
		me_fans_list.setAdapter(adapter);
		fans(true);
	}
	
	private void fans(boolean is_refresh) {
		JSONObjectProxy obj = new JSONObjectProxy();
		try {
			obj.put("user_id", getUser_id());
		} catch (JSONException e) {
			e.printStackTrace();
		}
		HttpTask httpTask = new HttpTask(getCurrentActivity()) {

			@Override
			public void onStart() {
			}

			@Override
			public void onEnd(HttpResult httpResult) {
				onXListViewStop();
				if (httpResult != null && httpResult.getJsonObject() != null) {
					JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
					int success = jSONObjectProxy.getIntOrNull("success");
					String message = jSONObjectProxy.getStringOrNull("message");
					JSONArrayPoxy data = jSONObjectProxy.getJSONArrayOrNull("data");
					if (success == 0 && data != null) {
						List<UserInfo> infos = new Gson().fromJson(data.toString(), new TypeToken<List<UserInfo>>() {
						}.getType());
						adapter.setData(infos);
					} else {
						Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
					}
				} else {
					Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
				}
			}

			@Override
			public void onError(HttpError httpError) {
				if (httpError != null) {
					if (httpError.getErrorCode() == HttpError.NONetworkError) {
						Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
					}
				}
			}

			@Override
			public void onProgress(int i, int j) {
			}

		};
		httpTask.setShow_progressbar(is_refresh);
		HttpSetting httpSetting = new HttpSetting();
		httpSetting.setFunctionId(ConstFuncId.xiaoshi_friends_fans+"?on_type=fans");
		httpSetting.setUrl(ConstHttpProp.base_url);
		httpSetting.setJsonParams(obj.toString());
		httpSetting.setHttp_type(HttpSetting.HTTP_POST);
		httpSetting.setType(ConstHttpProp.TYPE_JSON);
		httpTask.executes(httpSetting);
	}

	@Override
	public void onRefresh() {
		fans(false);
	}

	@Override
	public void onLoadMore() {
	}

	@Override
	public void onXListViewStop() {
		me_fans_list.stopRefresh();
		me_fans_list.stopLoadMore();
	}
}