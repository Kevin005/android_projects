package com.xsfuture.xsfuture2.util;

import java.io.UnsupportedEncodingException;
import java.util.UUID;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;

import com.xsfuture.xsfuture2.config.ConstSysConfig;

public class DeviceUuidTool {

	protected static UUID uuid;

	public DeviceUuidTool(Context context) {
		if (uuid == null) {
			synchronized (DeviceUuidTool.class) {
				if (uuid == null) {
					final SharedPreferences prefs = context.getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0);
					final String id = prefs.getString(ConstSysConfig.KEY_DEVICE_ID, null);
					if (id != null) {
						// 使用之前计算好存储在SharedPreferences中的device_id
						uuid = UUID.fromString(id);
					} else {
						final String androidId = Secure.getString(context.getContentResolver(), Secure.ANDROID_ID);
						try {
							/*
							 * ANDROID_ID在Android <=2.1 or Android
							 * >=2.3的版本是可靠、稳定的，但在2.2的版本并不是100%可靠的,
							 * 在主流厂商生产的设备上，有一个很经常的bug
							 * ，就是每个设备都会产生相同的ANDROID_ID：9774d56d682e549c
							 */
							if (!"9774d56d682e549c".equals(androidId)) {
								uuid = UUID.nameUUIDFromBytes(androidId.getBytes("utf8"));
							} else {
								TelephonyManager telephonyManager = (TelephonyManager) context
										.getSystemService(Context.TELEPHONY_SERVICE);
								final String deviceId = telephonyManager.getDeviceId();
								if (null != deviceId) {
									uuid = UUID.nameUUIDFromBytes(deviceId.getBytes("utf8"));
								} else {
									StringBuffer build = new StringBuffer();
									build.append(Build.VERSION.RELEASE).append(Build.SERIAL).append(Build.MODEL)
											.append(Build.MANUFACTURER).append(Build.BOARD).append(Build.BRAND)
											.append(Build.CPU_ABI).append(Build.DEVICE).append(Build.DISPLAY)
											.append(Build.FINGERPRINT).append(Build.HARDWARE).append(Build.HOST)
											.append(Build.ID).append(Build.PRODUCT).append(Build.SERIAL)
											.append(Build.TYPE).append(Build.USER);

									uuid = UUID.fromString(build.toString());
								}
							}
						} catch (UnsupportedEncodingException e) {
							throw new RuntimeException(e);
						}
						// 存储到SharedPreferences
						prefs.edit().putString(ConstSysConfig.KEY_DEVICE_ID, uuid.toString()).commit();
					}
				}
			}
		}

	}

	/**
	 * @see http://www.cnblogs.com/lvcha/p/3721091.html
	 * 
	 * @return a UUID that may be used to uniquely identify your device for most
	 *         purposes.
	 */
	public UUID getDeviceUuid() {
		return uuid;
	}

	// uuid的'-'去掉
	public static String getDeviceId(Context context) {
		if (uuid == null) {
			synchronized (DeviceUuidTool.class) {
				if (uuid == null) {
					final SharedPreferences prefs = context.getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0);
					final String id = prefs.getString(ConstSysConfig.KEY_DEVICE_ID, null);

					if (id != null) {
						// 使用之前计算好存储在SharedPreferences中的device_id
						uuid = UUID.fromString(id);
					} else {
						final String androidId = Secure.getString(context.getContentResolver(), Secure.ANDROID_ID);
						try {
							/*
							 * ANDROID_ID在Android <=2.1 or Android
							 * >=2.3的版本是可靠、稳定的，但在2.2的版本并不是100%可靠的,
							 * 在主流厂商生产的设备上，有一个很经常的bug
							 * ，就是每个设备都会产生相同的ANDROID_ID：9774d56d682e549c
							 */
							if (!"9774d56d682e549c".equals(androidId)) {
								uuid = UUID.nameUUIDFromBytes(androidId.getBytes("utf8"));
							} else {
								TelephonyManager telephonyManager = (TelephonyManager) context
										.getSystemService(Context.TELEPHONY_SERVICE);
								final String deviceId = telephonyManager.getDeviceId();
								if (null != deviceId) {
									uuid = UUID.nameUUIDFromBytes(deviceId.getBytes("utf8"));
								} else {
									StringBuffer build = new StringBuffer();
									build.append(Build.VERSION.RELEASE).append(Build.SERIAL).append(Build.MODEL)
											.append(Build.MANUFACTURER).append(Build.BOARD).append(Build.BRAND)
											.append(Build.CPU_ABI).append(Build.DEVICE).append(Build.DISPLAY)
											.append(Build.FINGERPRINT).append(Build.HARDWARE).append(Build.HOST)
											.append(Build.ID).append(Build.PRODUCT).append(Build.SERIAL)
											.append(Build.TYPE).append(Build.USER);

									uuid = UUID.fromString(build.toString());
								}
							}
						} catch (UnsupportedEncodingException e) {
							throw new RuntimeException(e);
						}
						// 存储到SharedPreferences
						prefs.edit().putString(ConstSysConfig.KEY_DEVICE_ID, uuid.toString()).commit();
					}
				}
			}
		}
		return uuid.toString().replaceAll("\\-", "");
	}
}
