package com.xsfuture.xsfuture2.activity.main_module;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.SearchBookListAdapter;
import com.xsfuture.xsfuture2.bean.BookListInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.task.LoadDoubanBookInfoTask;
import com.xsfuture.xsfuture2.util.StringUtils;
import com.xsfuture.xsfuture2.view.xlistview.XListView;

public class SearchBookListActivity extends BaseActivity implements XListView.IXListViewListener {
    private XListView readed_books_list;
    private SearchBookListAdapter adapter;
    private TextView iv_search_books;
    private EditText edtTxt_search_books;

    private final int offset = 0;
    private int limit = 1000;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            InputMethodManager imm1 = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm1.hideSoftInputFromWindow(edtTxt_search_books.getWindowToken(),0);
            BookListInfo info = (BookListInfo) msg.obj;
            if (info != null) {
                refreshView(info);
            } else {
                Toast.makeText(getCurrentActivity(), "没有找到图书哦", Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_search_book_list);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        initView();
    }

    private void initView() {
        readed_books_list = (XListView) findViewById(R.id.readed_books_list);
        readed_books_list.setOnItemClickListener(new XListView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                intent.putExtra("author", adapter.getItem(position).getAuthor().get(0));
                intent.putExtra("title", adapter.getItem(position).getTitle());
                intent.putExtra("book_img", adapter.getItem(position).getImages().getLarge());
                intent.putExtra("pages", adapter.getItem(position).getPages());
                setResult(Activity.RESULT_OK, intent);
                finish();
            }
        });
        readed_books_list.setPullLoadEnable(false);
        readed_books_list.setPullRefreshEnable(false);
        readed_books_list.setXListViewListener(this);
        adapter = new SearchBookListAdapter(getCurrentActivity());
        readed_books_list.setAdapter(adapter);
        edtTxt_search_books = (EditText) findViewById(R.id.edtTxt_search_books);
        iv_search_books = (TextView) findViewById(R.id.iv_search_books);
        iv_search_books.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!StringUtils.isEmpty(edtTxt_search_books.getText().toString())) {
                    String urlstr = ConstHttpProp.douban_api_url + ConstFuncId.book_search + "?q=" + edtTxt_search_books.getText().toString();
                    new DownloadThread(urlstr).start();
                }
            }
        });
        edtTxt_search_books.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    if (!StringUtils.isEmpty(edtTxt_search_books.getText().toString())) {
                        String urlstr = ConstHttpProp.douban_api_url + ConstFuncId.book_search + "?q=" + edtTxt_search_books.getText().toString();
                        new DownloadThread(urlstr).start();
                    }
                    return true;
                }
                return false;
            }
        });
    }

    private class DownloadThread extends Thread {
        String url = null;

        public DownloadThread(String urlstr) {
            url = urlstr;
        }

        public void run() {
            String result = LoadDoubanBookInfoTask.Download(url);
            BookListInfo info = new LoadDoubanBookInfoTask().parseBookListInfo(result);
            Message msg = Message.obtain();
            msg.obj = info;
            mHandler.sendMessage(msg);
        }
    }

    @Override
    public void onXListViewStop() {
        readed_books_list.stopRefresh();
        readed_books_list.stopLoadMore();
    }


    @Override
    public void onRefresh() {
    }

    @Override
    public void onLoadMore() {
    }

    private void refreshView(BookListInfo info) {
        adapter.setData(info.getBooks());
    }

}