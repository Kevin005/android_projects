package com.xsfuture.xsfuture2.activity.main_module;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.presenter.CharacterRecognizePresenter;
import com.xsfuture.xsfuture2.activity.presenter.WriteJournalEntryActivityPresenter;
import com.xsfuture.xsfuture2.activity.tool.CropPicActivity;
import com.xsfuture.xsfuture2.activity.tool.SelectPicActivity;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.bean.DraftInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.database.DraftInfoDBHelper;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.task.HttpUploadArticleFileTask;
import com.xsfuture.xsfuture2.util.FileService;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.Log;
import com.xsfuture.xsfuture2.util.StringUtils;
import com.xsfuture.xsfuture2.view.RichEditText;

import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class WriteJournalEntryActivity extends BaseActivity {
    private ImageView img_add_img;
    private EditText current_pages;
    private TextView tv_record;
    private TextView tv_red_status;
    private RelativeLayout rel_record;
    private RichEditText write_journal_entry_content;

    private final int TO_SELECT_PHOTO = 1;
    private final int PHOTO_REQUEST_CUT = 2;
    private int post_id;
    private String book_name;
    private boolean is_recording = false;

    private WriteJournalEntryActivityPresenter presenter;
    private CharacterRecognizePresenter recognizePresenter;

    private AlphaAnimation alphaAnimation;
    private int edt_first_index = 0;//编辑器开始坐标
    private int edt_end_index = 0;//编辑器最终坐标

    private int selected_type;
    private final int ADD_IMG_TYPE = 0;
    private final int RECOGNIZE_TYPE = 1;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_write_journal_entry);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        initData();
        setTitleText("《" + book_name + "》");
        setTitleLeftBtn(R.string.back, new OnClickListener() {

            @Override
            public void onClick(View v) {
                saveDraft();
            }
        });
        setTitleBtnRight(R.string.release, 0, new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check()) {
                    release();
                }
            }
        });
        initPresenter();
        initView();
    }

    private void initPresenter() {
        presenter = new WriteJournalEntryActivityPresenter(WriteJournalEntryActivity.this);
        presenter.initASR(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                tv_record.setText("点击停止识别");
                tv_record.setEnabled(true);//开启
                tv_red_status.setVisibility(View.VISIBLE);
                tv_red_status.startAnimation(alphaAnimation);//开始闪烁
                write_journal_entry_content.setEnabled(false);//不能编辑
            }

            @Override
            public void onBeginningOfSpeech() {

            }

            @Override
            public void onRmsChanged(float rmsdB) {

            }

            @Override
            public void onBufferReceived(byte[] buffer) {

            }

            @Override
            public void onEndOfSpeech() {
                presenter.stopRecord();
                tv_record.setEnabled(true);//开启
                tv_record.setText("点击开始说话");
                tv_red_status.setVisibility(View.INVISIBLE);
                tv_red_status.clearAnimation();
                write_journal_entry_content.setEnabled(true);//可以编辑
                is_recording = false;
            }

            @Override
            public void onError(int error) {
                tv_record.setEnabled(true);//开启
                tv_record.setText("点击开始说话");
                tv_red_status.setVisibility(View.INVISIBLE);
                tv_red_status.clearAnimation();
                write_journal_entry_content.setEnabled(true);//可以编辑
                StringBuilder sb = new StringBuilder();
                switch (error) {
                    case SpeechRecognizer.ERROR_AUDIO:
                        sb.append("音频问题");
                        break;
                    case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                        sb.append("没有语音输入");
                        break;
                    case SpeechRecognizer.ERROR_CLIENT:
                        sb.append("其它客户端错误");
                        break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                        sb.append("权限不足");
                        break;
                    case SpeechRecognizer.ERROR_NETWORK:
                        sb.append("网络问题");
                        break;
                    case SpeechRecognizer.ERROR_NO_MATCH:
                        sb.append("没有匹配的识别结果");
                        break;
                    case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                        sb.append("引擎忙");
                        break;
                    case SpeechRecognizer.ERROR_SERVER:
                        sb.append("服务端错误");
                        break;
                    case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                        sb.append("连接超时");
                        break;
                }
                sb.append(":" + error);
                Log.w("TAG", sb.toString());
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> nbest = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                Editable edit_text = write_journal_entry_content.getEditableText();
                edit_text.replace(edt_first_index, edt_end_index, "");
                edit_text.insert(edt_first_index, nbest.get(0));
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                ArrayList<String> nbest = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (nbest.size() > 0) {
                    Editable edit_text = write_journal_entry_content.getEditableText();
                    edit_text.replace(edt_first_index, edt_end_index, "");
                    edit_text.insert(edt_first_index, nbest.get(0));
                    edt_end_index = write_journal_entry_content.getSelectionStart();//初始化最终焦点位置
                }
            }

            @Override
            public void onEvent(int eventType, Bundle params) {

            }
        });
        /** baidu character recognize */
        recognizePresenter = new CharacterRecognizePresenter(getCurrentActivity());
    }

    private void initData() {
        post_id = getIntent().getIntExtra("post_id", 0);
        book_name = getIntent().getStringExtra("book_name");
    }

    private void initView() {
        img_add_img = (ImageView) findViewById(R.id.img_add_img);
        img_add_img.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                selected_type = ADD_IMG_TYPE;
                Intent intent = new Intent(getCurrentActivity(), SelectPicActivity.class);
                startActivityForResult(intent, TO_SELECT_PHOTO);
            }
        });
        ImageView btn_text_recon = (ImageView) findViewById(R.id.img_text_recon);
        btn_text_recon.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                selected_type = RECOGNIZE_TYPE;
                Intent intent = new Intent(getCurrentActivity(), SelectPicActivity.class);
                intent.putExtra("take_photo_txt", "识别拍照文字");
                intent.putExtra("pick_photo_txt", "识别相册文字");
                startActivityForResult(intent, TO_SELECT_PHOTO);
            }
        });
        current_pages = (EditText) findViewById(R.id.current_pages);
        write_journal_entry_content = (RichEditText) findViewById(R.id.write_journal_entry_content);
        tv_red_status = (TextView) findViewById(R.id.tv_red_status);
        alphaAnimation = (AlphaAnimation) AnimationUtils.loadAnimation(WriteJournalEntryActivity.this, R.anim.read_response_red_status_animation);
        tv_record = (TextView) findViewById(R.id.tv_record);
        rel_record = (RelativeLayout) findViewById(R.id.rel_record);
        rel_record.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (is_recording) {
                    presenter.stopRecord();
                    tv_record.setText("点击开始说话");
                    tv_record.setEnabled(true);//开启
                    tv_red_status.setVisibility(View.INVISIBLE);
                    tv_red_status.clearAnimation();
                    write_journal_entry_content.setEnabled(true);//可以编辑
                    is_recording = false;
                } else {
                    edt_first_index = edt_end_index = write_journal_entry_content.getSelectionStart();//初始化开始焦点位置
                    presenter.startRecord();
                    tv_record.setText("准备识别...");
                    tv_record.setEnabled(false);//锁定
                    tv_red_status.setVisibility(View.INVISIBLE);
                    tv_red_status.clearAnimation();
                    write_journal_entry_content.setEnabled(false);//不能编辑
                    is_recording = true;
                }
            }
        });

        initViewData();
    }

    private void initViewData() {
        if (post_id != 0) {
            DraftInfo info = DraftInfoDBHelper.getDraft(post_id, getCurrentActivity());
            if (info != null && info.getPostId() != 0) {
                if (info.getContent().contains("@xiaoshi@")) {
                    DraftInfoDBHelper.deleteDraftForPostId(post_id, getCurrentActivity());
                    return;
                }
                current_pages.setText(String.valueOf(info.getReadedPageNumber()));
                write_journal_entry_content.setText(info.getContent());
            }
        }
    }

    private boolean check() {
        if (StringUtils.isEmpty(current_pages.getText().toString())
                || Integer.parseInt(current_pages.getText().toString()) == 0) {
            showShortToast("请填写当前读书页数");
            return false;
        }
        if (StringUtils.isEmpty(write_journal_entry_content.getText().toString())) {
            showShortToast("写下读后感就可以发布了哦！");
            return false;
        }
        return true;
    }

    private void release() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("content", write_journal_entry_content.getText().toString());
            obj.put("readed_page_number", current_pages.getText().toString());
            obj.put("post_id", post_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONObjectProxy data = jSONObjectProxy.getJSONObjectOrNull("data");
                    if (success == 0) {
                        if (post_id != 0) {
                            DraftInfoDBHelper.deleteDraftForPostId(post_id, getCurrentActivity());
                        }
                        finish();
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_post_postReaderResponse);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    @Override
    protected boolean setGesturesTracker() {
        return false;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            saveDraft();
        }
        return false;

    }

    private void saveDraft() {
        if (!StringUtils.isEmpty(current_pages.getText().toString()) || !StringUtils.isEmpty(write_journal_entry_content.getText().toString())) {
            if (write_journal_entry_content.getText().toString().contains("@xiaoshi@")) {
                showDialog("读后感编辑", "是否保存编辑内容");
            } else {
                DraftInfo info = DraftInfoDBHelper.getDraft(post_id, getCurrentActivity());
                String str = StringUtils.isEmpty(current_pages.getText().toString()) ? "0" : current_pages.getText().toString();
                if (info != null && info.getPostId() != 0) {
                    info.setPostId(post_id);
                    info.setReadedPageNumber(Integer.valueOf(str));
                    info.setContent(write_journal_entry_content.getText().toString());
                    DraftInfoDBHelper.updateDraft(info, getCurrentActivity());
                } else {
                    DraftInfo info1 = new DraftInfo();
                    info1.setPostId(post_id);
                    info1.setReadedPageNumber(Integer.valueOf(str));
                    info1.setContent(write_journal_entry_content.getText().toString());
                    DraftInfoDBHelper.insertDraft(info1, getCurrentActivity());
                }
                Toast.makeText(getCurrentActivity(), "已存入草稿", Toast.LENGTH_SHORT).show();
                finish();
            }
        } else {
            DraftInfoDBHelper.deleteDraftForPostId(post_id, getCurrentActivity());
            finish();
        }
    }

    private void showDialog(String title_msg, String content_msg) {
        final AlertDialog dlg = new AlertDialog.Builder(getCurrentActivity()).create();
        dlg.show();
        Window window = dlg.getWindow();
        window.setContentView(R.layout.view_dialog);
        TextView title = (TextView) window.findViewById(R.id.title);
        title.setText(title_msg);
        TextView content = (TextView) window.findViewById(R.id.content);
        content.setText(content_msg);
        Button ok = (Button) window.findViewById(R.id.ok);
        Button cancle = (Button) window.findViewById(R.id.cancle);
        ok.setText("不保存");
        ok.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dlg.dismiss();
                DraftInfoDBHelper.deleteDraftForPostId(post_id, getCurrentActivity());
                finish();
            }
        });
        cancle.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dlg.dismiss();
            }
        });
        window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == TO_SELECT_PHOTO) {
                String picPath = data.getStringExtra(SelectPicActivity.KEY_PHOTO_PATH);
                if (picPath != null) {
                    Intent intent = new Intent(getCurrentActivity(), CropPicActivity.class);
                    intent.putExtra("crop_url", picPath);
                    startActivityForResult(intent, PHOTO_REQUEST_CUT);
                }
            } else if (requestCode == PHOTO_REQUEST_CUT) {
                String local_url_name = data.getStringExtra("data");
                String local_url = Environment.getExternalStorageDirectory() + "/xsfuture/image/crop/" + local_url_name;
                switch (selected_type) {
                    case ADD_IMG_TYPE:
                        sendFile(local_url);
                        break;
                    case RECOGNIZE_TYPE:
                        recognizePresenter.start(local_url, new CharacterRecognizePresenter.RecognizeGeneralResult() {
                            @Override
                            public void onSuccess(String resultStr) {
                                insertTxt(resultStr);
                            }

                            @Override
                            public void onFailed(int resultStr) {
                                showShortToast("识别失败");
                            }
                        });
                        break;
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void sendFile(final String local_url) {
        HttpUploadArticleFileTask fileTask = new HttpUploadArticleFileTask(getCurrentActivity(), local_url, "image", post_id) {

            @Override
            public boolean isStop() {
                return false;
            }

            @Override
            public void stop() {
            }

            @Override
            public void onError() {
            }

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(JSONObjectProxy result) {
                if (result != null) {
                    int success = result.getIntOrNull("success");
                    String message = result.getStringOrNull("message");
                    String server_relative_url = result.getStringOrNull("data");
                    String server_url = ConstHttpProp.img_base_url + server_relative_url;
                    if (success == 0) {
                        Bitmap bitmap = FileService.getImage(local_url);
                        if (bitmap != null) {
                            setRichText(bitmap, server_url, local_url);
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        fileTask.executes(ConstHttpProp.base_url + ConstFuncId.xiaoshi_image_upload_p + "?image_type=c");
    }

    private Bitmap bytes2Bimap(byte[] b) {
        if (b.length != 0) {
            return BitmapFactory.decodeByteArray(b, 0, b.length);
        } else {
            return null;
        }
    }

    private void setRichText(Bitmap bitmap, String server_url, String local_url) {
        if (bitmap != null && !StringUtils.isEmpty(server_url) && !StringUtils.isEmpty(local_url)) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            if (local_url.endsWith("jpg")) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 25, baos);
            } else if (local_url.endsWith("png")) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 25, baos);
            } else {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 25, baos);
            }
            Bitmap bitmap1 = bytes2Bimap(baos.toByteArray());
            //根据Bitmap对象创建ImageSpan对象
            ImageSpan imageSpan = new ImageSpan(getCurrentActivity(), bitmap1);
            //创建一个SpannableString对象，以便插入用ImageSpan对象封装的图像
            SpannableString spannableString = new SpannableString("@xiaoshi@" + server_url + "@xiaoshi@");
            //  用ImageSpan对象替换string
            spannableString.setSpan(imageSpan, 0, ("@xiaoshi@" + server_url + "@xiaoshi@").length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            Editable edit_text = write_journal_entry_content.getEditableText();
            int index = write_journal_entry_content.getSelectionStart();
            if (index < 0 || index >= edit_text.length()) {
                edit_text.append(spannableString);
            } else {
                edit_text.insert(index, spannableString);
            }
            edit_text.insert(write_journal_entry_content.getSelectionStart(), "\n");
            write_journal_entry_content.setFocusable(true);
            write_journal_entry_content.setFocusableInTouchMode(true);
            write_journal_entry_content.requestFocus();
            write_journal_entry_content.requestFocusFromTouch();
        }
    }

    private void insertTxt(String str){
        Editable edit_text = write_journal_entry_content.getEditableText();
        int index = write_journal_entry_content.getSelectionStart();
        if (index < 0 || index > edit_text.length()) {
            edit_text.append(str);
        } else {
            edit_text.insert(index, str);
        }
        edit_text.insert(write_journal_entry_content.getSelectionStart(), "\n");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        presenter.destoryRecord();
        recognizePresenter.release();
    }
}