package com.xsfuture.xsfuture2.bean;

/**
 * Created by Kevin on 2017/6/14.
 */

public class EventBusInfo {
    /** {@link com.xsfuture.xsfuture2.activity.presenter.eventbus_module.IntentId} */
    private String intentId;
    /** {@link com.xsfuture.xsfuture2.activity.presenter.eventbus_module.CommandId} */
    private int commandId;

    public String getIntentId() {
        return intentId;
    }

    public void setIntentId(String intentId) {
        this.intentId = intentId;
    }

    public int getCommandId() {
        return commandId;
    }

    public void setCommandId(int commandId) {
        this.commandId = commandId;
    }
}
