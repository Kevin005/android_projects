package com.xsfuture.xsfuture2.view;

import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.Target;
import com.xsfuture.xsfuture2.activity.tool.PhotoViewActivity;
import com.xsfuture.xsfuture2.util.StringUtils;

/**
 * Created by Administrator on 2016/12/13.
 */
public class RichtextLinearlayout extends LinearLayout {
    private Context context;

    public RichtextLinearlayout(Context context) {
        super(context);
        this.context = context;
    }

    public RichtextLinearlayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
    }

    public RichtextLinearlayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
    }

    public void actionAddView(final String content) {
        if (!StringUtils.isEmpty(content)) {
            String[] str_array = content.split("@xiaoshi@");
            for (final String str : str_array) {
                if (str.contains("http://115.28.56.168") || str.contains("https://115.28.56.168")) {
                    if (StringUtils.isEmpty(str)) {
                        continue;
                    } else {
                        final ImageView imageView = new ImageView(context);
                        addView(imageView);
                        Glide.with(context)
                                .load(str)
                                .asBitmap()
                                .skipMemoryCache(false)//跳过内存缓存
                                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                                .into(new SimpleTarget<Bitmap>(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL) {
                                    @Override
                                    public void onResourceReady(Bitmap bitmap, GlideAnimation glideAnimation) {
                                        // Do something with bitmap here.
                                        imageView.setImageBitmap(bitmap);
                                    }
                                });
                        imageView.setOnClickListener(new OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent(context, PhotoViewActivity.class);
                                intent.putExtra("big_photo_view", str);
                                context.startActivity(intent);
                            }
                        });
                    }
                } else {
                    if (StringUtils.isEmpty(str)) {
                        continue;
                    } else {
                        final TextView textView = new TextView(context);
                        textView.setOnLongClickListener(new OnLongClickListener() {
                            @Override
                            public boolean onLongClick(View v) {
                                ClipboardManager cmb = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                                cmb.setText(textView.getText());
                                Toast.makeText(context, "文字已复制", Toast.LENGTH_SHORT).show();
                                return true;
                            }
                        });
                        textView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT));
                        textView.setText(str);
                        textView.setTextSize(17.0f);
                        addView(textView);
                    }
                }
            }
        }
    }

}
