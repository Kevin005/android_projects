package com.xsfuture.xsfuture2.bean;

/**
 * Created by changtaoxie on 16/10/29.
 */
public class UpdateReqParms {
    /**
     * version_code : 1
     * version_name : 1.3.0
     * white_list :
     */

    private String version_code;
    private String version_name;
    private String white_list;

    public String getVersion_code() {
        return version_code;
    }

    public void setVersion_code(String version_code) {
        this.version_code = version_code;
    }

    public String getVersion_name() {
        return version_name;
    }

    public void setVersion_name(String version_name) {
        this.version_name = version_name;
    }

    public String getWhite_list() {
        return white_list;
    }

    public void setWhite_list(String white_list) {
        this.white_list = white_list;
    }

    @Override
    public String toString() {
        return "UpdateReqParms{" +
                "version_code='" + version_code + '\'' +
                ", version_name='" + version_name + '\'' +
                ", white_list='" + white_list + '\'' +
                '}';
    }
}
