package com.xsfuture.xsfuture2.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;

import com.xsfuture.xsfuture2.bean.ImageInfo;
import com.xsfuture.xsfuture2.cache.ImageCache;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;


public class ImageLoaderRunnable implements Runnable{

	private ImageInfo image;
	private Handler handler;
	private Context context;
	private boolean isCompression;

	public ImageLoaderRunnable(ImageInfo image, Handler handler, Context context) {
		this.image = image;
		this.handler = handler;
		this.context = context;
		isCompression=true;
	}
	
	public ImageLoaderRunnable(ImageInfo image, Handler handler, Context context,boolean isCompression) {
		this.image = image;
		this.handler = handler;
		this.context = context;
		 this. isCompression=isCompression;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		Bitmap bitmap = returnBitMap(image);
		if (bitmap != null) {
			if (!isCompression) {
				String new_url=image.getUrl().substring(0,image.getUrl().lastIndexOf("/"))+"/big"+image.getUrl().substring(image.getUrl().lastIndexOf("/")+1);
				ImageCache.putBitmap(new_url, bitmap);
			}else{
				ImageCache.putBitmap(image.getUrl(), bitmap);
			}
			Message msg = new Message();
			msg.what = ImageLoader.success;
			msg.obj = image;
			handler.sendMessage(msg);
		} else {
			Message msg = new Message();
			msg.what = ImageLoader.fail;
			msg.obj = image;
			handler.sendMessage(msg);
		}
	}

	public Bitmap returnBitMap(ImageInfo image) {
		URL myFileUrl = null;
		Bitmap bitmap = null;
		try {
			myFileUrl = new URL(image.getUrl());
		} catch (Exception e) {
			return bitmap;
		}
		if (myFileUrl != null) {
			try {
				ByteArrayOutputStream outStream = new ByteArrayOutputStream();
				byte[] buffer = new byte[1024];
				int len = 0;
				HttpURLConnection conn = (HttpURLConnection) myFileUrl
						.openConnection();
				conn.setDoInput(true);
				conn.connect();
				int fileLength = conn.getContentLength();//获取文件大小
				InputStream is = conn.getInputStream();

				while ((len = is.read(buffer)) != -1) {
					outStream.write(buffer, 0, len);
				}
				if (outStream != null) {
					outStream.close();
				}
				if (is != null) {
					is.close();
				}
				byte[] data = outStream.toByteArray();
				if(data.length<fileLength){//此时图片下载不完整
					if(data.length<(fileLength*2/3)){
						return null;
					}
				}
				BitmapFactory.Options options = new BitmapFactory.Options();
				options.inJustDecodeBounds = true;

				BitmapFactory.decodeByteArray(data, 0, data.length, options);
				int rate=0;
				if( !isCompression){
					options.inSampleSize = 1;
					rate=60;
				}else{
					options.inSampleSize = calculateInSampleSize(options,
							image.getWidth(), image.getHeight());
					rate=60;
				}

				options.inJustDecodeBounds = false;
				bitmap = BitmapFactory.decodeByteArray(data, 0, data.length,
						options);
				if(bitmap!=null){
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					
					
					if (image.getUrl().endsWith("jpg")) {
						bitmap.compress(Bitmap.CompressFormat.JPEG, rate, baos);
					} else if (image.getUrl().endsWith("png")) {
						bitmap.compress(Bitmap.CompressFormat.PNG, rate, baos);
					} else {
						bitmap.compress(Bitmap.CompressFormat.JPEG, rate, baos);
					}
					InputStream in = new ByteArrayInputStream(baos.toByteArray());
					if (FileService.externalMemoryAvailable()) {
						if(!isCompression ){
							String new_url=image.getUrl().substring(0,image.getUrl().lastIndexOf("/"))+"/big"+image.getUrl().substring(image.getUrl().lastIndexOf("/")+1);
							image.setUrl(new_url);
						}
						FileService.saveImage(image, in, context);
						bitmap = FileService.getImage(isCompression,image, context);
					} else {
						bitmap = BitmapFactory.decodeStream(is);
					}
				}
				
			} catch (IOException e) {
				return bitmap;
			}
		}
		return bitmap;
	}

	// 计算图片的缩放值
	public int calculateInSampleSize(BitmapFactory.Options options,
			int reqWidth, int reqHeight) {
		final int height = options.outHeight;// 图片原始高度
		final int width = options.outWidth;// 图片原始宽度
		int inSampleSize = 1;
		if (reqWidth > 0 && reqHeight > 0) {// 压缩后宽高确定
			final int heightRatio = Math.round((float) height
					/ (float) reqHeight);
			int widthRatio = Math.round((float) width / (float) reqWidth);
			inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
			return inSampleSize;
		} else if (reqWidth > 0) {// 压缩后宽度确定，高度不确定
			if (width > reqWidth) {// 图片宽度大于要求宽度，压缩
				int widthRatio = Math.round((float) width / (float) reqWidth);
				return widthRatio;
			} else {
				return inSampleSize;
			}
		} else if (reqHeight > 0) {// 压缩后高度确定，宽度不确定
			if (height > reqHeight) {// 图片高度大于要求高度，压缩
				 int heightRatio = Math.round((float) height
							/ (float) reqHeight);
				 return heightRatio;
			} else {
				return inSampleSize;
			}
		} else {
			return inSampleSize;
		}
	}

}
