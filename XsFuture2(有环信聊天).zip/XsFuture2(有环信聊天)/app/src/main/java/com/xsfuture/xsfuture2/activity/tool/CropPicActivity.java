package com.xsfuture.xsfuture2.activity.tool;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.util.FileService;
import com.xsfuture.xsfuture2.util.Log;
import com.xsfuture.xsfuture2.util.StringUtils;
import com.xsfuture.xsfuture2.view.CropView;

import java.text.SimpleDateFormat;
import java.util.Date;


public class CropPicActivity extends BaseActivity {
    private ImageView img_left_finish;
    private Button btn_right_complete;
    private String crop_url;
    private CropView img_crop;

    @Override
    protected void setCurrentContentView() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        int flag = WindowManager.LayoutParams.FLAG_FULLSCREEN;
        Window myWindow = this.getWindow();
        myWindow.setFlags(flag, flag);
        setContentView(R.layout.activity_crop_pic);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        initExtra();
    }

    private void initExtra() {
        crop_url = getIntent().getStringExtra("crop_url");
        if (StringUtils.isEmpty(crop_url)) {
            Toast.makeText(getCurrentActivity(), "图片不存在哦", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            initView();
        }
    }

    private void initView() {
        img_crop = (CropView) findViewById(R.id.img_crop);
        try {
            img_crop.setBmpPath(crop_url);
        } catch (Exception e) {
            showShortToast("图片格式不支持");
            e.printStackTrace();
        }
        img_left_finish = (ImageView) findViewById(R.id.img_left_finish);
        img_left_finish.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btn_right_complete = (Button) findViewById(R.id.btn_right_complete);
        btn_right_complete.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Bitmap bitmap = img_crop.getCroppedImage();
                    //save file
                    String file_name = getFileName();
                    FileService.saveBitmap(bitmap, "/crop", file_name);
                    Intent intent = new Intent();
                    intent.putExtra("data", file_name);
                    setResult(RESULT_OK, intent);
                    finish();
                } catch (Exception e) {
                    showShortToast("截取图片失败");
                    e.printStackTrace();
                    Log.e("TAG",e.toString());
                }
            }
        });
    }

    private String getFileName() {
        //删除所有缓存crop
//        String saveDir = Environment.getExternalStorageDirectory() + "/xsfuture/crop";
        // 用日期作为文件名，确保唯一性
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String fileName = formatter.format(date) + ".jpg";
        return fileName.replace("file://", "");
    }

    @Override
    public boolean setGesturesTracker() {
        return false;
    }
}
