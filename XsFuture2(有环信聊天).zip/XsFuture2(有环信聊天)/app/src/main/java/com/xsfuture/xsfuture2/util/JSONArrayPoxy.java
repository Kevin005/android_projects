package com.xsfuture.xsfuture2.util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JSONArrayPoxy extends JSONArray {
	private JSONArray jsonArray;

	public JSONArrayPoxy() {
		JSONArray localJSONArray = new JSONArray();
		this.jsonArray = localJSONArray;
	}

	public JSONArrayPoxy(JSONArray paramJSONArray) {
		this.jsonArray = paramJSONArray;
	}

	public boolean equals(Object paramObject) {
		return this.jsonArray.equals(paramObject);
	}

	public Object get(int paramInt) throws JSONException {
		return this.jsonArray.get(paramInt);
	}

	public boolean getBoolean(int paramInt) throws JSONException {
		return this.jsonArray.getBoolean(paramInt);
	}

	public double getDouble(int paramInt) throws JSONException {
		return this.jsonArray.getDouble(paramInt);
	}

	public int getInt(int paramInt) throws JSONException {
		return this.jsonArray.getInt(paramInt);
	}

	public JSONArrayPoxy getJSONArray(int paramInt) throws JSONException {
		JSONArray localJSONArray = this.jsonArray.getJSONArray(paramInt);
		return new JSONArrayPoxy(localJSONArray);
	}

	public JSONArrayPoxy getJSONArrayOrNull(int paramInt) {
		JSONArrayPoxy localJSONArrayPoxy;
		try {
			JSONArray localJSONArray = this.jsonArray.getJSONArray(paramInt);
			localJSONArrayPoxy = new JSONArrayPoxy(localJSONArray);
			return localJSONArrayPoxy;
		} catch (JSONException localJSONException) {
			localJSONArrayPoxy = null;
		}
		return localJSONArrayPoxy;
	}

	public JSONObjectProxy getJSONObject(int paramInt) throws JSONException {
		JSONObject localJSONObject = this.jsonArray.getJSONObject(paramInt);
		JSONObjectProxy localJSONObjectProxy = new JSONObjectProxy(
				localJSONObject);
		return new JSONObjectProxy(localJSONObjectProxy);
	}

	public JSONObjectProxy getJSONObjectOrNull(int paramInt) {
		JSONObjectProxy localJSONObjectProxy2;
		try {
			JSONObject localJSONObject = this.jsonArray.getJSONObject(paramInt);
			JSONObjectProxy localJSONObjectProxy1 = new JSONObjectProxy(
					localJSONObject);
			localJSONObjectProxy2 = new JSONObjectProxy(localJSONObjectProxy1);
			return localJSONObjectProxy2;
		} catch (JSONException localJSONException) {
			localJSONObjectProxy2 = null;
		}
		return localJSONObjectProxy2;
	}

	public long getLong(int paramInt) throws JSONException {
		return this.jsonArray.getLong(paramInt);
	}

	public String getStringOrNull(int paramInt) {
		try {
			return this.jsonArray.getString(paramInt);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			return null;
		}
	}

	public int hashCode() {
		return this.jsonArray.hashCode();
	}

	public boolean isNull(int paramInt) {
		return this.jsonArray.isNull(paramInt);
	}

	public String join(String paramString) throws JSONException {
		return this.jsonArray.join(paramString);
	}

	public int length() {
		return this.jsonArray.length();
	}

	public Object opt(int paramInt) {
		return this.jsonArray.opt(paramInt);
	}

	public boolean optBoolean(int paramInt) {
		return this.jsonArray.optBoolean(paramInt);
	}

	public boolean optBoolean(int paramInt, boolean paramBoolean) {
		return this.jsonArray.optBoolean(paramInt, paramBoolean);
	}

	public double optDouble(int paramInt) {
		return this.jsonArray.optDouble(paramInt);
	}

	public double optDouble(int paramInt, double paramDouble) {
		return this.jsonArray.optDouble(paramInt, paramDouble);
	}

	public int optInt(int paramInt) {
		return this.jsonArray.optInt(paramInt);
	}

	public int optInt(int paramInt1, int paramInt2) {
		return this.jsonArray.optInt(paramInt1, paramInt2);
	}

	public JSONArray optJSONArray(int paramInt) {
		return this.jsonArray.optJSONArray(paramInt);
	}

	public JSONObject optJSONObject(int paramInt) {
		return this.jsonArray.optJSONObject(paramInt);
	}

	public long optLong(int paramInt) {
		return this.jsonArray.optLong(paramInt);
	}

	public long optLong(int paramInt, long paramLong) {
		return this.jsonArray.optLong(paramInt, paramLong);
	}

	public String optString(int paramInt) {
		return this.jsonArray.optString(paramInt);
	}

	public String optString(int paramInt, String paramString) {
		return this.jsonArray.optString(paramInt, paramString);
	}

	public JSONArray put(double paramDouble) throws JSONException {
		return this.jsonArray.put(paramDouble);
	}

	public JSONArray put(int paramInt) {
		return this.jsonArray.put(paramInt);
	}

	public JSONArray put(int paramInt, double paramDouble) throws JSONException {
		return this.jsonArray.put(paramInt, paramDouble);
	}

	public JSONArray put(int paramInt1, int paramInt2) throws JSONException {
		return this.jsonArray.put(paramInt1, paramInt2);
	}

	public JSONArray put(int paramInt, long paramLong) throws JSONException {
		return this.jsonArray.put(paramInt, paramLong);
	}

	public JSONArray put(int paramInt, Object paramObject) throws JSONException {
		return this.jsonArray.put(paramInt, paramObject);
	}

	public JSONArray put(int paramInt, boolean paramBoolean)
			throws JSONException {
		return this.jsonArray.put(paramInt, paramBoolean);
	}

	public JSONArray put(long paramLong) {
		return this.jsonArray.put(paramLong);
	}

	public JSONArray put(Object paramObject) {
		return this.jsonArray.put(paramObject);
	}

	public JSONArray put(boolean paramBoolean) {
		return this.jsonArray.put(paramBoolean);
	}

	public JSONObject toJSONObject(JSONArray paramJSONArray)
			throws JSONException {
		return this.jsonArray.toJSONObject(paramJSONArray);
	}

	public String toString() {
		return this.jsonArray.toString();
	}

	public String toString(int paramInt) throws JSONException {
		return this.jsonArray.toString(paramInt);
	}

	public JSONArray getJsonArray() {
		return jsonArray;
	}

	public void setJsonArray(JSONArray jsonArray) {
		this.jsonArray = jsonArray;
	}
	
	
}
