package com.xsfuture.xsfuture2.activity.main_module;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.PersonalAllJournalEntryAdapter;
import com.xsfuture.xsfuture2.bean.MyReaderResponseDetails;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.view.xlistview.XListView;

import org.json.JSONException;

import java.util.List;

public class AllJournalEntryActivity extends BaseActivity implements XListView.IXListViewListener {
    private XListView xlV_personal_all_journal_entry;
    private PersonalAllJournalEntryAdapter adapter;

    private int intentPostId;
    private String intentBookName;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_all_journal_entry);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        initData();
        setTitleText("《" + intentBookName + "》");
        setTitleLeftBtn(R.string.back, new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initView();
    }

    private void initData() {
        intentBookName = getIntent().getStringExtra("book_name");
        intentPostId = getIntent().getIntExtra("post_id", 0);
    }

    private void initView() {
        xlV_personal_all_journal_entry = (XListView) findViewById(R.id.xlV_personal_all_journal_entry);
        xlV_personal_all_journal_entry.setPullRefreshEnable(true);
        xlV_personal_all_journal_entry.setPullLoadEnable(false);
        xlV_personal_all_journal_entry.setXListViewListener(this);
        adapter = new PersonalAllJournalEntryAdapter(getCurrentActivity());
        xlV_personal_all_journal_entry.setAdapter(adapter);
        readerResponse("desc", true);
    }

    private void readerResponse(String order, boolean is_show) {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("post_id", intentPostId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                onXListViewStop();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONArrayPoxy data = jSONObjectProxy.getJSONArrayOrNull("data");
                    if (success == 0 && data != null) {
                        if (data.length() > 0) {
                            List<MyReaderResponseDetails> datas = new Gson().fromJson(data.toString(), new TypeToken<List<MyReaderResponseDetails>>() {}.getType());
                            adapter.setData(datas);
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), "网络连接错误，请稍后再试！", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(is_show);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_post_getReaderResponseList + "?order=" + order);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    @Override
    public void onRefresh() {
        readerResponse("desc", false);
    }

    @Override
    public void onLoadMore() {
    }

    @Override
    public void onXListViewStop() {
        xlV_personal_all_journal_entry.stopLoadMore();
        xlV_personal_all_journal_entry.stopRefresh();
    }
}