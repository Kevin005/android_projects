package com.xsfuture.xsfuture2.activity.account_module;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.mob.MobSDK;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.util.StringUtils;

import cn.smssdk.EventHandler;
import cn.smssdk.SMSSDK;

public class FogetPwdTypeVerificationActivity extends BaseActivity {
    private Button register_next;
    private EditText registered_input;
    private EditText verification_code;
    private TextView retry;
    private TextView counter_text;
    private ImageButton phone_clear;

    private int defaulttime = 30;
    private int counter;
    private EventHandler eh;
    public Handler handler = new Handler();
    private Runnable runnable = new Runnable() {
        public void run() {
            counter--;
            counter_text.setText(counter + "秒后可重发");
            if (counter > 0) {
                getHandler().postDelayed(this, 1000);
            } else {
                retry.setVisibility(View.VISIBLE);
                retry.setEnabled(true);
                counter_text.setVisibility(View.GONE);
                counter = defaulttime;// 重置
            }
        }
    };
    private Handler smsCallbackHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    Toast.makeText(getCurrentActivity(), "验证失败，请重新验证", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_registered);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleText("注册");
        setTitleLeftBtn(R.string.back, new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initView();
    }

    @Override
    protected void onResume() {
        initVerCode();
        super.onResume();
    }

    private void initVerCode() {
        MobSDK.init(this, ConstSysConfig.MOB_APP_KEY, ConstSysConfig.MOB_APP_SECRET);
        if (eh == null) {
            eh = new EventHandler() {
                @Override
                public void afterEvent(int event, int result, Object data) {
                    if (result == SMSSDK.RESULT_COMPLETE) {
                        // 回调完成
                        if (event == SMSSDK.EVENT_SUBMIT_VERIFICATION_CODE) {
                            // 提交验证码成功
                            Intent intent = new Intent(FogetPwdTypeVerificationActivity.this, FogetPwdConfirmPwdActivity.class);
                            intent.putExtra("phone", registered_input.getText().toString());
                            startActivity(intent);
                            finish();
                        } else if (event == SMSSDK.EVENT_GET_VERIFICATION_CODE) {
                            // 获取验证码成功
                        } else if (event == SMSSDK.EVENT_GET_SUPPORTED_COUNTRIES) {
                            // 返回支持发送验证码的国家列表
                        }
                    } else {
                        ((Throwable) data).printStackTrace();
                        smsCallbackHandler.sendEmptyMessage(1);
                    }
                }
            };
        }
        SMSSDK.registerEventHandler(eh); // 注册短信回调
    }

    public void post(Runnable action) {
        counter = defaulttime;
        final Runnable ar = action;
        handler.post(new Runnable() {

            @Override
            public void run() {
                if (!isFinishing())
                    ar.run();
            }

        });
    }

    private void initView() {
        registered_input = (EditText) findViewById(R.id.registered_input);
        registered_input.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (checkPhone(s.toString())) {
                    retry.setEnabled(true);
                } else {
                    retry.setEnabled(false);
                }
            }
        });
        verification_code = (EditText) findViewById(R.id.verification_code);
        retry = (TextView) findViewById(R.id.retry);
        retry.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPhone()) {
                    getVerificationCode();
                }
            }
        });
        counter_text = (TextView) findViewById(R.id.counter_text);
        register_next = (Button) findViewById(R.id.register_next);
        register_next.setEnabled(true);
        register_next.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check()) {
                    String phone = registered_input.getText().toString();
                    String code = verification_code.getText().toString();
                    SMSSDK.submitVerificationCode("86", phone, code);
                }
            }
        });
        phone_clear = (ImageButton) findViewById(R.id.phone_clear);
        phone_clear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                registered_input.setText("");
            }
        });
    }

    private boolean check() {
        String phone = registered_input.getText().toString();
        String code = verification_code.getText().toString();
        if (StringUtils.isEmpty(phone) && phone.toString().trim().length() != 11
                && !phone.toString().trim().startsWith("1")) {
            Toast.makeText(FogetPwdTypeVerificationActivity.this, "手机号码格式错误", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (StringUtils.isEmpty(code)) {
            Toast.makeText(FogetPwdTypeVerificationActivity.this, "验证码错误", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean checkPhone() {
        String phone = registered_input.getText().toString();
        if (StringUtils.isEmpty(phone) || phone.toString().trim().length() != 11
                || !phone.toString().trim().startsWith("1")) {
            Toast.makeText(FogetPwdTypeVerificationActivity.this, "手机号码格式错误", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean checkPhone(String phone) {
        if (StringUtils.isEmpty(phone) || phone.toString().trim().length() != 11
                || !phone.toString().trim().startsWith("1")) {
            return false;
        }
        return true;
    }

    private void getVerificationCode() {
        retry.setVisibility(View.GONE);
        counter_text.setVisibility(View.VISIBLE);
        post(runnable);
        String phone = registered_input.getText().toString();
        SMSSDK.getVerificationCode("86", phone);// 发送短信验证码
    }

    @Override
    protected void onStop() {
        if (eh != null) {
            SMSSDK.unregisterEventHandler(eh);
            eh = null;
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null)
            handler.removeCallbacksAndMessages(null);
        if (smsCallbackHandler != null)
            smsCallbackHandler.removeCallbacksAndMessages(null);
    }
}