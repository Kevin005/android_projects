package com.xsfuture.xsfuture2.database;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.xsfuture.xsfuture2.bean.DraftInfo;

public class DraftInfoDBHelper {

    private static String TableName = "DraftInfoTable";

    public static void create(SQLiteDatabase paramSQLiteDatabase) {
        if (paramSQLiteDatabase != null)
            paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + TableName
                    + "(id INTEGER PRIMARY KEY AUTOINCREMENT, " + " PostId INTEGER, " + "ReadedPageNumber INTEGER, "
                    + "Content VARCHAR )");
    }

    public static synchronized void delAll(Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        if (sqlitedatabase != null) {
            sqlitedatabase.delete(TableName, "1=1", null);
        }
        DBHelperUtil.closeDatabase();
    }

    public static synchronized DraftInfo getDraft(int post_id, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        DraftInfo info = null;
        if (sqlitedatabase != null) {
            Cursor c = sqlitedatabase.rawQuery("SELECT * FROM " + TableName + " where PostId = ? ORDER BY id DESC",
                    new String[]{String.valueOf(post_id)});
            while (c.moveToNext()) {
                info = new DraftInfo();
                info.setPostId(c.getInt(c.getColumnIndex("PostId")));
                info.setReadedPageNumber(c.getInt(c.getColumnIndex("ReadedPageNumber")));
                info.setContent(c.getString(c.getColumnIndex("Content")));
                break;
            }
            if (c != null) {
                c.close();
            }
        }
        DBHelperUtil.closeDatabase();
        return info;
    }

    public static synchronized void insertDraft(DraftInfo info, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        if (sqlitedatabase != null) {
            sqlitedatabase.execSQL("INSERT INTO " + TableName + " VALUES(null,?,?,?)", new Object[]{
                    info.getPostId(), info.getReadedPageNumber(), info.getContent()});
        }
        DBHelperUtil.closeDatabase();
    }

    public static synchronized void deleteDraftForPostId(int psot_id, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        if (sqlitedatabase != null) {
            sqlitedatabase.execSQL("DELETE FROM " + TableName + " WHERE PostId = ? ", new Object[]{
                    psot_id});
        }
        DBHelperUtil.closeDatabase();
    }

    public static synchronized void updateDraft(DraftInfo info, Context paramContext) {
        SQLiteDatabase sqlitedatabase = DBHelperUtil.getDatabase(paramContext);
        if (sqlitedatabase != null) {
            ContentValues cv = new ContentValues();
            cv.put("PostId", info.getPostId());
            cv.put("ReadedPageNumber", info.getReadedPageNumber());
            cv.put("Content", info.getContent());
            sqlitedatabase.update(TableName, cv, "PostId=? ", new String[]{String.valueOf(info.getPostId())});
        }
        DBHelperUtil.closeDatabase();
    }

    public static void upgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("drop table if exists " + TableName);
            create(db);
        }
    }
}
