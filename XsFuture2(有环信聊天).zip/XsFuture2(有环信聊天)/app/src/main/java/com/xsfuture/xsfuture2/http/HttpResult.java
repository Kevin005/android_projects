package com.xsfuture.xsfuture2.http;

import java.io.File;
import java.io.InputStream;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import com.xsfuture.xsfuture2.util.JSONObjectProxy;

public class HttpResult {

    private Context context;
    private Bitmap bitmap;
    private JSONObjectProxy jsonObject;
    private File saveFile;
    private int type;
    private InputStream inputStream;
    private byte[] inputData;
    private long length;

    public HttpResult(Context c) {
        context = c;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public JSONObjectProxy getJsonObject() {
        return jsonObject;
    }

    public void setJsonObject(JSONObjectProxy jsonObject) {
        this.jsonObject = jsonObject;
    }

    public File getSaveFile() {
        return saveFile;
    }

    public void setSaveFile(File saveFile) {
        this.saveFile = saveFile;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public InputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    public byte[] getInputData() {
        return inputData;
    }

    public void setInputData(byte[] inputData) {
        this.inputData = inputData;
    }

    public long getLength() {
        return length;
    }

    public void setLength(long length) {
        this.length = length;
    }

    public Drawable getZoomDrawable(float thwidth, float thheight) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float scale;
        if (width > height) {
            scale = thwidth / width;
        } else {
            scale = thheight / height;
        }
        if (scale < 1F) {
            int actual_width = Math.round((float) width * scale);
            int actual_height = Math.round((float) height * scale);
            Bitmap bitmap2 = Bitmap.createScaledBitmap(bitmap, actual_width, actual_height, false);
            return new BitmapDrawable(context.getResources(), bitmap2);
        } else {
            return new BitmapDrawable(context.getResources(), bitmap);
        }
    }

    public Drawable getZoomDrawable(Bitmap bitmap, float thwidth, float thheight) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float scale;
        if (width > height) {
            scale = thwidth / width;
        } else {
            scale = thheight / height;
        }
        if (scale < 1F) {
            int actual_width = Math.round((float) width * scale);
            int actual_height = Math.round((float) height * scale);
            Bitmap bitmap2 = Bitmap.createScaledBitmap(bitmap, actual_width, actual_height, false);
            return new BitmapDrawable(context.getResources(), bitmap2);
        } else {
            return new BitmapDrawable(context.getResources(), bitmap);
        }
    }
}
