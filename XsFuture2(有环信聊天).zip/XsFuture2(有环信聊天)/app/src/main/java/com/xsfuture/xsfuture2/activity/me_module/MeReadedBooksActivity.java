package com.xsfuture.xsfuture2.activity.me_module;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.MeReadedBooksAdapter;
import com.xsfuture.xsfuture2.bean.BookItemInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.view.xlistview.XListView;

import org.json.JSONException;

import java.util.List;

public class MeReadedBooksActivity extends BaseActivity implements XListView.IXListViewListener {
	private XListView readed_books_list;
	private MeReadedBooksAdapter adapter;

	private final int offset = 0;
	private int limit = 1000;

	@Override
	protected void setCurrentContentView() {
		setContentView(R.layout.activity_me_readed_books);
	}

	@Override
	protected void init(Bundle savedInstanceState) {
		setTitleText("读书记录");
		setTitleLeftBtn(R.string.back, new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		initView();
	}

	private void initView() {
		readed_books_list = (XListView) findViewById(R.id.readed_books_list);
		readed_books_list.setPullLoadEnable(false);
		readed_books_list.setPullRefreshEnable(true);
		readed_books_list.setXListViewListener(this);
		adapter = new MeReadedBooksAdapter(getCurrentActivity());
		readed_books_list.setAdapter(adapter);
		finishReaded(true);
	}

	private void finishReaded(boolean is_refresh) {
		JSONObjectProxy obj = new JSONObjectProxy();
		try {
			obj.put("user_id", getUser_id());
		} catch (JSONException e) {
			e.printStackTrace();
		}
		HttpTask httpTask = new HttpTask(getCurrentActivity()) {

			@Override
			public void onStart() {
			}

			@Override
			public void onEnd(HttpResult httpResult) {
				onXListViewStop();
				if (httpResult != null && httpResult.getJsonObject() != null) {
					JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
					int success = jSONObjectProxy.getIntOrNull("success");
					String message = jSONObjectProxy.getStringOrNull("message");
					JSONArrayPoxy data = jSONObjectProxy.getJSONArrayOrNull("data");
					if (success == 0 && data != null) {
						List<BookItemInfo> infos = new Gson().fromJson(data.toString(), new TypeToken<List<BookItemInfo>>() {
						}.getType());
						adapter.setData(infos);
					} else {
						Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
					}
				} else {
					Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
				}
			}

			@Override
			public void onError(HttpError httpError) {
				if (httpError != null) {
					if (httpError.getErrorCode() == HttpError.NONetworkError) {
						Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
					}
				}
			}

			@Override
			public void onProgress(int i, int j) {
			}

		};
		httpTask.setShow_progressbar(is_refresh);
		HttpSetting httpSetting = new HttpSetting();
		httpSetting.setFunctionId(ConstFuncId.xiaoshi_post_getreadedbooks + "?offset=" + offset + "&limit=" + limit
				+ "&is_finished=yes");
		httpSetting.setJsonParams(obj.toString());
		httpSetting.setHttp_type(HttpSetting.HTTP_POST);
		httpSetting.setUrl(ConstHttpProp.base_url);
		httpSetting.setType(ConstHttpProp.TYPE_JSON);
		httpTask.executes(httpSetting);
	}

	@Override
	public void onXListViewStop(){
		readed_books_list.stopRefresh();
		readed_books_list.stopLoadMore();
	}


	@Override
	public void onRefresh() {
		finishReaded(false);
	}

	@Override
	public void onLoadMore() {

	}

}