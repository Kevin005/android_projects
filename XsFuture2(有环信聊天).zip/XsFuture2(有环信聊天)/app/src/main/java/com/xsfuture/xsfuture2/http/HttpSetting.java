package com.xsfuture.xsfuture2.http;

import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.util.FileGuider;
import com.xsfuture.xsfuture2.util.Md5Encrypt;

import java.util.Iterator;
import java.util.Map;

public class HttpSetting {

	public static final int HTTP_GET = 1;
	public static final int HTTP_POST = 2;
	public static final int HTTP_PUT = 3;
	public static final int HTTP_DELETE = 4;
	private int cacheMode = ConstHttpProp.CACHE_MODE_NO;// 默认不缓存

	private long localFileCacheTime;// 超时时间
	private String jsonParams;
	private int http_type;
	private String md5;
	private String url;
	private int priority;
	private int type;
	private String functionId;
	private Map<String, String> mapParams;

	private int readTimeout;
	private int connectTimeout;

	public int imageViewWidth;
	public int imageViewHeight;
	private FileGuider savePath;//

	private String local_file_path;

	public String getJsonParams() {
		return jsonParams;
	}

	public void setJsonParams(String jsonParams) {
		this.jsonParams = jsonParams;
	}

	public int getHttp_type() {
		return http_type;
	}

	public void setHttp_type(int http_type) {
		this.http_type = http_type;
	}

	public String getMd5() {
		if (md5 != null)
			return md5;
		else {
			if (getUrl() != null) {
				int index = appointindexOf(getUrl(), "/", 2);
				if (index != -1) {
					String mds = getUrl().substring(index);
					switch (http_type) {
					case HTTP_GET:
						md5 = Md5Encrypt.md5(mds + "get");
						return md5;
					case HTTP_POST:
						md5 = Md5Encrypt.md5(new StringBuilder(String.valueOf(mds)).append(getJsonParams()).toString()
								+ "post");
						return md5;
					case HTTP_PUT:
						md5 = Md5Encrypt.md5(new StringBuilder(String.valueOf(mds)).append(getJsonParams()).toString()
								+ "put");
						return md5;
					case HTTP_DELETE:
						md5 = Md5Encrypt.md5(new StringBuilder(String.valueOf(mds)).append(getJsonParams()).toString()
								+ "delete");
						return md5;
					default:
						md5 = Md5Encrypt.md5(mds);
						return md5;
					}
				}
			}
		}
		return null;
	}

	private int appointindexOf(String mainString, String subString, int appoint) {
		if (mainString != null) {
			int i = 0;
			int j = 0;
			while (j < appoint + 1) {
				int k = i + 1;
				i = mainString.indexOf(subString, k);
				j++;
			}
			return i;
		} else {
			return -1;
		}
	}

	public void setMd5(String md5) {
		this.md5 = md5;
	}

	public String getUrl() {
		if (url == null || url.trim().equals("")) {
			url = ConstSysConfig.baseUrl;
		}
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public Map<String, String> getMapParams() {
		return mapParams;
	}

	public void setMapParams(Map<String, String> pmapParams) {
		mapParams = pmapParams;

		if (mapParams != null) {
			Iterator<String> iterator = mapParams.keySet().iterator();
			while (iterator.hasNext()) {
				String s = (String) iterator.next();
				String s1 = String.valueOf(mapParams.get(s));
				putMapParams(s, s1);
			}
		}
	}

	public void putMapParams(String name, String value) {
		// TODO Auto-generated method stub
		if (mapParams == null) {
			mapParams = new URLParamMap();
		}
		mapParams.put(name, value);
	}

	public int getReadTimeout() {
		if (readTimeout == 0)
			readTimeout = 60000;
		return readTimeout;
	}

	public void setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
	}

	public int getConnectTimeout() {
		if (connectTimeout == 0)
			connectTimeout = 60000;
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public FileGuider getSavePath() {
		return savePath;
	}

	public void setSavePath(FileGuider savePath) {
		this.savePath = savePath;
	}

	public int getCacheMode() {
		return cacheMode;
	}

	public void setCacheMode(int cacheMode) {
		this.cacheMode = cacheMode;
	}

	public long getLocalFileCacheTime() {
		return localFileCacheTime;
	}

	public void setLocalFileCacheTime(long localFileCacheTime) {
		this.localFileCacheTime = localFileCacheTime;
	}

	public String getLocal_file_path() {
		return local_file_path;
	}

	public void setLocal_file_path(String local_file_path) {
		this.local_file_path = local_file_path;
	}

}
