package com.xsfuture.xsfuture2.util;

import java.io.File;

public class Directory {

	private File dir;
    private String path;
    private int space;
    
    public Directory(File pfile)
    {
    	dir = pfile;
    	path = dir.getAbsolutePath();
    }

    public Directory(File file, int i)
	{
		dir = file;
		space = i;
	}
    
    public Directory(String arg1, int arg2)
    {
    	this(new File(arg1), arg2);
    }
    
	public File getDir() {
		return dir;
	}
	public void setDir(File dir) {
		this.dir = dir;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public int getSpace() {
		return space;
	}
	public void setSpace(int space) {
		this.space = space;
	}
    
    
}
