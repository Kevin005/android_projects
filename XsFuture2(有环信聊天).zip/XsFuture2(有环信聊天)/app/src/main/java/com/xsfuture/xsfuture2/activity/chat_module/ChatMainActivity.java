package com.xsfuture.xsfuture2.activity.chat_module;

import android.content.Context;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hyphenate.EMCallBack;
import com.hyphenate.EMMessageListener;
import com.hyphenate.chat.EMClient;
import com.hyphenate.chat.EMConversation;
import com.hyphenate.chat.EMMessage;
import com.hyphenate.chat.EMTextMessageBody;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.ChatMsgViewAdapter;
import com.xsfuture.xsfuture2.bean.ChatMsgInfo;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.database.UserInfoDBHelper;
import com.xsfuture.xsfuture2.tool.SoundMeter;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.activity.presenter.ChatMainActivityPresenter;
import com.xsfuture.xsfuture2.util.DateUtils;
import com.xsfuture.xsfuture2.util.Log;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Created by Kevin on 2017/5/31.
 */

public class ChatMainActivity extends BaseActivity implements View.OnClickListener {
    private final String TAG = ChatMainActivity.class.getName();
    private TextView tvRcd;
    private EditText etMessageContent;
    private RelativeLayout mBottom;
    private ListView lvMsgList;
    private ChatMsgViewAdapter mAdapter;
    private LinearLayout voice_rcd_hint_loading, voice_rcd_hint_rcding, voice_rcd_hint_tooshort;
    private ImageView img1, sc_img1;
    private SoundMeter mSensor;
    private View rcChat_popup;
    private LinearLayout del_re;
    private ImageView chatting_mode_btn, volume;

    private UserInfo myInfo;
    private boolean btn_vocie = false;
    private String voiceName;
    private long startVoiceT, endVoiceT;
    private String sell_user_name;
    private String sell_user_phone_num;
    private EMMessageListener msgListener;
    private ChatMainActivityPresenter presenter;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_chat_main);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        initExtra();
        initView();
        initViewData();
        addListenForEmMsg();
    }

    private void initExtra() {
        sell_user_name = getIntent().getStringExtra("sell_user_name");
        sell_user_phone_num = getIntent().getStringExtra("sell_user_phone_num");
        myInfo = UserInfoDBHelper.getUser(getUser_id(), getCurrentActivity());
        presenter = new ChatMainActivityPresenter(getCurrentActivity());
    }

    public void initView() {
        lvMsgList = (ListView) findViewById(R.id.lv_msg_list);
        lvMsgList.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    InputMethodManager imm1 = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm1.hideSoftInputFromWindow(etMessageContent.getWindowToken(), 0);
                }
                return false;
            }
        });
        findViewById(R.id.btn_send).setOnClickListener(this);
        tvRcd = (TextView) findViewById(R.id.tv_rcd);
        mBottom = (RelativeLayout) findViewById(R.id.btn_bottom);
        chatting_mode_btn = (ImageView) findViewById(R.id.ivPopUp);
        volume = (ImageView) this.findViewById(R.id.volume);
        rcChat_popup = this.findViewById(R.id.rcChat_popup);
        img1 = (ImageView) this.findViewById(R.id.img1);
        sc_img1 = (ImageView) this.findViewById(R.id.sc_img1);
        del_re = (LinearLayout) this.findViewById(R.id.del_re);
        voice_rcd_hint_rcding = (LinearLayout) findViewById(R.id.voice_rcd_hint_rcding);
        voice_rcd_hint_loading = (LinearLayout) findViewById(R.id.voice_rcd_hint_loading);
        voice_rcd_hint_tooshort = (LinearLayout) findViewById(R.id.voice_rcd_hint_tooshort);
        mSensor = new SoundMeter();
        etMessageContent = (EditText) findViewById(R.id.et_message_content);
        chatting_mode_btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tvRcd.setVisibility(View.GONE);
                mBottom.setVisibility(View.VISIBLE);
                chatting_mode_btn.setImageResource(R.drawable.chatting_setmode_msg_btn);
            }
        });
        tvRcd.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });

    }

    @Override
    public void finish() {
        super.finish();
        initConversationToDB();
    }

    private void initConversationToDB() {
        EMConversation conversation = EMClient.getInstance().chatManager().getConversation(sell_user_phone_num);
        if (conversation != null) {
            presenter.initConversationToDB(conversation, sell_user_name, sell_user_phone_num);
        }
    }

    public void initViewData() {
        mAdapter = new ChatMsgViewAdapter(getCurrentActivity());
        lvMsgList.setAdapter(mAdapter);
        EMConversation conversation = EMClient.getInstance().chatManager().getConversation(sell_user_phone_num);
        if (conversation != null) {
            presenter.initConversationToDB(conversation, sell_user_name, sell_user_phone_num);
            List<EMMessage> messages = conversation.getAllMessages();
            //SDK初始化加载的聊天记录为20条，到顶时需要去DB里获取更多
            //获取startMsgId之前的pagesize条消息，此方法获取的messages SDK会自动存入到此会话中，APP中无需再次把获取到的messages添加到会话中
//        List<EMMessage> messages = conversation.loadMoreMsgFromDB(startMsgId, pagesize);
            if (messages != null && messages.size() > 0) {
                List<ChatMsgInfo> msgInfos = new ArrayList<>();
                for (EMMessage message : messages) {
                    ChatMsgInfo msgInfo = new ChatMsgInfo();
                    msgInfo.setText(message.getBody().toString());
                    message.getChatType();
                    msgInfo.setDate(DateUtils.stamp2CnYMDHM(message.getMsgTime()));
                    if (message.direct().name().equals("SEND")) {
                        msgInfo.setMsgType(false);
                        msgInfo.setName(myInfo.getNick_name());
                    } else {
                        msgInfo.setMsgType(true);
                    }
                    msgInfos.add(msgInfo);
                }
                mAdapter.setData(msgInfos);
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_send:
                send();
                break;
        }
    }

    private void send() {
        String msgContent = etMessageContent.getText().toString();
        if (msgContent.length() > 0) {
            sendEmMsg(msgContent, sell_user_phone_num);
            ChatMsgInfo entity = new ChatMsgInfo();
            entity.setDate(getDate());
            entity.setName(myInfo.getNick_name());
            entity.setMsgType(false);
            entity.setText(msgContent);
            mAdapter.addData(entity);
            etMessageContent.setText("");
            lvMsgList.setSelection(lvMsgList.getCount() - 1);
        }
    }

    private void sendEmMsg(String content, String toChatUsername) {
        EMMessage message = EMMessage.createTxtSendMessage(content, toChatUsername);
        //发送消息
        EMClient.getInstance().chatManager().sendMessage(message);
        message.setMessageStatusCallback(new EMCallBack() {
            @Override
            public void onSuccess() {
                Log.d(TAG, "send message success");
            }

            @Override
            public void onError(int i, String s) {
                Log.d(TAG, "send message error");
            }

            @Override
            public void onProgress(int i, String s) {
                Log.d(TAG, "send message progress");
            }
        });
    }

    private void addListenForEmMsg() {
        msgListener = new EMMessageListener() {
            @Override
            public void onMessageReceived(List<EMMessage> messages) {
                //收到消息
                for (EMMessage message : messages) {
                    showShortToast("get success");
                    Log.e("TAG", message.toString());
                    EMTextMessageBody txtBody = (EMTextMessageBody) message.getBody();

                    ChatMsgInfo entity = new ChatMsgInfo();
                    entity.setDate(getDate());
                    entity.setName("a");
                    entity.setMsgType(true);
                    entity.setText(txtBody.getMessage());
                    mAdapter.addData(entity);
                    scrollMyListViewToBottom();
                }
            }

            @Override
            public void onCmdMessageReceived(List<EMMessage> messages) {
                //收到透传消息
            }

            @Override
            public void onMessageReadAckReceived(List<EMMessage> messages) {
                //收到已读回执
            }

            @Override
            public void onMessageDeliveryAckReceived(List<EMMessage> message) {
                //收到已送达回执
            }

            @Override
            public void onMessageChanged(EMMessage message, Object change) {
                //消息状态变动
            }
        };
        EMClient.getInstance().chatManager().addMessageListener(msgListener);
    }

    private void scrollMyListViewToBottom() {
        lvMsgList.post(new Runnable() {
            @Override
            public void run() {
                lvMsgList.setSelection(mAdapter.getCount() - 1);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EMClient.getInstance().chatManager().removeMessageListener(msgListener);
    }

    private String getDate() {
        Calendar c = Calendar.getInstance();
        String year = String.valueOf(c.get(Calendar.YEAR));
        String month = String.valueOf(c.get(Calendar.MONTH));
        String day = String.valueOf(c.get(Calendar.DAY_OF_MONTH) + 1);
        String hour = String.valueOf(c.get(Calendar.HOUR_OF_DAY));
        String mins = String.valueOf(c.get(Calendar.MINUTE));

        StringBuffer sbBuffer = new StringBuffer();
        sbBuffer.append(year + "-" + month + "-" + day + " " + hour + ":"
                + mins);
        return sbBuffer.toString();
    }
}
