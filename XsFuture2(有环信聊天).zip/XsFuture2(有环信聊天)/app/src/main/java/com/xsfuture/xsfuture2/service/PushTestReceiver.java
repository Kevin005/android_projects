package com.xsfuture.xsfuture2.service;

import android.content.Context;

import com.baidu.android.pushservice.PushMessageReceiver;
import com.xsfuture.xsfuture2.activity.presenter.PushTestReceiverPresenter;
import com.xsfuture.xsfuture2.util.Log;

import java.util.List;

public class PushTestReceiver extends PushMessageReceiver {

    @Override
    public void onBind(Context context, int errorCode, String appid, String userId, String channelId, String requestId) {
        PushTestReceiverPresenter.getInstance().postChannelId(context, channelId);
    }

    @Override
    public void onUnbind(Context context, int i, String s) {

    }

    @Override
    public void onSetTags(Context context, int i, List<String> list, List<String> list1, String s) {

    }

    @Override
    public void onDelTags(Context context, int i, List<String> list, List<String> list1, String s) {

    }

    @Override
    public void onListTags(Context context, int i, List<String> list, String s) {

    }

    @Override
    public void onMessage(Context context, String s, String s1) {
        PushTestReceiverPresenter.getInstance().setNoReadMessage(context);
        Log.e("onMessage", s);
    }

    @Override
    public void onNotificationClicked(Context context, String s, String s1, String s2) {
        Log.e("onNotificationClicked", s + s1);
    }

    @Override
    public void onNotificationArrived(Context context, String s, String s1, String s2) {
        Log.e("onNotificationArrived", s + s1);
    }
}
