/*********************************************************************/
/*  文件名  StringUtils.java    　                                   */
/*  程序名  字符串工具类                     						 */
/*  版本履历   2014/09/25  新建                  陈豪    			 */
/* 		       2014/09/26  UI1.0变更             陈豪  				 */
/*         Copyright 2014 DILIN. All Rights Reserved.                */
/*********************************************************************/
package com.xsfuture.xsfuture2.util;

import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * 字符串工具类
 * 
 */
public class StringUtils {
	/**
	 * 随机实例
	 */
	private static final Random DEFULT_RANDOM = new Random();

	/**
	 * 判断字符串不为空并且不为提示字符
	 * 
	 * @param value
	 *            字符串
	 * @param hint
	 *            提示字符
	 * @return true:不为空且不为提示字符，false:为空或为提示字符
	 */
	public static boolean validateString(String value, String hint) {
		if (!isEmpty(value) && !value.equals(hint)) {
			return true;
		}
		return false;
	}
	
	public static boolean sTring (String hint,String hintStr){
		if(hint.length() == hintStr.length()){
			return true;
		}
		return false;
	}

	/**
	 * 判断字符串不为空并且不为提示字符
	 * 
	 * @param value
	 *            字符串
	 * @param hint
	 *            提示字符
	 * @return true:不为空且不为提示字符，false:为空或为提示字符
	 */
	public static boolean validateString(Object value, String hint) {
		if (!isEmpty(value) && !value.equals(hint)) {
			return true;
		}
		return false;
	}

	/**
	 * 判断字符串是否为空
	 * 
	 * @param value
	 *            字符串
	 * @return true:为空,false:不为空
	 */
	public static boolean isEmpty(Object value) {
		if (value == null || value.toString().trim().length() == 0) {
			return true;
		}
		return false;
	}

	/**
	 * 去除制表符、空格、回车、换行
	 * 
	 * @param str
	 *            原字符串
	 * @return 去除制表符后的字符串
	 */
	public static String filterBlankTag(String str) {
		String dest = "";
		if (str != null) {
			Pattern p = Pattern.compile("\\s*|\t|\r|\n");
			Matcher m = p.matcher(str);
			dest = m.replaceAll("");
		}
		return dest;
	}

	/**
	 * 按Byte位数截取字符串
	 * 
	 * @param str
	 *            字符串
	 * @param byteLen
	 *            byte位数
	 * @param paddingSuffix
	 *            超长补位符，一般为省略号
	 * @return 截取后的字符串
	 */
	public static String subStrB(String str, int byteLen, String paddingSuffix) {
		if (str == null) {
			return str;
		}
		int suffixLen = paddingSuffix.getBytes().length;

		StringBuffer sbuffer = new StringBuffer();
		char[] chr = str.trim().toCharArray();
		int len = 0;
		for (int i = 0; i < chr.length; i++) {
			if (chr[i] >= 0xa1) {
				len += 2;
			} else {
				len++;
			}
		}

		if (len <= byteLen) {
			return str;
		}

		len = 0;
		for (int i = 0; i < chr.length; i++) {

			if (chr[i] >= 0xa1) {
				len += 2;
				if (len + suffixLen > byteLen) {
					break;
				} else {
					sbuffer.append(chr[i]);
				}
			} else {
				len++;
				if (len + suffixLen > byteLen) {
					break;
				} else {
					sbuffer.append(chr[i]);
				}
			}
		}
		sbuffer.append(paddingSuffix);
		return sbuffer.toString();
	}

	/**
	 * 判断字符串是否正确格式的手机号码
	 * 
	 * @param mobiles
	 *            手机号码
	 * @return true:格式正确,false:格式错误
	 */
	public static boolean isMobileNO(String mobiles) {
		Pattern p = Pattern.compile("^((13[0-9])|(14[5,7])|(15[^4,\\D])|(17[6-8])|(18[0-9]))\\d{8}$");
		Matcher m = p.matcher(mobiles);
		return m.matches();
	}

	/**
	 * 判断包含文字的字符串是否正确格式的手机号码
	 * 
	 * @param chatMsg
	 *            可能包含文字的字符串
	 * @return true:格式正确,false:格式错误
	 */
	public static String isMobileNumber(String chatMsg) {
		// 更改上面的手机正则时勿忘更改此处正则表达式
		Pattern pattern = Pattern
				.compile("(?<!\\d)(((13[0-9])|(14[5,7])|(15[^4,\\D])|(17[6-8])|(18[0-9]))\\d{8})(?!\\d)");
		Matcher matcher = pattern.matcher(chatMsg);

		while (matcher.find()) {
			String number = matcher.group();
			chatMsg = chatMsg.replace(number, number.subSequence(0, 3) + "***" + number.substring(10));
		}
		return chatMsg;
	}

	/**
	 * 生成随机验证码
	 * 
	 * @param len
	 *            验证码位数
	 * @return 随机验证码
	 */
	public static String makeRandom(int len) {

		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < len; i++) {
			buffer.append(DEFULT_RANDOM.nextInt(10));
		}
		return buffer.toString();
	}

	/**
	 * 将中文标点替换为英文标点
	 *
	 * @return 替换后的文本
	 */
	public static String replacePunctuation(String text) {
		text = text.replace('，', ',').replace('。', '.').replace('【', '[').replace('】', ']')
				.replace('？', '?').replace('！', '!').replace('（', '(').replace('）', ')').replace
						('“', '"').replace('”', '"');
		return text;
	}
}
