package com.xsfuture.xsfuture2.fragment;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.base.FrameMainActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.me_module.MeFansActivity;
import com.xsfuture.xsfuture2.activity.me_module.MeFousOnManActivity;
import com.xsfuture.xsfuture2.activity.me_module.MeReadedBooksActivity;
import com.xsfuture.xsfuture2.activity.me_module.MeSettingActivity;
import com.xsfuture.xsfuture2.activity.me_module.ReaderResponseMessageActivity;
import com.xsfuture.xsfuture2.activity.tool.SelectPicActivity;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.database.UserInfoDBHelper;
import com.xsfuture.xsfuture2.http.HttpUploadFileTask;
import com.xsfuture.xsfuture2.activity.presenter.PushTestReceiverPresenter;
import com.xsfuture.xsfuture2.util.FileService;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.view.CircularImage;

import java.io.File;

public class MeFragment extends BaseFragment implements OnClickListener {
    private TextView name;
    private LinearLayout userinfo_layout;
    private CircularImage user_avatar;
    private TextView tv_red_remind;

    private final int TO_SELECT_PHOTO = 1;
    private final int PHOTO_REQUEST_CUT = 2;
    private String end_name;
    private UserInfo info;

    @Override
    protected View setCurrentContentView(LayoutInflater inflater, ViewGroup container) {
        View view = inflater.inflate(R.layout.fragment_me, container, false);
        setCurrentActivity((FrameMainActivity) getActivity());
        return view;
    }

    @Override
    protected void init(View view, Bundle savedInstanceState) {
        initView(view);
    }

    @Override
    public void onResume() {
        super.onResume();
        isNoReadMessage();
    }

    private void isNoReadMessage() {
        boolean isNoReadMessage = PushTestReceiverPresenter.getInstance().isNoReadMessage(getCurrentActivity());
        if (isNoReadMessage) {
            tv_red_remind.setVisibility(View.VISIBLE);
        } else {
            tv_red_remind.setVisibility(View.GONE);
        }
    }

    private void initView(View view) {
        tv_red_remind = (TextView) view.findViewById(R.id.tv_red_remind);
        TextView name = (TextView) view.findViewById(R.id.name);
        info = UserInfoDBHelper.getUser(getCurrentActivity().getUser_id(), getCurrentActivity());
        name.setText(info.getNick_name());
        view.findViewById(R.id.rel_readed_books).setOnClickListener(this);
        view.findViewById(R.id.rel_focus_on_man).setOnClickListener(this);
        view.findViewById(R.id.rel_fans).setOnClickListener(this);
        view.findViewById(R.id.rel_setting).setOnClickListener(this);
        view.findViewById(R.id.rel_message).setOnClickListener(this);
        user_avatar = (CircularImage) view.findViewById(R.id.user_avatar);
        setAvatar(getUserImage());
        userinfo_layout = (LinearLayout) view.findViewById(R.id.userinfo_layout);
        userinfo_layout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), SelectPicActivity.class);
                startActivityForResult(intent, TO_SELECT_PHOTO);
            }
        });
    }

    private void setAvatar(String str) {
        Glide.with(getCurrentActivity())
                .load(str)
                .placeholder(R.drawable.avatar)
                .error(R.drawable.avatar)
                .skipMemoryCache(false)//跳过内存缓存
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(user_avatar);
    }

    private String getUserImage() {
        UserInfo info = UserInfoDBHelper.getUser(getCurrentActivity().getUser_id(), getCurrentActivity());
        return info.getImage();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rel_readed_books:
                Intent intent = new Intent(getCurrentActivity(), MeReadedBooksActivity.class);
                startActivity(intent);
                break;
            case R.id.rel_focus_on_man:
                Intent intent1 = new Intent(getCurrentActivity(), MeFousOnManActivity.class);
                startActivity(intent1);
                break;
            case R.id.rel_fans:
                Intent intent2 = new Intent(getCurrentActivity(), MeFansActivity.class);
                startActivity(intent2);
                break;
            case R.id.rel_setting:
                Intent intent3 = new Intent(getCurrentActivity(), MeSettingActivity.class);
                startActivity(intent3);
                break;
            case R.id.rel_message:
                Intent intent5 = new Intent(getCurrentActivity(), ReaderResponseMessageActivity.class);
                startActivity(intent5);
                break;
            default:
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == TO_SELECT_PHOTO) {
                String picPath = data.getStringExtra(SelectPicActivity.KEY_PHOTO_PATH);
                if (picPath != null) {
                    int i = picPath.lastIndexOf(".");
                    if (i > 0 && i < picPath.length()) {
                        end_name = picPath.substring(i);
                    }
                    crop(Uri.fromFile(new File(picPath)));
                }
            } else if (requestCode == PHOTO_REQUEST_CUT) {
                Bitmap bitmap = data.getParcelableExtra("data");
                String file_path = FileService.getTempPath() + "/" + "temp" + end_name;
                file_path = FileService.saveBitmap(bitmap, file_path);
                sendFile(file_path);
                user_avatar.setImageBitmap(bitmap);

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void crop(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        // 裁剪框的比例，1：1
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // 裁剪后输出图片的尺寸大小
        intent.putExtra("outputX", 250);
        intent.putExtra("outputY", 250);
        intent.putExtra("outputFormat", "JPEG");
        // 取消人脸识别
        intent.putExtra("noFaceDetection", true);
        // true:不返回uri，false：返回uri
        intent.putExtra("return-data", true);
        startActivityForResult(intent, PHOTO_REQUEST_CUT);
    }

    private void sendFile(String picPath) {
        HttpUploadFileTask fileTask = new HttpUploadFileTask(getCurrentActivity(), picPath, "image") {

            @Override
            public boolean isStop() {
                return false;
            }

            @Override
            public void stop() {
            }

            @Override
            public void onError() {
            }

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(JSONObjectProxy result) {
                if (result != null) {
                    int success = result.getIntOrNull("success");
                    String message = result.getStringOrNull("message");
                    String data = result.getStringOrNull("data");
                    if (success == 0) {
                        info.setImage(data);
                        UserInfoDBHelper.updateUser(info, getCurrentActivity());
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        fileTask.executes(ConstHttpProp.base_url + ConstFuncId.xiaoshi_image_upload_p + "?image_type=p");
    }
}
