package com.xsfuture.xsfuture2.util;

import android.content.Context;
import android.content.SharedPreferences;

import com.xsfuture.xsfuture2.config.ConstSysConfig;

public class PrefUtils {

    private static SharedPreferences getPref(Context context) {
        return context.getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, Context.MODE_PRIVATE);
    }

    public static int getUserId(Context context) {
        return getPref(context).getInt("userId", 0);
    }

    public static void putUserId(Context context, int user_id) {
        getPref(context).edit().putInt("userId", user_id).commit();
    }

    public static String getUserToken(Context context) {
        return getPref(context).getString("token", "");
    }

    public static void putUserToken(Context context, String user_token) {
        getPref(context).edit().putString("token", user_token).commit();
    }

    //--------------------------------
    public boolean getBooleanFromPreference(Context context, String s) {
        return getPref(context).getBoolean(s, false);
    }

    public boolean getBooleanFromPreference(Context context, String s, boolean flag) {
        return getPref(context).getBoolean(s, flag);
    }

    public String getStringFromPreference(Context context, String s) {
        return getPref(context).getString(s, "");
    }

    public String getStringFromPreference(Context context, String s, String defaultValue) {
        return getPref(context).getString(s, defaultValue);
    }

    public int getIntFromPreference(Context context, String s, int defaultValue) {
        return getPref(context).getInt(s, defaultValue);
    }

    public void putBooleanToPreference(Context context, String s, Boolean value) {
        getPref(context).edit().putBoolean(s, value.booleanValue()).commit();
    }

    public void putStringToPreference(Context context, String s, String value) {
        getPref(context).edit().putString(s, value).commit();
    }

    public void removePreference(Context context, String s) {
        getPref(context).edit().remove(s);
    }
}
