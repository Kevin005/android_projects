package com.xsfuture.xsfuture2.activity.account_module;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.activity.presenter.LoginActivityPresenter;
import com.xsfuture.xsfuture2.util.StringUtils;

public class LoginActivity extends BaseActivity {
    private Button btnRegister;
    private Button btnLogin;
    private EditText edtPhoneInput;
    private EditText edtPwdInput;
    private ImageButton imgBtnPhoneClear;
    private TextView tvForgetPwd;

    private LoginActivityPresenter presenter;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_login);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleLeftBtn(R.string.back, new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initPresenter();
        initView();
    }

    private void initPresenter() {
        presenter = new LoginActivityPresenter(getCurrentActivity());
    }

    private void initView() {
        edtPhoneInput = (EditText) findViewById(R.id.edt_phone_input);
        edtPwdInput = (EditText) findViewById(R.id.edt_pwd_input);
        btnLogin = (Button) findViewById(R.id.btn_login);
        btnLogin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkInput()) {
                    LoginActivityPresenter.LoginInfo info = presenter.new LoginInfo();
                    info.setPhone_input(edtPhoneInput.getText().toString());
                    info.setPwd_input(edtPwdInput.getText().toString());
                    presenter.login(info);
                }
            }
        });
        btnRegister = (Button) findViewById(R.id.btn_register);
        btnRegister.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), RegisteredActivity.class);
                startActivity(intent);
            }
        });
        tvForgetPwd = (TextView) findViewById(R.id.tv_forget_pwd);
        tvForgetPwd.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getCurrentActivity(), FogetPwdTypeVerificationActivity.class));
            }
        });
        imgBtnPhoneClear = (ImageButton) findViewById(R.id.imgBtn_phone_clear);
        imgBtnPhoneClear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                edtPhoneInput.setText("");
            }
        });
    }

    private boolean checkInput() {
        String phoneInput = edtPhoneInput.getText().toString();
        String pwdInput = edtPwdInput.getText().toString();
        if (StringUtils.isEmpty(phoneInput)) {
            showShortToast(R.string.please_input_phone_num);
            return false;
        }
        if (StringUtils.isEmpty(pwdInput)) {
            showShortToast(R.string.please_input_pwd);
            return false;
        }
        return true;
    }

}