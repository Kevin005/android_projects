package com.xsfuture.xsfuture2.bean;

import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.util.StringUtils;

/**
 * Created by liuwei on 2016/10/10.
 */
public class CommentsItemInfo {
    private int comment_id;
    private int user_id;
    private int reader_response_id;
    private String content;
    private String push_time;
    private int reply_id;
    private long time_stamp;
    private String user_image;
    private String nick_name;
    private int gender;//man:0,women:1

    public int getReader_response_id() {
        return reader_response_id;
    }

    public void setReader_response_id(int reader_response_id) {
        this.reader_response_id = reader_response_id;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getUser_image() {
        if (!StringUtils.isEmpty(user_image) && user_image.contains("http://115.28.56.168")) {
            return user_image;
        }
        return ConstHttpProp.img_base_url + user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getNick_name() {
        return nick_name;
    }

    public void setNick_name(String nick_name) {
        this.nick_name = nick_name;
    }

    public long getTime_stamp() {
        return time_stamp;
    }

    public void setTime_stamp(long time_stamp) {
        this.time_stamp = time_stamp;
    }

    public int getComment_id() {
        return comment_id;
    }

    public void setComment_id(int comment_id) {
        this.comment_id = comment_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPush_time() {
        return push_time;
    }

    public void setPush_time(String push_time) {
        this.push_time = push_time;
    }

    public int getReply_id() {
        return reply_id;
    }

    public void setReply_id(int reply_id) {
        this.reply_id = reply_id;
    }

}
