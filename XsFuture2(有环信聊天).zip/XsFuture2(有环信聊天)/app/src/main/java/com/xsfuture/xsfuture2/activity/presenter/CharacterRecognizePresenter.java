package com.xsfuture.xsfuture2.activity.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.baidu.ocr.sdk.OCR;
import com.baidu.ocr.sdk.OnResultListener;
import com.baidu.ocr.sdk.exception.OCRError;
import com.baidu.ocr.sdk.model.AccessToken;
import com.baidu.ocr.sdk.model.GeneralParams;
import com.baidu.ocr.sdk.model.GeneralResult;
import com.baidu.ocr.sdk.model.Word;
import com.baidu.ocr.sdk.model.WordSimple;
import com.xsfuture.xsfuture2.config.ConstSysConfig;

import java.io.File;

/**
 * Created by Kevin on 2017/9/29.
 */

public class CharacterRecognizePresenter {
    private boolean hasGotToken = false;
    public static final int FAILED_CODE_0 = 0;//recognize success
    public static final int FAILED_CODE_1 = 1;//get token failed
    public static final int FAILED_CODE_2 = 2;//recognize failed

    public CharacterRecognizePresenter(Context context){
        initAccessTokenWithAkSk(context);
    }

    private void initAccessTokenWithAkSk(Context context) {
        OCR.getInstance().initAccessTokenWithAkSk(new OnResultListener<AccessToken>() {
            @Override
            public void onResult(AccessToken result) {
                String token = result.getAccessToken();
                hasGotToken = true;
            }

            @Override
            public void onError(OCRError error) {
                error.printStackTrace();
                hasGotToken = false;
            }
        }, context, ConstSysConfig.BAIDU_CHARACTER_RECOGNIZE_AK, ConstSysConfig.BAIDU_CHARACTER_RECOGNIZE_SK);
    }

    public interface RecognizeGeneralResult {
        void onSuccess(String resultStr);

        void onFailed(int resultStr);
    }

    public void start(String filePath, final RecognizeGeneralResult callback) {
        if (!hasGotToken && callback != null) {
            callback.onFailed(FAILED_CODE_1);
            return;
        }
        if (TextUtils.isEmpty(filePath)) {
            throw new IllegalArgumentException("FilePath cannot be empty.");
        }
        // 通用文字识别参数设置
        GeneralParams param = new GeneralParams();
        param.setDetectDirection(true);
        param.setImageFile(new File(filePath));
        // 调用通用文字识别服务
        OCR.getInstance().recognizeGeneral(param, new OnResultListener<GeneralResult>() {
            @Override
            public void onResult(GeneralResult result) {
                StringBuilder sb = new StringBuilder();
                // 调用成功，返回GeneralResult对象
                for (WordSimple wordSimple : result.getWordList()) {
                    // Word类包含位置信息
                    Word word = (Word) wordSimple;
                    sb.append(word.getWords());
                    sb.append("\n");
                }
                if (callback != null)
                    callback.onSuccess(sb.toString());
            }

            @Override
            public void onError(OCRError error) {
                if (callback != null)
                    callback.onFailed(FAILED_CODE_2);
            }
        });
    }

    public void release() {
        OCR.getInstance().release();
    }
}
