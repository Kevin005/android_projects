package com.xsfuture.xsfuture2.bean;

/**
 * Created by liuwei on 2016/10/18.
 */
public class BookItemInfo {
    private String book_name;
    private String image;
    private int post_id;
    private int last_date;
    private String author;
    private int readed_days;
    private double progress;
    private int favor_total;
    
    public int getLast_date() {
        return last_date;
    }

    public void setLast_date(int last_date) {
        this.last_date = last_date;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getReaded_days() {
        return readed_days;
    }

    public void setReaded_days(int readed_days) {
        this.readed_days = readed_days;
    }

    public double getProgress() {
        return progress;
    }

    public void setProgress(double progress) {
        this.progress = progress;
    }

    public int getFavor_total() {
        return favor_total;
    }

    public void setFavor_total(int favor_total) {
        this.favor_total = favor_total;
    }

    public int getPost_id() {
        return post_id;
    }

    public void setPost_id(int post_id) {
        this.post_id = post_id;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
