package com.xsfuture.xsfuture2.activity.main_module;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.tool.SelectPicActivity;
import com.xsfuture.xsfuture2.bean.BookInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.task.LoadDoubanBookInfoTask;
import com.xsfuture.xsfuture2.util.FileService;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.StringUtils;
import com.xsfuture.xsfuture2.util.zxing.android.CaptureActivity;
import com.xsfuture.xsfuture2.util.zxing.android.Intents;
import com.xsfuture.xsfuture2.view.CheckSwitchButton;

import org.json.JSONException;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ReleasePlanActivity extends BaseActivity {
    private EditText titeForBook;
    private EditText athorForBook;
    private EditText total_number_pages;
    private Button release_plan;
    private ImageView book_img;
    private Button edtTxt_search_books;
    private ImageView iv_scan_books;
    private CheckSwitchButton mCheckSwithcButton;
    private ImageView iv_book;
    private TextView tv_permissions;

    private boolean is_private = false;//public:false  private:true
    private final int PIC_REQUESTCODE = 1;
    private final int PHOTO_REQUEST_CUT = 2;
    private final int SCAN_BOOKS = 3;
    private final int SEARCH_BOOKS = 4;
    private String end_name;
    private BookInfo info;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            info = (BookInfo) msg.obj;
            if (info != null) {
                refreshView(info);
            } else {
                Toast.makeText(getCurrentActivity(), "没有找到图书哦", Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_release_plan);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleText("发布书籍");
        setTitleLeftBtn(R.string.back, new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initView();
    }

    private void initView() {
        tv_permissions = (TextView) findViewById(R.id.tv_permissions);
        iv_book = (ImageView) findViewById(R.id.iv_book);
        iv_book.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO
            }
        });
        mCheckSwithcButton = (CheckSwitchButton) findViewById(R.id.mCheckSwithcButton);
        mCheckSwithcButton.setChecked(true);
        is_private = false;
        mCheckSwithcButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    is_private = false;
                    tv_permissions.setText("公开");
                } else {
                    is_private = true;
                    tv_permissions.setText("私人");
                }
            }
        });
        edtTxt_search_books = (Button) findViewById(R.id.edtTxt_search_books);
        edtTxt_search_books.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), SearchBookListActivity.class);
                startActivityForResult(intent, SEARCH_BOOKS);
            }
        });
        iv_scan_books = (ImageView) findViewById(R.id.iv_scan_books);
        iv_scan_books.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), CaptureActivity.class);
                startActivityForResult(intent, SCAN_BOOKS);
            }
        });

        titeForBook = (EditText) findViewById(R.id.tite);
        athorForBook = (EditText) findViewById(R.id.athor);
        total_number_pages = (EditText) findViewById(R.id.total_number_pages);

        release_plan = (Button) findViewById(R.id.release_plan);
        release_plan.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check()) {
                    releasePlan();
                }
            }
        });
    }

    private boolean check() {
        String title = titeForBook.getText().toString();
        String total_number = total_number_pages.getText().toString();
        if (StringUtils.isEmpty(title)) {
            showShortToast("请填写书名");
            return false;
        }
        if (!total_number.matches("[0-9]+")) {
            showShortToast("页数格式错误");
            return false;
        }
        if (StringUtils.isEmpty(total_number) || Integer.parseInt(total_number.trim()) == 0) {
            showShortToast("请填写总页数");
            return false;
        }
        return true;
    }

    private void releasePlan() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("book_name", titeForBook.getText().toString());
            obj.put("is_private", is_private);
            obj.put("page_total", Integer.parseInt(total_number_pages.getText().toString()));
            obj.put("author", athorForBook.getText().toString());
            obj.put("image", StringUtils.isEmpty(info) ? "" : info.getImages().getLarge());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        Intent intent = new Intent(getCurrentActivity(), MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.post_create);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            switch (requestCode) {
                case PIC_REQUESTCODE:
                    String picPath = data.getStringExtra(SelectPicActivity.KEY_PHOTO_PATH);
                    if (picPath != null) {
                        int i = picPath.lastIndexOf(".");
                        if (i > 0 && i < picPath.length()) {
                            end_name = picPath.substring(i);
                        }
                        crop(Uri.fromFile(new File(picPath)));
                    }
                    break;
                case PHOTO_REQUEST_CUT:
                    Bitmap bitmap = data.getParcelableExtra("data");
                    String file_path = FileService.getTempPath() + "/" + "temp" + end_name;
                    file_path = FileService.saveBitmap(bitmap, file_path);
//                    sendFile(file_path);
                    break;
                case SCAN_BOOKS:
                    String isbnStr = data.getStringExtra(Intents.Scan.DECODED_CONTENT_KEY);
                    String urlstr = ConstHttpProp.douban_api_url + ConstFuncId.book_isbn + isbnStr;
                    new DownloadThread(urlstr).start();
                    break;
                case SEARCH_BOOKS:
                    if (!StringUtils.isEmpty(data)) {
                        BookInfo info = new BookInfo();
                        List<String> strs = new ArrayList<String>();
                        strs.add(data.getStringExtra("author"));
                        info.setAuthor(strs);
                        info.setTitle(data.getStringExtra("title"));
                        BookInfo.Imgs imgs = new BookInfo().new Imgs();
                        imgs.setLarge(data.getStringExtra("book_img"));
                        info.setImages(imgs);
                        info.setPages(data.getStringExtra("pages"));
                        Message msg = Message.obtain();
                        msg.obj = info;
                        mHandler.sendMessage(msg);
                    }
                    break;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void crop(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        // 裁剪框的比例，1：1
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // 裁剪后输出图片的尺寸大小
        intent.putExtra("outputX", 256);
        intent.putExtra("outputY", 256);
        intent.putExtra("outputFormat", "JPEG");
        // 取消人脸识别
        intent.putExtra("noFaceDetection", true);
        // true:不返回uri，false：返回uri
        intent.putExtra("return-data", true);
        startActivityForResult(intent, PHOTO_REQUEST_CUT);
    }

    private class DownloadThread extends Thread {
        String url = null;

        public DownloadThread(String urlstr) {
            url = urlstr;
        }

        public void run() {
            String result = LoadDoubanBookInfoTask.Download(url);
            BookInfo info = new LoadDoubanBookInfoTask().parseBookInfo(result);
            Message msg = Message.obtain();
            msg.obj = info;
            mHandler.sendMessage(msg);
        }
    }

    private void refreshView(BookInfo info) {
        BookInfo.Imgs imgs = info.getImages();
        Glide.with(getCurrentActivity())
                .load(imgs.getLarge())
                .placeholder(R.drawable.book_def)
                .error(R.drawable.book_def)
                .skipMemoryCache( true )//跳过内存缓存
                .diskCacheStrategy( DiskCacheStrategy.RESULT )
                .into(iv_book);

        titeForBook.setText(info.getTitle());
        athorForBook.setText(info.getAuthor().get(0));
        total_number_pages.setText(info.getPages());
    }
}