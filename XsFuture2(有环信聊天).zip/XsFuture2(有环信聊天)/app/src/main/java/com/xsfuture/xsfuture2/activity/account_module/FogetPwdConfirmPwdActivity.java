package com.xsfuture.xsfuture2.activity.account_module;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.presenter.LoginActivityPresenter;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.EncodeUtils;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.StringUtils;

import org.json.JSONException;

import static android.R.id.message;

public class FogetPwdConfirmPwdActivity extends BaseActivity {
    private LinearLayout mLayout_num;
    private ImageView mIcon_phone;
    private EditText mEdt_pwd_input;
    private ImageButton mPhone_clear;
    private EditText mEdt_pwd_reinput;
    private Button mBtn_reset_pwd;

    private String intentPhone;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_foget_pwd_confirm_pwd);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleLeftBtn(R.string.back, new OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initExtra();
        initView();
    }

    private void initExtra() {
        intentPhone = getIntent().getStringExtra("phone");
    }

    private void initView() {
        mLayout_num = (LinearLayout) findViewById(R.id.layout_num);
        mIcon_phone = (ImageView) findViewById(R.id.icon_phone);
        mEdt_pwd_input = (EditText) findViewById(R.id.edt_pwd_input);
        mPhone_clear = (ImageButton) findViewById(R.id.phone_clear);
        mEdt_pwd_reinput = (EditText) findViewById(R.id.edt_pwd_reinput);
        mBtn_reset_pwd = (Button) findViewById(R.id.btn_reset_pwd);
        mBtn_reset_pwd.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check()) {
                    reset_pwd();
                }
            }
        });
    }

    private boolean check() {
        String pwd = mEdt_pwd_input.getText().toString();
        String confirm_pwd = mEdt_pwd_reinput.getText().toString();
        if (StringUtils.isEmpty(pwd)) {
            showShortToast("请输入密码");
            return false;
        } else if (StringUtils.isEmpty(confirm_pwd)) {
            showShortToast("请确认密码");
            return false;
        } else if (!pwd.equals(confirm_pwd)) {
            showShortToast("两次密码不一样哦");
            return false;
        }
        return true;
    }

    private void reset_pwd() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("phone_number", intentPhone);
            String sha1Pwd = EncodeUtils.shaEncrypt(mEdt_pwd_input.getText().toString());//sha1密文
            obj.put("password", sha1Pwd);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        writePwd(intentPhone, mEdt_pwd_input.getText().toString());
                    } else {
                        showShortToast(message);
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        showShortToast(R.string.request_error);
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_user_edit_pwd);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    private void writePwd(String phone, String pwd) {
        LoginActivityPresenter presenter = new LoginActivityPresenter(getCurrentActivity());
        LoginActivityPresenter.LoginInfo info = presenter.new LoginInfo();
        info.setPhone_input(phone);
        info.setPwd_input(pwd);
        presenter.login(info);
    }


}