package com.xsfuture.xsfuture2.cache;

import com.xsfuture.xsfuture2.util.JSONObjectProxy;

import java.lang.ref.SoftReference;
import java.util.concurrent.ConcurrentHashMap;

public class JsonCache {

	private static ConcurrentHashMap<String, SoftReference<JSONObjectProxy>> jsonCache = new ConcurrentHashMap<String, SoftReference<JSONObjectProxy>>();

	public static void clearAllJson() {
		jsonCache.clear();
	}

	public static boolean containsKey(String key) {
		if (jsonCache.containsKey(key)) {
			return true;
		} else {
			return false;
		}
	}

	public static JSONObjectProxy getJson(String key) {
		if (jsonCache != null && jsonCache.containsKey(key)) {
			SoftReference<JSONObjectProxy> soft_bitmap = jsonCache.get(key);
			return soft_bitmap.get();
		} else {
			return null;
		}
	}

	public static void putJson(String key, JSONObjectProxy json) {
		if (jsonCache != null) {
			if (!jsonCache.containsKey(key)) {
				jsonCache.put(key, new SoftReference<JSONObjectProxy>(json));
			}
		} else {
			jsonCache = new ConcurrentHashMap<String, SoftReference<JSONObjectProxy>>();
			jsonCache.put(key, new SoftReference<JSONObjectProxy>(json));
		}
	}
}
