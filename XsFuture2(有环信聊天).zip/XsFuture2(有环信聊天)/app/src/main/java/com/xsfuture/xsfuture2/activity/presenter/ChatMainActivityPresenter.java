package com.xsfuture.xsfuture2.activity.presenter;

import android.text.TextUtils;

import com.hyphenate.chat.EMConversation;
import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.bean.ConversationItemInfo;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.database.ConversationListInfoDBHelper;
import com.xsfuture.xsfuture2.database.UserInfoDBHelper;

/**
 * Created by Kevin on 2017/6/9.
 */

public class ChatMainActivityPresenter {
    private ActivityHandlerInterface context;

    public ChatMainActivityPresenter(ActivityHandlerInterface context) {
        this.context = context;
    }

    /**
     * 初始化一条Conversation到DB
     *
     * @param emConversation
     * @param sellUserName   卖家name
     * @param sellUserPhone  卖家phone
     */
    public void initConversationToDB(EMConversation emConversation, String sellUserName, String sellUserPhone) {
        if (emConversation != null) {
            ConversationItemInfo itemInfo = ConversationListInfoDBHelper.getConversationByEmId(emConversation.conversationId(), context.getCurrentActivity());
            if (itemInfo == null) {//DB没有此条会话记录，则插入一条记录
                if (!TextUtils.isEmpty(sellUserName) && !TextUtils.isEmpty(sellUserPhone)) {
                    UserInfo myInfo = UserInfoDBHelper.getUser(context.getUser_id(), context.getCurrentActivity());
                    ConversationItemInfo cvInfo = new ConversationItemInfo();
                    cvInfo.setMy_user_id(myInfo.getUser_id());
                    cvInfo.setEm_id(emConversation.conversationId());
                    cvInfo.setEm_conversation_last_msg(emConversation.getLastMessage().getBody().toString());
                    cvInfo.setFrom_user_name(myInfo.getNick_name());
                    cvInfo.setFrom_user_phone(myInfo.getPhone_number());
                    cvInfo.setFrom_user_avatar_url(myInfo.getImage());
                    cvInfo.setTo_user_name(sellUserName);
                    cvInfo.setTo_user_phone(sellUserPhone);
                    cvInfo.setTo_user_avatar_url(myInfo.getImage());//TODO 需要卖家的avatar url
                    ConversationListInfoDBHelper.insertConversation(cvInfo, context.getCurrentActivity());
                }
            }else{
                if (!TextUtils.isEmpty(sellUserName) && !TextUtils.isEmpty(sellUserPhone)) {
                    UserInfo myInfo = UserInfoDBHelper.getUser(context.getUser_id(), context.getCurrentActivity());
                    ConversationItemInfo cvInfo = new ConversationItemInfo();
                    cvInfo.setMy_user_id(myInfo.getUser_id());
                    cvInfo.setEm_id(emConversation.conversationId());
                    cvInfo.setEm_conversation_last_msg(emConversation.getLastMessage().getBody().toString());
                    cvInfo.setFrom_user_name(myInfo.getNick_name());
                    cvInfo.setFrom_user_phone(myInfo.getPhone_number());
                    cvInfo.setFrom_user_avatar_url(myInfo.getImage());
                    cvInfo.setTo_user_name(sellUserName);
                    cvInfo.setTo_user_phone(sellUserPhone);
                    cvInfo.setTo_user_avatar_url(myInfo.getImage());//TODO 需要卖家的avatar url
                    ConversationListInfoDBHelper.updateConversationById(cvInfo, context.getCurrentActivity());
                }
            }
        }
    }

    public ConversationItemInfo getDBConversationByEMid(String emId) {
        ConversationItemInfo itemInfo = ConversationListInfoDBHelper.getConversationByEmId(emId, context.getCurrentActivity());
        if (itemInfo != null) {
            return itemInfo;
        }
        return null;
    }
}
