package com.xsfuture.xsfuture2.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.bean.BookInfo;
import com.xsfuture.xsfuture2.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class SearchBookListAdapter extends BaseAdapter {

    private List<BookInfo> data;
    private LayoutInflater inflater;
    private Activity context;

    public SearchBookListAdapter(Activity c) {
        context = c;
        inflater = LayoutInflater.from(context);
        data = new ArrayList<BookInfo>();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public BookInfo getItem(int position) {
        return data.get(position-1);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void setData(List<BookInfo> infos) {
        if (data == null) {
            data = new ArrayList<BookInfo>();
        } else {
            data.clear();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    public void addData(List<BookInfo> infos) {
        if (data == null) {
            data = new ArrayList<BookInfo>();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        final BookInfo item = data.get(position);
        holder = new ViewHolder();
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.activity_search_books, null);
            holder.book_name = (TextView) convertView.findViewById(R.id.tv_book_name);
            holder.tv_author = (TextView) convertView.findViewById(R.id.tv_author);
            holder.img_book = (ImageView) convertView.findViewById(R.id.img_book);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.book_name.setText(item.getTitle());
        holder.tv_author.setVisibility(View.VISIBLE);
        if (item.getAuthor() != null && item.getAuthor().size() > 0 && !StringUtils.isEmpty(item.getAuthor().get(0))){
            holder.tv_author.setText(item.getAuthor().get(0));
        }else{
            holder.tv_author.setText("");
        }
        Glide.with(context)
                .load(item.getImages().getMedium())
                .placeholder(R.drawable.book_def)
                .error(R.drawable.book_def)
                .skipMemoryCache(false )//跳过内存缓存
                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                .into(holder.img_book);
        return convertView;
    }

    public class ViewHolder {
        public TextView book_name;
        public TextView tv_author;
        public ImageView img_book;
    }
}
