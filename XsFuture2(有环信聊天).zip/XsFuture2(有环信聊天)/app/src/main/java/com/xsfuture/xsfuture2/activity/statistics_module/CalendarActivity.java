package com.xsfuture.xsfuture2.activity.statistics_module;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.database.UserInfoDBHelper;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.util.CollectionData;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.Log;
import com.xsfuture.xsfuture2.view.CircularImage;
import com.xsfuture.xsfuture2.view.calendar.CalendarView;

import org.json.JSONException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CalendarActivity extends BaseActivity implements View.OnClickListener {
    //    private TextView mTextSelectMonth;
    private TextView tv_select_year;
    private TextView tv_select_month;
    private TextView tv_select_day;
    private ImageView mLastMonthView;
    private ImageView mNextMonthView;
    private CalendarView mCalendarView;
    private CircularImage user_avatar;
    private TextView tex_name;
    private TextView tv_day_num;
    private TextView tv_book_num;
    private TextView tv_reader_response_num;

    private List<String> mDatas = new ArrayList<String>();
    private CollectionData<String> collectionData = new CollectionData<String>();

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_calendar);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleText("读书日历");
        setTitleLeftBtn(R.string.back, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        tv_day_num = (TextView) findViewById(R.id.tv_day_num);
        tv_book_num = (TextView) findViewById(R.id.tv_book_num);
        tv_reader_response_num = (TextView) findViewById(R.id.tv_reader_response_num);
        user_avatar = (CircularImage) findViewById(R.id.user_avatar);
        tex_name = (TextView) findViewById(R.id.tex_name);

        tv_select_year = (TextView) findViewById(R.id.tv_select_year);
        tv_select_month = (TextView) findViewById(R.id.tv_select_month);
        tv_select_day = (TextView) findViewById(R.id.tv_select_day);

        mLastMonthView = (ImageView) findViewById(R.id.img_select_last_month);
        mNextMonthView = (ImageView) findViewById(R.id.img_select_next_month);
        mCalendarView = (CalendarView) findViewById(R.id.calendarView);
        mLastMonthView.setOnClickListener(this);
        mNextMonthView.setOnClickListener(this);
        // 设置不可以被点击
        mCalendarView.setClickable(false);
        // 设置点击事件
        mCalendarView.setOnClickDate(new CalendarView.OnClickListener() {
            @Override
            public void onClickDateListener(int year, int month, int day) {
                Toast.makeText(getApplication(), year + "年" + month + "月" + day + "天", Toast.LENGTH_SHORT).show();

                // 获取已选择日期
                List<String> dates = mCalendarView.getSelectedDates();
                for (String date : dates) {
                    Log.e("test", "date: " + date);
                }
            }
        });
        tv_select_year.setText(mCalendarView.getDateYear());
        tv_select_month.setText(mCalendarView.getDateMohth());
        tv_select_day.setText(" ");
        getMonthData();
        getSummaryTotal();
        initViewData();
    }

    private void initViewData() {
        UserInfo info = UserInfoDBHelper.getUser(getCurrentActivity().getUser_id(), getCurrentActivity());
        tex_name.setText(info.getNick_name());
        setAvatar(info.getImage());
    }

    private void setAvatar(String str) {
        Glide.with(getCurrentActivity())
                .load(str)
                .placeholder(R.drawable.avatar)
                .error(R.drawable.avatar)
                .skipMemoryCache(false)//跳过内存缓存
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(user_avatar);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.img_select_last_month:
                mCalendarView.setLastMonth();
                tv_select_year.setText(mCalendarView.getDateYear());
                tv_select_month.setText(mCalendarView.getDateMohth());
                tv_select_day.setText(" ");
                getMonthData();
                break;
            case R.id.img_select_next_month:
                mCalendarView.setNextMonth();
                tv_select_year.setText(mCalendarView.getDateYear());
                tv_select_month.setText(mCalendarView.getDateMohth());
                tv_select_day.setText(" ");
                getMonthData();
                break;
        }
    }

    private void getMonthData() {
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONArrayPoxy datas = jSONObjectProxy.getJSONArrayOrNull("data");
                    if (success == 0) {
                        if (datas.length() > 0) {
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
                            mDatas.clear();
                            for (int i = 0; i < datas.length(); i++) {
                                try {
                                    long data = Long.parseLong(datas.get(i).toString());
                                    mDatas.add(sdf.format(new Date(data * 1000)));
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                            collectionData.dataDuplicateRemovalAndReture(mDatas);
                            // 设置可选日期
                            mCalendarView.setOptionalDate(mDatas);
                            // 设置已选日期
                            mCalendarView.setSelectedDates(mDatas);

                            tv_select_year.setText(mCalendarView.getDateYear());
                            tv_select_month.setText(mCalendarView.getDateMohth());
                            tv_select_day.setText(String.valueOf(mCalendarView.getSelectedDates().size()));
                        } else {
                            tv_select_year.setText(mCalendarView.getDateYear());
                            tv_select_month.setText(mCalendarView.getDateMohth());
                            tv_select_day.setText("0");
                        }
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_summary_month + "?time_stamp=" + getCurentTimeStamp());
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_GET);
        httpTask.executes(httpSetting);
    }

    private int getCurentTimeStamp() {
        String dateStr = mCalendarView.getDate() + "-01";
        Date date = null;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            date = simpleDateFormat.parse(dateStr);
        } catch (Exception exception) {
        }
        return (int) (date.getTime() / 1000);
    }

    private void getSummaryTotal() {
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONObjectProxy data = jSONObjectProxy.getJSONObjectOrNull("data");
                    if (success == 0 && data != null) {
                        int day_num = data.getIntOrNull("day_number");
                        int book_num = data.getIntOrNull("book_number");
                        int reader_response_num = data.getIntOrNull("reader_response_number");
                        tv_day_num.setText(day_num + "天");
                        tv_book_num.setText(book_num + "本");
                        tv_reader_response_num.setText(reader_response_num + "条");
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_summary_total);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_GET);
        httpTask.executes(httpSetting);
    }

    protected boolean setGesturesTracker() {
        return false;
    }

}