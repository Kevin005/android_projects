package com.xsfuture.xsfuture2.bean;

public class ReadingBookInfo {
    private String title;
    private String content;
    private int is_private;
    private String author;
    private int page_total;
    private int schedule_days;// 计划总天数
    private int favor;// 关注数
    private int book_id;
    private String book_image;
    private String readed_book_id;
    private int user_id;
    private int post_id;
    private String progress;// 进度0.50
    private int info_type;//*特殊标识*标识数据源item类型

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getIs_private() {
        return is_private;
    }

    public void setIs_private(int is_private) {
        this.is_private = is_private;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPage_total() {
        return page_total;
    }

    public void setPage_total(int page_total) {
        this.page_total = page_total;
    }

    public int getSchedule_days() {
        return schedule_days;
    }

    public void setSchedule_days(int schedule_days) {
        this.schedule_days = schedule_days;
    }

    public int getFavor() {
        return favor;
    }

    public void setFavor(int favor) {
        this.favor = favor;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public String getBook_image() {
        return book_image;
    }

    public void setBook_image(String book_image) {
        this.book_image = book_image;
    }

    public String getReaded_book_id() {
        return readed_book_id;
    }

    public void setReaded_book_id(String readed_book_id) {
        this.readed_book_id = readed_book_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getPost_id() {
        return post_id;
    }

    public void setPost_id(int post_id) {
        this.post_id = post_id;
    }

    public String getProgress() {
        return progress;
    }

    public void setProgress(String progress) {
        this.progress = progress;
    }

    public int getInfo_type() {
        return info_type;
    }

    public void setInfo_type(int info_type) {
        this.info_type = info_type;
    }


}
