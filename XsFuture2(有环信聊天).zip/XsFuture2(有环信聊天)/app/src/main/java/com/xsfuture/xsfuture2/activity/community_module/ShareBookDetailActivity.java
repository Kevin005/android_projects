package com.xsfuture.xsfuture2.activity.community_module;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.database.UserInfoDBHelper;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.activity.chat_module.ChatMainActivity;
import com.xsfuture.xsfuture2.util.LocationUtils;
import com.xsfuture.xsfuture2.util.Log;

/**
 * Created by Kevin on 2017/5/31.
 */

public class ShareBookDetailActivity extends BaseActivity {
    private String TAG = ShareBookDetailActivity.class.getName();
    private TextView tvSellUserName;
    private Button btnToChat;

    private String sell_user_name;
    private String sell_user_phone_num;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_share_book_detail);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        initExtra();
        initView();
    }

    private void initExtra() {
        sell_user_name = getIntent().getStringExtra("sell_user_name");
        sell_user_phone_num = getIntent().getStringExtra("sell_user_phone_num");
    }

    private void initView() {
        tvSellUserName = (TextView) findViewById(R.id.tv_sell_user_name);
        tvSellUserName.setText(sell_user_name);
        UserInfo info = UserInfoDBHelper.getUser(getCurrentActivity().getUser_id(), getCurrentActivity());
        btnToChat = (Button) findViewById(R.id.btn_to_chat);
        if (info != null && info.getPhone_number().equals(sell_user_phone_num)) {
            btnToChat.setVisibility(View.GONE);
        }
        btnToChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), ChatMainActivity.class);
                intent.putExtra("sell_user_phone_num", sell_user_phone_num);
                intent.putExtra("sell_user_name", sell_user_name);
                startActivity(intent);
                finish();
            }
        });

        LocationUtils locationUtils = new LocationUtils();
        locationUtils.getLocation(getCurrentActivity(), new LocationUtils.LocationCallback() {
            @Override
            public void callBack(LocationUtils.LocationInfo info) {
                Log.e(TAG, String.valueOf(info.getLatitude()));
                Log.e(TAG, String.valueOf(info.getLongitude()));
            }
        });
    }

}
