package com.xsfuture.xsfuture2.fragment.server;

/**
 * Created by liuwei on 2016/7/26.
 */
public interface DynamicRefreshListener {
    void onRefresh();
}
