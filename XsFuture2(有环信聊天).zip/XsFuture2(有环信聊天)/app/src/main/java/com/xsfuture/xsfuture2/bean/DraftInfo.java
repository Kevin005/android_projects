package com.xsfuture.xsfuture2.bean;

public class DraftInfo {
    private int PostId;
    private int ReadedPageNumber;
    private String Content;

    public int getPostId() {
        return PostId;
    }

    public void setPostId(int postId) {
        PostId = postId;
    }

    public int getReadedPageNumber() {
        return ReadedPageNumber;
    }

    public void setReadedPageNumber(int readedPageNumber) {
        ReadedPageNumber = readedPageNumber;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }

}
