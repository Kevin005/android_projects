package com.xsfuture.xsfuture2.http;

import android.content.Context;

import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.util.Log;
import com.xsfuture.xsfuture2.util.StringUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.FileNameMap;
import java.net.URLConnection;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class OkHttpTask {

    private static OkHttpClient client = null;
    private static OkHttpTask task;
    private static String token;

    public interface OkCallback {
        void onEnd(String responseStr);

        void onError();
    }

    private OkHttpTask() {
    }

    public static OkHttpTask getInstance() {
        if (task == null) {
            synchronized (OkHttpTask.class) {
                task = new OkHttpTask();
            }
        }
        return task;
    }

    private OkHttpClient getClientInstance() {
        if (client == null) {
            synchronized (OkHttpTask.class) {
                if (client == null)
                    client = new OkHttpClient();
                okhttp3.OkHttpClient.Builder ClientBuilder = new okhttp3.OkHttpClient.Builder();
                ClientBuilder.readTimeout(30, TimeUnit.SECONDS);//读取超时
                ClientBuilder.connectTimeout(10, TimeUnit.SECONDS);//连接超时
                ClientBuilder.writeTimeout(60, TimeUnit.SECONDS);//写入超时
                client = ClientBuilder.build();
            }
        }
        return client;
    }

    /**
     * Get请求
     *
     * @param url
     * @param callback
     */
    public void actionGet(Context context, String url, final OkCallback callback) {
        Request request = new Request.Builder()
                .url(url)
                .addHeader("Content-Type", "application/json;charset=utf-8")
                .addHeader("X-AccessToken", getToken(context))
                .build();
        Call call = getClientInstance().newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                callback.onError();
            }

            @Override
            public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {
                // 注：该回调是子线程，非主线程
                Log.i("", "callback thread id is " + Thread.currentThread().getId());
                callback.onEnd(response.body().string());
            }
        });
    }

    /**
     * Post请求发送JSON数据
     *
     * @param url
     * @param jsonParams
     * @param callback
     */
    public void actionPost(Context context, String url, String jsonParams, final OkCallback callback) {
        RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8")
                , jsonParams);
        Request request = new Request.Builder()
                .url(getFullUrl(url))
                .addHeader("Content-Type", "application/json;charset=utf-8")
                .addHeader("X-AccessToken", getToken(context))
                .post(body)
                .build();
        Call call = getClientInstance().newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                callback.onError();
            }

            @Override
            public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {
                // 注：该回调是子线程，非主线程
                //Log.i("", "callback thread id is " + Thread.currentThread().getId());
                callback.onEnd(response.body().string());
            }
        });
    }

    /**
     * Post请求发送键值对数据
     *
     * @param url
     * @param mapParams
     * @param callback
     */
    public void doPost(String url, Map<String, String> mapParams, Callback callback) {
        FormBody.Builder builder = new FormBody.Builder();
        for (String key : mapParams.keySet()) {
            builder.add(key, mapParams.get(key));
        }
        Request request = new Request.Builder()
                .url(url)
                .post(builder.build())
                .build();
        Call call = getClientInstance().newCall(request);
        call.enqueue(callback);
    }

    /**
     * 上传文件
     *
     * @param url
     * @param pathName
     * @param fileName
     * @param callback
     */
    public void doFile(String url, String pathName, String fileName, Callback callback) {
        //判断文件类型
        MediaType MEDIA_TYPE = MediaType.parse(judgeType(pathName));
        //创建文件参数
        MultipartBody.Builder builder = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(MEDIA_TYPE.type(), fileName,
                        RequestBody.create(MEDIA_TYPE, new File(pathName)));
        //发出请求参数
        Request request = new Request.Builder()
                .header("Authorization", "Client-ID " + "9199fdef135c122")
                .url(url)
                .post(builder.build())
                .build();
        Call call = getClientInstance().newCall(request);
        call.enqueue(callback);

    }

    /**
     * 根据文件路径判断MediaType
     *
     * @param path
     * @return
     */
    private String judgeType(String path) {
        FileNameMap fileNameMap = URLConnection.getFileNameMap();
        String contentTypeFor = fileNameMap.getContentTypeFor(path);
        if (contentTypeFor == null) {
            contentTypeFor = "application/octet-stream";
        }
        return contentTypeFor;
    }

    /**
     * 下载文件
     *
     * @param url
     * @param fileDir
     * @param fileName
     */
    public void downFile(String url, final String fileDir, final String fileName) {
        Request request = new Request.Builder()
                .url(url)
                .build();
        Call call = getClientInstance().newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                InputStream is = null;
                byte[] buf = new byte[2048];
                int len = 0;
                FileOutputStream fos = null;
                try {
                    is = response.body().byteStream();
                    File file = new File(fileDir, fileName);
                    fos = new FileOutputStream(file);
                    while ((len = is.read(buf)) != -1) {
                        fos.write(buf, 0, len);
                    }
                    fos.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (is != null) is.close();
                    if (fos != null) fos.close();
                }
            }
        });
    }

    private String getToken(Context context) {
        if (StringUtils.isEmpty(token)) {
            return context.getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0).getString("token", "");
        }
        return token;
    }

    private static String getFullUrl(String url) {
        if (url.startsWith(ConstHttpProp.base_url)) {
            return url;
        }
        return ConstHttpProp.base_url + url;
    }

    /**
     * 同步Get方法
     */
    @Deprecated
    private void okHttp_synchronousGet() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = "https://api.github.com/";
                    OkHttpClient client = new OkHttpClient();
                    Request request = new Request.Builder().url(url).build();
                    okhttp3.Response response = client.newCall(request).execute();
                    if (response.isSuccessful()) {
                        Log.i("TAG", response.body().string());
                    } else {
                        Log.i("TAG", "okHttp is request error");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
