package com.xsfuture.xsfuture2.util;

public class FileGuider {

	/* 文件大小 */
	private long AvailableSize;
	private String childDirName;
	private String fileName;// 文件名
	private boolean immutable;
	private int internalType;
	private Directory dir;
	/*
	 * 存储模式：
	 * Context.MODE_APPEND 私有，在原有内容基础上增加数据                                          
	 * Context.MODE_PRIVATE 私有，每次打开文件都会覆盖原来的内容                    
	 * Context.MODE_WORLD_READABLE 可以被其他应用程序读取                  
	 * Context.MODE_WORLD_WRITEABLE 可以被其他应用程序写入                            
	 */
	private int mode;
	private StorageType space;

	public enum StorageType {
		STORAGE_UNKNOWN(0), //未知存储
		STORAGE_INTERNAL(1), //内部存储
		STORAGE_EXTERNAL(2); //外部存储

		private final int value;

		private StorageType(int value) {
			this.value = value;
		}
		
		public int getValue() {
		    return value;
		  }
	}

	public long getAvailableSize() {
		return AvailableSize;
	}

	public void setAvailableSize(long availableSize) {
		AvailableSize = availableSize;
	}

	public String getChildDirName() {
		return childDirName;
	}

	public void setChildDirName(String childDirName) {
		this.childDirName = childDirName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public boolean isImmutable() {
		return immutable;
	}

	public void setImmutable(boolean immutable) {
		this.immutable = immutable;
	}

	public int getInternalType() {
		return internalType;
	}

	public void setInternalType(int internalType) {
		this.internalType = internalType;
	}

	public int getMode() {
		return mode;
	}

	public void setMode(int mode) {
		this.mode = mode;
	}

	public StorageType getSpace() {
		return space;
	}

	public void setSpace(StorageType space) {
		this.space = space;
	}

	public Directory getDir() {
		return dir;
	}

	public void setDir(Directory dir) {
		this.dir = dir;
	}
}
