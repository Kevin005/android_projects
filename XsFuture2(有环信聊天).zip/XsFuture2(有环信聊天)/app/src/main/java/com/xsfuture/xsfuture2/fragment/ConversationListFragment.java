package com.xsfuture.xsfuture2.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.hyphenate.chat.EMClient;
import com.hyphenate.chat.EMConversation;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.ConversationListAdapter;
import com.xsfuture.xsfuture2.bean.ConversationItemInfo;
import com.xsfuture.xsfuture2.database.ConversationListInfoDBHelper;
import com.xsfuture.xsfuture2.base.FrameMainActivity;
import com.xsfuture.xsfuture2.activity.chat_module.ChatMainActivity;
import com.xsfuture.xsfuture2.view.xlistview.XListView;

import java.util.List;
import java.util.Map;

public class ConversationListFragment extends BaseFragment implements XListView.IXListViewListener {
    private XListView xlvConversationList;
    private ConversationListAdapter adapter;

    @Override
    protected View setCurrentContentView(LayoutInflater inflater, ViewGroup container) {
        View view = inflater.inflate(R.layout.fragment_conversation_list, container, false);
        setCurrentActivity((FrameMainActivity) getActivity());
        return view;
    }

    @Override
    protected void init(View view, Bundle savedInstanceState) {
        initView(view);
        initData();
    }

    private void initView(View view) {
        xlvConversationList = (XListView) view.findViewById(R.id.xlv_conversation_list);
        xlvConversationList.setOnItemClickListener(new XListView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getCurrentActivity(), ChatMainActivity.class);
                intent.putExtra("sell_user_phone_num", adapter.getItem(position).getTo_user_phone());
                intent.putExtra("sell_user_name", adapter.getItem(position).getTo_user_name());
                startActivity(intent);
            }
        });
        xlvConversationList.setPullLoadEnable(false);
        xlvConversationList.setPullRefreshEnable(false);
        xlvConversationList.setXListViewListener(this);
        adapter = new ConversationListAdapter(getCurrentActivity());
        xlvConversationList.setAdapter(adapter);

    }

    private void initData() {
        List<ConversationItemInfo> infos = ConversationListInfoDBHelper.getAllConversationByMyId(getCurrentActivity().getUser_id(), getActivity());
        Map<String, EMConversation> conversations = EMClient.getInstance().chatManager().getAllConversations();//获取所有会话
//        EMConversation conversation = EMClient.getInstance().chatManager().getConversation(username);//获取聊天记录
        adapter.addData(infos);
    }

    @Override
    public void onRefresh() {
    }

    @Override
    public void onLoadMore() {
    }

    @Override
    public void onXListViewStop() {
        xlvConversationList.stopRefresh();
        xlvConversationList.stopLoadMore();
    }
}
