package com.xsfuture.xsfuture2.bean;

import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.util.StringUtils;

public class TodayMainInfo {
    // 首页头
    private int books;
    private int read_days;
    //首页读书计划
    private boolean is_signed;//0：未打卡，1：打卡
    private int read_time;
    //    private int post_id;
    private double progress;// 进度0.50
    private String name;//书名
    private String page_total;
    private int info_type;// *特殊标识*标识首页数据源类型
    private boolean plan_is_null;// *特殊标识*标识首页数据源是否为空
    private String image;
    // 首页列表
    private int readed_days;
    private String content;
    private String user_name;
    private String nick_name;
    private boolean is_on;//0：未关注 1：已关注
    private int favor;
    private int readed_page_number;
    private String book_name;
    private int time_stamp;// 发布计划时间戳
    private int reader_response_id;
    private int post_id;
    private String push_time;// 发布计划时间
    private int user_id;
    private int gender;
    private String user_image;
    private String book_image;
    private int rr_favor_total;
    private int favor_total;
    private int rr_comment_total;
    private boolean is_favored;
    private String author;

    public int getFavor_total() {
        return favor_total;
    }

    public void setFavor_total(int favor_total) {
        this.favor_total = favor_total;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public boolean is_favored() {
        return is_favored;
    }

    public void setIs_favored(boolean is_favored) {
        this.is_favored = is_favored;
    }

    public int getRr_favor_total() {
        return rr_favor_total;
    }

    public void setRr_favor_total(int rr_favor_total) {
        this.rr_favor_total = rr_favor_total;
    }

    public int getRr_comment_total() {
        return rr_comment_total;
    }

    public void setRr_comment_total(int rr_comment_total) {
        this.rr_comment_total = rr_comment_total;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public boolean is_signed() {
        return is_signed;
    }

    public void setIs_signed(boolean is_signed) {
        this.is_signed = is_signed;
    }

    public boolean is_on() {
        return is_on;
    }

    public void setIs_on(boolean is_on) {
        this.is_on = is_on;
    }

    public int getBooks() {
        return books;
    }

    public void setBooks(int books) {
        this.books = books;
    }

    public double getProgress() {
        return progress;
    }

    public void setProgress(double progress) {
        this.progress = progress;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRead_days() {
        return read_days;
    }

    public void setRead_days(int read_days) {
        this.read_days = read_days;
    }

    public int getRead_time() {
        return read_time;
    }

    public void setRead_time(int read_time) {
        this.read_time = read_time;
    }

    public String getPage_total() {
        return page_total;
    }

    public void setPage_total(String page_total) {
        this.page_total = page_total;
    }

    public int getFavor() {
        return favor;
    }

    public void setFavor(int favor) {
        this.favor = favor;
    }

    public int getTime_stamp() {
        return time_stamp;
    }

    public void setTime_stamp(int time_stamp) {
        this.time_stamp = time_stamp;
    }

    public int getInfo_type() {
        return info_type;
    }

    public void setInfo_type(int info_type) {
        this.info_type = info_type;
    }

    public boolean isPlan_is_null() {
        return plan_is_null;
    }

    public void setPlan_is_null(boolean plan_is_null) {
        this.plan_is_null = plan_is_null;
    }

    public int getReaded_days() {
        return readed_days;
    }

    public void setReaded_days(int readed_days) {
        this.readed_days = readed_days;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getNick_name() {
        return nick_name;
    }

    public void setNick_name(String nick_name) {
        this.nick_name = nick_name;
    }


    public int getReaded_page_number() {
        return readed_page_number;
    }

    public void setReaded_page_number(int readed_page_number) {
        this.readed_page_number = readed_page_number;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }


    public int getReader_response_id() {
        return reader_response_id;
    }

    public void setReader_response_id(int reader_response_id) {
        this.reader_response_id = reader_response_id;
    }

    public int getPost_id() {
        return post_id;
    }

    public void setPost_id(int post_id) {
        this.post_id = post_id;
    }

    public String getPush_time() {
        return push_time;
    }

    public void setPush_time(String push_time) {
        this.push_time = push_time;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getUser_image() {
        if (!StringUtils.isEmpty(user_image) && user_image.contains("http://115.28.56.168")) {
            return user_image;
        }
        return ConstHttpProp.img_base_url + user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getBook_image() {
        return book_image;
    }

    public void setBook_image(String book_image) {
        this.book_image = book_image;
    }


}
