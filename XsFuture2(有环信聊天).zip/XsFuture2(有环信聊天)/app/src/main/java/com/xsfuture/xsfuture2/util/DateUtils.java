package com.xsfuture.xsfuture2.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {

    private static final SimpleDateFormat format2YMDHM = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    private static final SimpleDateFormat format2HM = new SimpleDateFormat("HH:mm");
    private static final SimpleDateFormat format2CNMD = new SimpleDateFormat("yyyy年M月d日");
    private static final SimpleDateFormat format2YYYY_MM_DD = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * HH:mm
     *
     * @return
     */
    public static String getMonthDayHourMinute() {
        return format2HM.format(new Date());
    }

    /**
     * yyyy-MM-dd
     *
     * @return
     */
    public static String getYearMonthDay() {
        return format2YYYY_MM_DD.format(new Date());
    }

    public static String TimeStamp2Date(String timestampString) {
        String formats = "MM月dd日 HH:mm";//yyyy年MM月dd日 HH:mm
        Long timestamp;
        if (timestampString.length() == 10) {
            timestamp = Long.parseLong(timestampString) * 1000;
        } else if (timestampString.length() == 12) {
            timestamp = Long.parseLong(timestampString);
        } else {
            timestamp = System.currentTimeMillis();
        }
        String date = new SimpleDateFormat(formats).format(new Date(timestamp));
        return date;
    }

    public static String TimeStamp2MD(String timestampString) {
        String formats = "MM月dd日";
        Long timestamp;
        if (timestampString.length() == 10) {
            timestamp = Long.parseLong(timestampString) * 1000;
        } else if (timestampString.length() == 12) {
            timestamp = Long.parseLong(timestampString);
        } else {
            timestamp = System.currentTimeMillis();
        }
        String date = new SimpleDateFormat(formats).format(new Date(timestamp));
        return date;
    }

    /**
     * y年M月d日 HH:mm
     *
     * @param stamp
     * @return
     */
    public static String stamp2CnYMDHM(long stamp) {
        return format2YMDHM.format(stamp);
    }

    private static long[][] parseDateMonthsAndDays(String value) {
        long[][] values = new long[2][];
        try {
            final String[] items = value.split("\\|");
            final String[] monthStrs = items[0].split(",");
            final String[] dayStrs = items[1].split(",");
            values[0] = new long[monthStrs.length];
            values[1] = new long[dayStrs.length];

            int i = 0;
            for (String s : monthStrs) {
                values[0][i++] = Long.valueOf(s);
            }
            i = 0;
            for (String s : dayStrs) {
                values[1][i++] = Long.valueOf(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return values;
    }

    /**
     * 时间戳转日期
     */
    public static String stamp2Time(String str) {
        String sd = format2YMDHM.format(new Date(Long.parseLong(str)));
        return sd;
    }

    /**
     * 取得时间戳
     *
     * @return
     */
    public static long genTimeStamp() {
        return System.currentTimeMillis() / 1000;
    }

    // 获得当天0点时间
	public static int getTimesmorning() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return (int) (cal.getTimeInMillis() / 1000);
	}

    // 获得当天24点时间
    public static int getTimesnight() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 24);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return (int) (cal.getTimeInMillis() / 1000);
    }

    /**
     * 把一个生日转换成年龄
     *
     * @param birthday yyyy-MM-dd
     * @return age
     */
    public static long tansToAge(String birthday) {
        try {
            Date birth = format2YYYY_MM_DD.parse(birthday);
            Date today = new Date();
            long secondOfYear = 60 * 60 * 24 * 365;
            return (today.getTime() - birth.getTime()) / 1000 / secondOfYear + 1;
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 获得指定日期的前一天
     *
     * @param specifiedDay
     * @return
     * @throws Exception
     */
    public static Date getSpecifiedDayBefore(String specifiedDay) {// 可以用new
        // Date().toLocalString()传递参数
        Calendar c = Calendar.getInstance();
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyy-MM-dd").parse(specifiedDay);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.setTime(date);
        int day = c.get(Calendar.DATE);
        c.set(Calendar.DATE, day - 1);
        return c.getTime();
    }

    /**
     * 获得指定日期的后一天
     *
     * @param specifiedDay
     * @return
     * @throws Exception
     */
    public static Date getSpecifiedDayAfter(String specifiedDay) {// 可以用new
        // Date().toLocalString()传递参数
        Calendar c = Calendar.getInstance();
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyy-MM-dd").parse(specifiedDay);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.setTime(date);
        int day = c.get(Calendar.DATE);
        c.set(Calendar.DATE, day + 1);
        return c.getTime();
    }

}
