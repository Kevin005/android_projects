package com.xsfuture.xsfuture2.activity.tool;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.Target;
import com.xsfuture.xsfuture2.R;

import uk.co.senab.photoview.PhotoViewAttacher;


public class PhotoViewActivity extends Activity {
    private ImageView img_photo_view;
    private String big_photo_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        int flag = WindowManager.LayoutParams.FLAG_FULLSCREEN;
        Window myWindow = this.getWindow();
        myWindow.setFlags(flag, flag);
        setContentView(R.layout.activity_photo_view);
        initExtra();
        initView();
        displayImage();

    }

    private void initExtra() {
        big_photo_view = getIntent().getStringExtra("big_photo_view");
    }

    private void initView() {
        img_photo_view = (ImageView) findViewById(R.id.img_photo_view);
    }

    private void displayImage() {
        Glide.with(PhotoViewActivity.this)
                .load(big_photo_view)
                .asBitmap()
                .skipMemoryCache(false)//跳过内存缓存
                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                .into(new SimpleTarget<Bitmap>(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL) {
                    @Override
                    public void onResourceReady(final Bitmap bitmap, GlideAnimation glideAnimation) {
                        // Do something with bitmap here.
                        img_photo_view.setImageBitmap(bitmap);
                        //创建一个photoview的一个attacher，实现了图片的放大缩小
                        PhotoViewAttacher attacher = new PhotoViewAttacher(img_photo_view);
                        attacher.setOnViewTapListener(new PhotoViewAttacher.OnViewTapListener() {
                            @Override
                            public void onViewTap(View view, float x, float y) {
                                finish();
                            }
                        });
                    }
                });
    }

}
