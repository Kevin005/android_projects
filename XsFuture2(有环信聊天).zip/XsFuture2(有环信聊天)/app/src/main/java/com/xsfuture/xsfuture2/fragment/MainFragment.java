package com.xsfuture.xsfuture2.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.MainFragmentPagerAdapter;
import com.xsfuture.xsfuture2.base.FrameMainActivity;
import com.xsfuture.xsfuture2.activity.account_module.LoginActivity;
import com.xsfuture.xsfuture2.activity.main_module.ReleasePlanActivity;
import com.xsfuture.xsfuture2.activity.statistics_module.CalendarActivity;
import com.xsfuture.xsfuture2.util.DPIUtils;
import com.xsfuture.xsfuture2.util.StringUtils;

import java.util.ArrayList;


public class MainFragment extends BaseFragment {
    private ViewPager mPager;
    private ArrayList<Fragment> fragmentsList;
    private TextView tv_today;
    private TextView tv_dynamic;
    private TextView tv_follow_another;
    private Fragment todayFragment;
    private Fragment dynamicFragment;
    private Fragment followFragment;
    private LinearLayout release_plan;
    private LinearLayout line_caledar;
    private ImageView ivBottomLine;

    private int currentFragmentTag = 0;
    private int bmpW;// 动画图片宽度
    private int currIndex = 0;
    private int offset = 0;

    @Override
    protected View setCurrentContentView(LayoutInflater inflater, ViewGroup container) {
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.fragment_main, container, false);
        setCurrentActivity((FrameMainActivity) getActivity());
        return view;
    }

    @Override
    protected void init(View view, Bundle savedInstanceState) {
        initView(view);
        initViewPager(view);

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    private void initView(View parentView) {
        release_plan = (LinearLayout) parentView.findViewById(R.id.release_plan);
        line_caledar = (LinearLayout) parentView.findViewById(R.id.line_caledar);
        tv_today = (TextView) parentView.findViewById(R.id.tv_today);
        tv_dynamic = (TextView) parentView.findViewById(R.id.tv_dynamic);
        tv_follow_another = (TextView) parentView.findViewById(R.id.tv_follow_another);
        tv_today.setOnClickListener(new MyOnClickListener(0));
        tv_dynamic.setOnClickListener(new MyOnClickListener(1));
        tv_follow_another.setOnClickListener(new MyOnClickListener(2));
        release_plan.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (StringUtils.isEmpty(getCurrentActivity().getUser_token())) {
                    Intent intent = new Intent(getCurrentActivity(), LoginActivity.class);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(getCurrentActivity(), ReleasePlanActivity.class);
                    startActivity(intent);
                }
            }
        });
        line_caledar.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (StringUtils.isEmpty(getCurrentActivity().getUser_token())) {
                    Intent intent = new Intent(getCurrentActivity(), LoginActivity.class);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(getCurrentActivity(), CalendarActivity.class);
                    startActivity(intent);
                }
            }
        });
        InitWidth(parentView);
    }

    private void InitWidth(View view) {
        ivBottomLine = (ImageView) view.findViewById(R.id.img_personal_details_bottom_line);
        bmpW = ivBottomLine.getLayoutParams().width;// 获取图片宽度
        DisplayMetrics dm = new DisplayMetrics();
        getCurrentActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
        int px = DPIUtils.dip2px(getCurrentActivity(), 140);
        int screenW = dm.widthPixels - px;// 获取分辨率宽度
        offset = (screenW / 3 - bmpW) / 2;// 计算偏移量
        TranslateAnimation animation = new TranslateAnimation(offset, offset, 0, 0);
        animation.setFillAfter(true);
        animation.setDuration(0);
        ivBottomLine.startAnimation(animation);
    }

    private void initViewPager(View parentView) {
        mPager = (ViewPager) parentView.findViewById(R.id.vPager);
        fragmentsList = new ArrayList<Fragment>();

        todayFragment = new TodayFragment();
        dynamicFragment = new DynamicFragment();
        followFragment = new FollowFragment();

        fragmentsList.add(todayFragment);
        fragmentsList.add(dynamicFragment);
        fragmentsList.add(followFragment);

        mPager.setAdapter(new MainFragmentPagerAdapter(getFragmentManager(), fragmentsList));
        mPager.setOnPageChangeListener(new MyOnPageChangeListener());
        currentFragmentTag = 0;
        mPager.setCurrentItem(currentFragmentTag);
    }

    public class MyOnClickListener implements OnClickListener {
        private int index = 0;

        public MyOnClickListener(int i) {
            index = i;
        }

        @Override
        public void onClick(View v) {
            currentFragmentTag = index;
            mPager.setCurrentItem(currentFragmentTag);
        }
    }

    public class MyOnPageChangeListener implements OnPageChangeListener {
        int one = (int) (offset * 1.3 + bmpW);// 页卡1 -> 页卡2 偏移量

        @Override
        public void onPageSelected(final int arg0) {
            switch (arg0) {
                case 0:
                    currentFragmentTag = 0;
                    mPager.setCurrentItem(currentFragmentTag);
                    break;
                case 1:
                    currentFragmentTag = 1;
                    mPager.setCurrentItem(currentFragmentTag);
                    break;
                case 2:
                    currentFragmentTag = 2;
                    mPager.setCurrentItem(currentFragmentTag);
                    break;
                default:
                    break;
            }
            Animation animation = new TranslateAnimation(one * currIndex + offset, one * arg0 + offset, 0, 0);
            currIndex = arg0;
            animation.setFillAfter(true);// true:图片停在动画结束位置
            animation.setDuration(150);
            ivBottomLine.startAnimation(animation);
            animation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                }

                @Override
                public void onAnimationRepeat(Animation animation) {
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                }
            });
        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        @Override
        public void onPageScrollStateChanged(int arg0) {
        }
    }

}
