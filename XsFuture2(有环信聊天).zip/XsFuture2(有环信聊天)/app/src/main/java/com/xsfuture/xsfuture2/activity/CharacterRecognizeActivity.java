package com.xsfuture.xsfuture2.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.ocr.sdk.OCR;
import com.baidu.ocr.sdk.OnResultListener;
import com.baidu.ocr.sdk.exception.OCRError;
import com.baidu.ocr.sdk.model.AccessToken;
import com.baidu.ocr.sdk.model.GeneralParams;
import com.baidu.ocr.sdk.model.GeneralResult;
import com.baidu.ocr.sdk.model.Word;
import com.baidu.ocr.sdk.model.WordSimple;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.tool.SelectPicActivity;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.util.FileService;

import java.io.File;

public class CharacterRecognizeActivity extends BaseActivity {
    private final int TO_SELECT_PHOTO = 1;
    private final int PHOTO_REQUEST_CUT = 2;
    private boolean hasGotToken = false;
    private String end_name;
    private TextView tv_result;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_character_recognize);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitle("");
        initAccessTokenWithAkSk();
        tv_result = (TextView) findViewById(R.id.tv_result);
        Button general_basic_button = (Button) findViewById(R.id.general_basic_button);
        general_basic_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!checkTokenStatus()) return;
                Intent intent = new Intent(getCurrentActivity(), SelectPicActivity.class);
                startActivityForResult(intent, TO_SELECT_PHOTO);
            }
        });
    }


    private boolean checkTokenStatus() {
        if (!hasGotToken) {
            Toast.makeText(getApplicationContext(), "token还未成功获取", Toast.LENGTH_LONG).show();
        }
        return hasGotToken;
    }

    private void initAccessTokenWithAkSk() {
        OCR.getInstance().initAccessTokenWithAkSk(new OnResultListener<AccessToken>() {
            @Override
            public void onResult(AccessToken result) {
                String token = result.getAccessToken();
                hasGotToken = true;
            }

            @Override
            public void onError(OCRError error) {
                error.printStackTrace();
                hasGotToken = false;
                showShortToast("SK方式获取token失败" + error.getMessage());
            }
        }, getApplicationContext(), "Ql0Oae0Lw8PmvmYGQ61N6B81", "ULkm6hcnlKwRXWLEZ8noP0pfbuFX3hX8");
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == TO_SELECT_PHOTO) {
                String picPath = data.getStringExtra(SelectPicActivity.KEY_PHOTO_PATH);
                if (picPath != null) {
                    int i = picPath.lastIndexOf(".");
                    if (i > 0 && i < picPath.length()) {
                        end_name = picPath.substring(i);
                    }
                    crop(Uri.fromFile(new File(picPath)));
                }
            } else if (requestCode == PHOTO_REQUEST_CUT) {
                Bitmap bitmap = data.getParcelableExtra("data");
                String file_path = FileService.getTempPath() + "/" + "temp" + end_name;
                file_path = FileService.saveBitmap(bitmap, file_path);
                // 通用文字识别参数设置
                GeneralParams param = new GeneralParams();
                param.setDetectDirection(true);
                param.setImageFile(new File(file_path));
                // 调用通用文字识别服务
                OCR.getInstance().recognizeGeneral(param, new OnResultListener<GeneralResult>() {
                    @Override
                    public void onResult(GeneralResult result) {
                        StringBuilder sb = new StringBuilder();
                        // 调用成功，返回GeneralResult对象
                        for (WordSimple wordSimple : result.getWordList()) {
                            // Word类包含位置信息
                            Word word = (Word) wordSimple;
                            sb.append(word.getWords());
                            sb.append("\n");
                            tv_result.setText(sb.toString());
                        }
                    }

                    @Override
                    public void onError(OCRError error) {
                        // 调用失败，返回OCRError对象
                    }
                });
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void crop(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        // 裁剪框的比例，1：1
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // 裁剪后输出图片的尺寸大小
        intent.putExtra("outputX", 250);
        intent.putExtra("outputY", 250);
        intent.putExtra("outputFormat", "JPEG");
        // 取消人脸识别
        intent.putExtra("noFaceDetection", true);
        // true:不返回uri，false：返回uri
        intent.putExtra("return-data", true);
        startActivityForResult(intent, PHOTO_REQUEST_CUT);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 释放内存资源
        OCR.getInstance().release();
    }
}