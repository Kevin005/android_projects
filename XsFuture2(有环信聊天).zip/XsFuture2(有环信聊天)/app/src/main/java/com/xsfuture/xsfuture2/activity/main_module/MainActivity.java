package com.xsfuture.xsfuture2.activity.main_module;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.android.pushservice.PushConstants;
import com.baidu.android.pushservice.PushManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.bean.UpdateReqParms;
import com.xsfuture.xsfuture2.bean.UpdateRespone;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.fragment.ConversationListFragment;
import com.xsfuture.xsfuture2.fragment.MainFragment;
import com.xsfuture.xsfuture2.fragment.MeFragment;
import com.xsfuture.xsfuture2.fragment.ShareBooksFragment;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpState;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.base.FrameMainActivity;
import com.xsfuture.xsfuture2.activity.account_module.LoginActivity;
import com.xsfuture.xsfuture2.activity.presenter.PushTestReceiverPresenter;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.StringUtils;
import com.xsfuture.xsfuture2.util.SystemUtil;

import org.json.JSONException;

import java.math.BigDecimal;
import java.util.Calendar;

public class MainActivity extends FrameMainActivity implements OnClickListener {
    // 底部标签切换的Fragment
    private Fragment currentFragment;
    private MainFragment mainFragment;
    private ShareBooksFragment shareBooksFragment;
    private ConversationListFragment chatListFragment;
    private MeFragment meFragment;
    // 底部标签图片
    private ImageView mBooksImg, mImgMe, mImgShareBooks, mImgDiscuss;
    // 底部标签的文本
    private TextView mTvKnow, mTvMe, mTvShareBooks, mTvDiscuss;
    private Dialog dialog;
    private DownLoadBroadcastReceiver receiver;

    @Override
    protected void onPostResume() {
        super.onPostResume();
    }

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        initUI();
        initTab();
        PushManager.startWork(getApplicationContext(), PushConstants.LOGIN_TYPE_API_KEY, ConstSysConfig.BAIDU_PUSH_API_KEY);
    }

    /**
     * fragment 应该已经被回收了。之所以fragment的view之所以还存在，是因为fragment［view］成为activity［view］的child了。
     * 系统对于有id的 view 会尝试恢复的状态。
     * 之所以之前hide［view］显示出来，因为那些view的可见性是对于fragment而言的，对于activity而言全都是具有可见性的
     * 所以解决办法1:onSaveInstanceState()。2:杀掉进程。
     *
     * @param outState
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        //不调用保存状态方法以解决应用被杀恢复时闪退问题
        //super.onSaveInstanceState(outState);
    }

    /**
     * 初始化UI
     */
    private void initUI() {
        mBooksImg = (ImageView) findViewById(R.id.img_know);
        mImgShareBooks = (ImageView) findViewById(R.id.img_share_books);
        mImgDiscuss = (ImageView) findViewById(R.id.img_discuss);
        mImgMe = (ImageView) findViewById(R.id.img_me);
        mTvKnow = (TextView) findViewById(R.id.tv_know);
        mTvShareBooks = (TextView) findViewById(R.id.tv_share_books);
        mTvDiscuss = (TextView) findViewById(R.id.tv_discuss);
        mTvMe = (TextView) findViewById(R.id.tv_me);
    }

    /**
     * 初始化底部标签
     */
    private void initTab() {
        if (mainFragment == null) {
            mainFragment = new MainFragment();
        }

        if (!mainFragment.isAdded()) {
            // 提交事务
            getSupportFragmentManager().beginTransaction().add(R.id.content_layout, mainFragment).commit();
            // 记录当前Fragment
            currentFragment = mainFragment;
            // 设置图片文本的变化
            mBooksImg.setImageResource(R.drawable.main_pre);
            mTvKnow.setTextColor(getResources().getColor(R.color.bottomtab_press));

            mImgShareBooks.setImageResource(R.drawable.mian_nor);
            mTvShareBooks.setTextColor(getResources().getColor(R.color.bottomtab_normal));

            mImgDiscuss.setImageResource(R.drawable.mian_nor);
            mTvDiscuss.setTextColor(getResources().getColor(R.color.bottomtab_normal));

            mImgMe.setImageResource(R.drawable.mine_main_nor);
            mTvMe.setTextColor(getResources().getColor(R.color.bottomtab_normal));
            registerReceiver();
        }
    }

    private void registerReceiver() {
        if (receiver == null) {
            receiver = new DownLoadBroadcastReceiver();
        }
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.DOWNLOAD_COMPLETE");
        intentFilter.addAction("android.intent.action.DOWNLOAD_NOTIFICATION_CLICKED");
        registerReceiver(receiver, intentFilter);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.rl_know: // 首页
                clickTab1Layout();
                break;
            case R.id.rel_share_books:
//                clickTab2Layout();
                break;
            case R.id.rel_discuss:
//                clickTab3Layout();
                break;
            case R.id.rl_me: // 我的
                if (StringUtils.isEmpty(getCurrentActivity().getUser_token())) {
                    Intent intent1 = new Intent(getCurrentActivity(), LoginActivity.class);
                    startActivity(intent1);
                } else {
                    clickTab4Layout();
                }
                break;
            default:
                break;
        }
    }

    /**
     * 点击第一个tab
     */
    private void clickTab1Layout() {
        if (mainFragment == null) {
            mainFragment = new MainFragment();
        }
        addOrShowFragment(getSupportFragmentManager().beginTransaction(), mainFragment);

        // 设置底部tab变化
        mBooksImg.setImageResource(R.drawable.main_pre);
        mTvKnow.setTextColor(getResources().getColor(R.color.bottomtab_press));

        mImgShareBooks.setImageResource(R.drawable.mian_nor);
        mTvShareBooks.setTextColor(getResources().getColor(R.color.bottomtab_normal));

        mImgDiscuss.setImageResource(R.drawable.mian_nor);
        mTvDiscuss.setTextColor(getResources().getColor(R.color.bottomtab_normal));

        mImgMe.setImageResource(R.drawable.mine_main_nor);
        mTvMe.setTextColor(getResources().getColor(R.color.bottomtab_normal));
    }

    /**
     * 点击第二个tab
     */
    private void clickTab2Layout() {
//        if (shareBooksFragment == null) {
//            shareBooksFragment = new ShareBooksFragment();
//        }
//        addOrShowFragment(getSupportFragmentManager().beginTransaction(), shareBooksFragment);

        // 设置底部tab变化
        mBooksImg.setImageResource(R.drawable.mian_nor);
        mTvKnow.setTextColor(getResources().getColor(R.color.bottomtab_press));

        mImgShareBooks.setImageResource(R.drawable.main_pre);
        mTvShareBooks.setTextColor(getResources().getColor(R.color.bottomtab_normal));

        mImgDiscuss.setImageResource(R.drawable.mian_nor);
        mTvDiscuss.setTextColor(getResources().getColor(R.color.bottomtab_normal));

        mImgMe.setImageResource(R.drawable.mine_main_nor);
        mTvMe.setTextColor(getResources().getColor(R.color.bottomtab_normal));
    }

    /**
     * 点击第三个tab
     */
    private void clickTab3Layout() {
//        if (chatListFragment == null) {
//            chatListFragment = new ConversationListFragment();
//        }
//        addOrShowFragment(getSupportFragmentManager().beginTransaction(), chatListFragment);

        // 设置底部tab变化
        mBooksImg.setImageResource(R.drawable.mian_nor);
        mTvKnow.setTextColor(getResources().getColor(R.color.bottomtab_press));

        mImgShareBooks.setImageResource(R.drawable.mian_nor);
        mTvShareBooks.setTextColor(getResources().getColor(R.color.bottomtab_normal));

        mImgDiscuss.setImageResource(R.drawable.main_pre);
        mTvDiscuss.setTextColor(getResources().getColor(R.color.bottomtab_normal));

        mImgMe.setImageResource(R.drawable.mine_main_nor);
        mTvMe.setTextColor(getResources().getColor(R.color.bottomtab_normal));
    }

    /**
     * 点击第四个tab
     */
    private void clickTab4Layout() {
        if (meFragment == null) {
            meFragment = new MeFragment();
        }
        addOrShowFragment(getSupportFragmentManager().beginTransaction(), meFragment);
        mBooksImg.setImageResource(R.drawable.mian_nor);
        mTvKnow.setTextColor(getResources().getColor(R.color.bottomtab_normal));

        mImgShareBooks.setImageResource(R.drawable.mian_nor);
        mTvShareBooks.setTextColor(getResources().getColor(R.color.bottomtab_normal));

        mImgDiscuss.setImageResource(R.drawable.mian_nor);
        mTvDiscuss.setTextColor(getResources().getColor(R.color.bottomtab_normal));

        mImgMe.setImageResource(R.drawable.mine_main_pre);
        mTvMe.setTextColor(getResources().getColor(R.color.bottomtab_press));
    }

    /**
     * 添加或者显示碎片
     *
     * @param transaction
     * @param fragment
     */
    private void addOrShowFragment(FragmentTransaction transaction, Fragment fragment) {
        if (currentFragment == fragment)
            return;
        if (!fragment.isAdded()) { // 如果当前fragment未被添加，则添加到Fragment管理器中
            transaction.hide(currentFragment).add(R.id.content_layout, fragment).commit();
        } else {
            transaction.hide(currentFragment).show(fragment).commit();
        }
        currentFragment = fragment;
    }

//    @Override
//    public void todayClick() {
//        if (mainFragment != null) {
//            mainFragment.refreshChangeFragment(1);
//        }
//    }

    @Override
    public void AddHttpState(HttpState state) {

    }

    // 获得当天0点时间
    @SuppressLint("WrongConstant")
    private long getTimesmorning() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    @Override
    protected void onResume() {
        super.onResume();
        findViewById(R.id.rl_know).setOnClickListener(this);
        findViewById(R.id.rel_share_books).setOnClickListener(this);
        findViewById(R.id.rel_discuss).setOnClickListener(this);
        findViewById(R.id.rl_me).setOnClickListener(this);
        updateVersion();
        isNoReadMessage();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (receiver != null) {
            unregisterReceiver(receiver);
        }
    }

    private void isNoReadMessage() {
        boolean isNoReadMessage = PushTestReceiverPresenter.getInstance().isNoReadMessage(getCurrentActivity());
        if (isNoReadMessage) {
            findViewById(R.id.tv_red_remind).setVisibility(View.VISIBLE);
        } else {
            findViewById(R.id.tv_red_remind).setVisibility(View.GONE);
        }
    }

    private void updateVersion() {
        long software_update = getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0).getLong(ConstSysConfig.SOFTWARE_UPDATE, 0);
        long curretnDay0 = getTimesmorning();
        if (software_update < curretnDay0) {
            checkVersionUpdate();
        }
    }

    /**
     * 检查版本更新
     */
    private void checkVersionUpdate() {
        String currentVersion = SystemUtil.getSoftwareVersionName(getCurrentActivity());
        int currentCode = SystemUtil.getSoftwareVersionCode(getCurrentActivity());
        UpdateReqParms parms = new UpdateReqParms();
        parms.setWhite_list(SystemUtil.getChannelCode(getCurrentActivity()));
        parms.setVersion_code(String.valueOf(currentCode));
        parms.setVersion_name(currentVersion);
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("version_code", parms.getVersion_code());
            obj.put("version_name", parms.getVersion_name());
            obj.put("white_list", parms.getWhite_list());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                try {
                    if (httpResult != null && httpResult.getJsonObject() != null) {
                        JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                        int success = jSONObjectProxy.getIntOrNull("success");
                        String message = jSONObjectProxy.getStringOrNull("message");
                        JSONObjectProxy data = jSONObjectProxy.getJSONObjectOrNull("data");
                        if (success == 0 && data != null) {
                            UpdateRespone updateRespone = new Gson().fromJson(data.toString(), new TypeToken<UpdateRespone>() {
                            }.getType());
                            if (updateRespone != null && !StringUtils.isEmpty(updateRespone.getDownload_url()) && !StringUtils.isEmpty(updateRespone.getPackage_size())) {
                                int pagesize = Integer.valueOf(updateRespone.getPackage_size());
                                boolean isForce = updateRespone.isIs_force_update();
                                String downLoadURL = updateRespone.getDownload_url();
                                showUpdateVersionDialog(updateRespone.getRelease_note(), pagesize, isForce, downLoadURL);
                            }
                        } else {
                            getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0).edit().putLong(ConstSysConfig.SOFTWARE_UPDATE, System.currentTimeMillis()).commit();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0).edit().putLong(ConstSysConfig.SOFTWARE_UPDATE, System.currentTimeMillis()).commit();
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), "更新失败", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.version_update);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.setShow_progressbar(false);
        httpTask.executes(httpSetting);
    }

    private void showUpdateVersionDialog(String decription, int page_byte, boolean isforce, final String downloadUrl) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        View contentView = LayoutInflater.from(this).inflate(R.layout.item_version, null);
        LinearLayout layout_soft = (LinearLayout) contentView.findViewById(R.id.layout_soft);
        TextView tv_force_download = (TextView) contentView.findViewById(R.id.tv_download);
        TextView tv_un_update = (TextView) contentView.findViewById(R.id.tv_un_update);
        TextView tv_cancel = (TextView) contentView.findViewById(R.id.tv_cancel);
        TextView tv_decription = (TextView) contentView.findViewById(R.id.tv_decription_text);
        TextView size = (TextView) contentView.findViewById(R.id.tv_net_tips);
        tv_decription.setText(decription);
        float size_km = (page_byte / 1024.0f) / 1024.0f;
        String pagesize = "*更新包的大小为%1$sMB,建议在wifi环境下更新,书豪请无视*";
        BigDecimal b = new BigDecimal(size_km);
        float f1 = b.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
        String p_size = String.format(pagesize, f1);
        size.setText(p_size);

        if (isforce) {
            //强制更新
            layout_soft.setVisibility(View.GONE);
//            alertDialog.setCancelable(false);
        } else {
            //非强制更新
            layout_soft.setVisibility(View.VISIBLE);
//            alertDialog.setCancelable(false);
        }
        alertDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                cancelRemindUpdate();
            }
        });
        tv_force_download.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //下载
                dialog.dismiss();
                download(downloadUrl);

            }
        });
        tv_un_update.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelRemindUpdate();
                //暂不升级
                dialog.dismiss();
            }
        });
        tv_cancel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelRemindUpdate();
                //不再提示
                dialog.dismiss();
            }
        });
        alertDialog.setView(contentView);
        dialog = alertDialog.create();
        dialog.show();
    }

    private void cancelRemindUpdate(){
        //tomorrow remind update dialog
        getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0).edit().putLong(ConstSysConfig.SOFTWARE_UPDATE, System.currentTimeMillis()).commit();
    }

    private void download(String downloadUrl) {
        DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
        request.setDescription("更新APP");
        request.allowScanningByMediaScanner();// 设置可以被扫描到
        request.setVisibleInDownloadsUi(true);// 设置下载可见
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);//下载完成后通知栏任然可见
        String fileName = downloadUrl.substring(downloadUrl.lastIndexOf("/"));// 解析fileName
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);// 设置下载位置，sdcard/Download/fileName
        long refernece = manager.enqueue(request);// 加入下载并取得下载ID
        getSharedPreferences(ConstSysConfig.UPDATE_PLATFORM, 0).edit().putLong("plato", refernece).commit();//保存此次下载ID
    }

    private class DownLoadBroadcastReceiver extends BroadcastReceiver {
        public void onReceive(Context context, Intent intent) {
            long myDwonloadID = intent.getLongExtra(
                    DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            long refernece = context.getSharedPreferences(ConstSysConfig.UPDATE_PLATFORM, 0).getLong("plato", 0);
            if (refernece == myDwonloadID) {
                cancelRemindUpdate();
                DownloadManager dManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
                Intent install = new Intent(Intent.ACTION_VIEW);
                Uri downloadFileUri = dManager.getUriForDownloadedFile(myDwonloadID);
                install.setDataAndType(downloadFileUri, "application/vnd.android.package-archive");
                install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(install);
            }

        }

    }


}