package com.xsfuture.xsfuture2.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build;
import android.os.Environment;

import com.google.gson.Gson;
import com.xsfuture.xsfuture2.base.XsfutureApplication;
import com.xsfuture.xsfuture2.bean.CrashInfo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.Thread.UncaughtExceptionHandler;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 当程序发生Uncaught异常的时候,有该类来接管程序,并记录发送错误报告.
 */
public class CrashHandlerUtils implements UncaughtExceptionHandler {

    public static final String TAG = CrashHandlerUtils.class.getName();
    // 系统默认的UncaughtException处理类
    private UncaughtExceptionHandler mDefaultHandler;
    // CrashHandler实例
    private static CrashHandlerUtils INSTANCE = new CrashHandlerUtils();
    // 用来存储设备信息和异常信息
    private Map<String, String> infos = new HashMap<String, String>();
    // 程序的Context对象
    private XsfutureApplication mContext;
    // 用于格式化日期,作为日志文件名的一部分
    private DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
    /**
     * 随机实例
     */
    private static final Random DEFULT_RANDOM = new Random();

    /**
     * 保证只有一个CrashHandler实例
     */
    private CrashHandlerUtils() {
    }

    /**
     * 获取CrashHandler实例 ,单例模式
     */
    public static CrashHandlerUtils getInstance() {
        return INSTANCE;
    }

    /**
     * 初始化
     */
    public void init(XsfutureApplication application) {
        mContext = application;
        // 获取系统默认的UncaughtException处理器
        mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        // 设置该CrashHandler为程序的默认处理器
        Thread.setDefaultUncaughtExceptionHandler(this);
    }

    /**
     * 当UncaughtException发生时会转入该函数来处理
     */
    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        handleException(ex);
        if (mDefaultHandler != null) {
            // 如果用户没有处理则让系统默认的异常处理器来处理
            mDefaultHandler.uncaughtException(thread, ex);
        }
    }

    /**
     * 自定义错误处理,收集错误信息 发送错误报告等操作均在此完成.
     *
     * @param ex
     * @return true:如果处理了该异常信息;否则返回false.
     */
    private boolean handleException(Throwable ex) {
        if (ex == null) {
            return false;
        }
        // 收集设备参数信息
        collectDeviceInfo(mContext);
        // 保存日志文件
        saveCrashInfo2File(ex);
        return true;
    }

    /**
     * 收集设备参数信息
     *
     * @param ctx
     */
    private void collectDeviceInfo(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            PackageInfo pi = pm.getPackageInfo(ctx.getPackageName(),
                    PackageManager.GET_ACTIVITIES);
            if (pi != null) {
                String versionName = pi.versionName == null ? "null"
                        : pi.versionName;
                String versionCode = pi.versionCode + "";
                infos.put("versionName", versionName);
                infos.put("versionCode", versionCode);
            }
        } catch (NameNotFoundException e) {
            Log.e(TAG, "an error occured when collect package info", e);
        }
        Field[] fields = Build.class.getDeclaredFields();
        for (Field field : fields) {
            try {
                field.setAccessible(true);
                infos.put(field.getName(), field.get(null).toString());
            } catch (Exception e) {
            }
        }
    }

    /**
     * 保存错误信息到文件中
     *
     * @param ex
     * @return 返回文件名称, 便于将文件传送到服务器
     */
    private String saveCrashInfo2File(Throwable ex) {
        String file_path = "";
        CrashInfo info = new CrashInfo();
        for (Map.Entry<String, String> entry : infos.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            info.setPlatform("android");
            info.setOsversion(Build.VERSION.RELEASE);
            info.setManufacturer(Build.MANUFACTURER);
            info.setModel(Build.MODEL);
            if ("DISPLAY".equals(key)) {
                info.setDisplay(value);
            }
            info.setTime(formatter.format(new Date()));
            if ("versionName".equals(key)) {
                info.setVersionName(value);
            }
            if ("versionCode".equals(key)) {
                info.setVersionCode(value);
            }
        }

        Writer writer = new StringWriter();
        PrintWriter printWriter = new PrintWriter(writer);
        ex.printStackTrace(printWriter);
        Throwable cause = ex.getCause();
        while (cause != null) {
            cause.printStackTrace(printWriter);
            cause = cause.getCause();
        }
        printWriter.close();
        String result = writer.toString();
        info.setContent(result);
        try {
            String time = formatter.format(new Date());
            String fileName = "crash-" + time + "-" + makeRandom(10) + ".txt";
            if (Environment.getExternalStorageState().equals(
                    Environment.MEDIA_MOUNTED)) {
                String path = Environment.getExternalStorageDirectory()
                        + "/xsfuture/crash/";
                File dir = new File(path);
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                file_path = path + fileName;
                FileOutputStream fos = new FileOutputStream(path + fileName);
                String crashJson = new Gson().toJson(info);
                fos.write(crashJson.getBytes());
                fos.close();
            }
            return file_path;
        } catch (Exception e) {
        }
        return file_path;
    }

    private String makeRandom(int len) {

        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < len; i++) {
            buffer.append(DEFULT_RANDOM.nextInt(10));
        }
        return buffer.toString();
    }

    //压缩文件
    private String zipFile(File resFile) throws FileNotFoundException,
            IOException {
        int BUFF_SIZE = 1024 * 1024;
        String zip_path = resFile.getAbsolutePath();
        String zip_name = zip_path.substring(0, zip_path.lastIndexOf(".") + 1) + "zip";
        File zipFile = new File(zip_name);

        ZipOutputStream zipout = new ZipOutputStream(new BufferedOutputStream(
                new FileOutputStream(zipFile), BUFF_SIZE));
        zipout.putNextEntry(new ZipEntry(resFile.getName()));
        byte buffer[] = new byte[BUFF_SIZE];
        BufferedInputStream in = new BufferedInputStream(new FileInputStream(
                resFile), BUFF_SIZE);
        int realLength = 0;
        while ((realLength = in.read(buffer)) != -1) {
            zipout.write(buffer, 0, realLength);
        }
        zipout.flush();
        in.close();
        zipout.closeEntry();
        zipout.close();
        return zip_name;
    }

}
