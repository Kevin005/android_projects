package com.xsfuture.xsfuture2.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.main_module.CommentBackActivity;
import com.xsfuture.xsfuture2.bean.CommentsItemInfo;
import com.xsfuture.xsfuture2.util.DateUtils;
import com.xsfuture.xsfuture2.view.CircularImage;
import com.xsfuture.xsfuture2.view.GenderSelectorImage;

import java.util.ArrayList;
import java.util.List;


public class ReadingBookJournalEntryDetailsAdapter extends BaseAdapter {

    private List<CommentsItemInfo> data;
    private LayoutInflater inflater;
    private ActivityHandlerInterface context;

    public ReadingBookJournalEntryDetailsAdapter(ActivityHandlerInterface context) {
        this.context = context;
        inflater = LayoutInflater.from(context.getCurrentActivity());
        data = new ArrayList<CommentsItemInfo>();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public CommentsItemInfo getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void addData(List<CommentsItemInfo> new_data) {
        if (data == null) {
            data = new ArrayList<CommentsItemInfo>();
        }
        if (new_data != null && new_data.size() > 0) {
            data.addAll(new_data);
            notifyDataSetChanged();
        }
    }

    public void setData(List<CommentsItemInfo> new_data) {
        if (data == null) {
            data = new ArrayList<CommentsItemInfo>();
        } else {
            data.clear();
        }
        if (new_data != null && new_data.size() > 0) {
            data.addAll(new_data);
        }
        notifyDataSetChanged();
    }

    public List<CommentsItemInfo> getData() {
        return data;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        final CommentsItemInfo item = data.get(position);
        holder = new ViewHolder();
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_jornalentry_detail, null);
            holder.tv_name = (TextView) convertView.findViewById(R.id.tv_name);
            holder.img_user = (CircularImage) convertView.findViewById(R.id.img_user);
            holder.img_gender_selector = (GenderSelectorImage) convertView.findViewById(R.id.img_gender_selector);
            holder.tv_time = (TextView) convertView.findViewById(R.id.tv_time);
            holder.tv_content = (TextView) convertView.findViewById(R.id.tv_content);
            holder.line_dynamic = (LinearLayout) convertView.findViewById(R.id.line_dynamic);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        if (item != null) {
            if (item.getGender() == 1) {
                holder.img_gender_selector.setWomanMark();
            } else {
                holder.img_gender_selector.setManMark();
            }
            Glide.with(context.getCurrentActivity())
                    .load(item.getUser_image())
                    .placeholder(R.drawable.avatar)
                    .error(R.drawable.avatar)
                    .skipMemoryCache(false )//跳过内存缓存
                    .diskCacheStrategy(DiskCacheStrategy.RESULT)
                    .into(holder.img_user);

            holder.tv_name.setText(item.getNick_name());
            holder.tv_time.setText(DateUtils.TimeStamp2Date(String.valueOf(item.getTime_stamp())));
            holder.tv_content.setText(String.valueOf(item.getContent()));
            holder.line_dynamic.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context.getCurrentActivity(), CommentBackActivity.class);
                    intent.putExtra("reader_response_id", item.getReader_response_id());
                    intent.putExtra("comment_id",item.getComment_id());
                    intent.putExtra("remind_sb", "@" + item.getNick_name() + " ");
                    context.getCurrentActivity().startActivityForResult(intent, 1);
                }
            });
        }
        return convertView;
    }

    public class ViewHolder {
        TextView tv_name;
        TextView tv_time;
        CircularImage img_user;
        GenderSelectorImage img_gender_selector;
        TextView tv_content;
        LinearLayout line_dynamic;
    }
}
