package com.xsfuture.xsfuture2.activity.presenter;

import android.content.Context;

import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.http.OkHttpTask;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.Log;

import org.json.JSONException;

/**
 * Created by Kevin on 2016/12/30.
 */
public class PushTestReceiverPresenter {
    private final String TAG = PushTestReceiverPresenter.class.getName();
    private static PushTestReceiverPresenter presenter;

    public static PushTestReceiverPresenter getInstance() {
        if (presenter == null) {
            presenter = new PushTestReceiverPresenter();
        }
        return presenter;
    }

    public void postChannelId(Context context, String channelId) {
        saveChannelId(context, channelId);
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("channel_id", channelId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        OkHttpTask.getInstance().actionPost(context, ConstFuncId.xiaoshi_user_update_channel_id, obj.toString(), new OkHttpTask.OkCallback() {
            @Override
            public void onEnd(String responseStr) {
                Log.i(TAG, responseStr);
            }

            @Override
            public void onError() {

            }
        });
    }

    public void setNoReadMessage(Context context) {
        context.getSharedPreferences(ConstSysConfig.SYS_MESSAGE, 0).edit().putBoolean(ConstSysConfig.IS_NO_READ_COMMENT_MESSAGE, true).commit();
    }

    public void setReadedMessage(Context context) {
        context.getSharedPreferences(ConstSysConfig.SYS_MESSAGE, 0).edit().putBoolean(ConstSysConfig.IS_NO_READ_COMMENT_MESSAGE, false).commit();
    }

    public boolean isNoReadMessage(Context context) {
        return context.getSharedPreferences(ConstSysConfig.SYS_MESSAGE, 0).getBoolean(ConstSysConfig.IS_NO_READ_COMMENT_MESSAGE, false);
    }

    private void saveChannelId(Context context, String channelId) {
        context.getSharedPreferences(ConstSysConfig.SYS_MESSAGE, 0).edit().putString(ConstSysConfig.BAIDU_PUSH_CHANNLE_ID, channelId).commit();
    }

}
