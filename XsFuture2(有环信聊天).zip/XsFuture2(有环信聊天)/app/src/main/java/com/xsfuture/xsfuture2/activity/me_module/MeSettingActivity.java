package com.xsfuture.xsfuture2.activity.me_module;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.activity.main_module.MainActivity;
import com.xsfuture.xsfuture2.activity.statistics_module.CalendarActivity;
import com.xsfuture.xsfuture2.bean.UpdateReqParms;
import com.xsfuture.xsfuture2.bean.UpdateRespone;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.StringUtils;
import com.xsfuture.xsfuture2.util.SystemUtil;

import org.json.JSONException;

public class MeSettingActivity extends BaseActivity {
    private RelativeLayout rel_version_update;
    private RelativeLayout rel_pass_through;
    private RelativeLayout title;
    private Button exit_account;
    private TextView tv_red_remind_version;
    private TextView tv_version_num;

    private UpdateRespone updateRespone;
    private boolean is_latest = true;
    private int pass_through = 0;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_setting);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleText("设置");
        setTitleTextClick(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pass_through >= 9) {
                    rel_pass_through.setVisibility(View.VISIBLE);
                }
                pass_through++;
            }
        });
        setTitleLeftBtn(R.string.back, new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initView();
    }

    private void initView() {
        tv_red_remind_version = (TextView) findViewById(R.id.tv_red_remind_version);
        tv_version_num = (TextView) findViewById(R.id.tv_version_num);
        rel_version_update = (RelativeLayout) findViewById(R.id.rel_version_update);
        rel_version_update.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (is_latest) {
                    showShortToast("已经是最新版本");
                } else {
                    if (updateRespone != null && !StringUtils.isEmpty(updateRespone.getDownload_url()) && !StringUtils.isEmpty(updateRespone.getVersion_name()) && !StringUtils.isEmpty(updateRespone.getRelease_note()) && !StringUtils.isEmpty(updateRespone.getPackage_size())) {
                        int packagesize = Integer.valueOf(updateRespone.getPackage_size());
                        boolean isForce = updateRespone.isIs_force_update();
                        String downLoadURL = updateRespone.getDownload_url();
                        Intent intent = new Intent(getCurrentActivity(), VersionUpdateActivity.class);
                        intent.putExtra("release_note", updateRespone.getRelease_note());
                        intent.putExtra("package_size", packagesize);
                        intent.putExtra("is_force", isForce);
                        intent.putExtra("download_url", downLoadURL);
                        startActivity(intent);
                    }
                }
            }
        });
        rel_pass_through = (RelativeLayout) findViewById(R.id.rel_pass_through);
        rel_pass_through.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getCurrentActivity(), CalendarActivity.class));
            }
        });
        title = (RelativeLayout) findViewById(R.id.title);
        title.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        exit_account = (Button) findViewById(R.id.exit_account);
        exit_account.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
//                EMClient.getInstance().logout(true);//TODO
                SharedPreferences sharedPreferences = getCurrentActivity().getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0);
                sharedPreferences.edit().putString("token", "").commit();
                Intent intent = new Intent(getCurrentActivity(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
        RelativeLayout rel_feedback = (RelativeLayout) findViewById(R.id.rel_feedback);
        rel_feedback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), FeedBackActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkVersionUpdate();
    }

    /**
     * 检查版本更新
     */
    private void checkVersionUpdate() {
        String currentVersion = SystemUtil.getSoftwareVersionName(getCurrentActivity());
        int currentCode = SystemUtil.getSoftwareVersionCode(getCurrentActivity());
        UpdateReqParms parms = new UpdateReqParms();
        parms.setWhite_list(SystemUtil.getChannelCode(getCurrentActivity()));
        parms.setVersion_code(String.valueOf(currentCode));
        parms.setVersion_name(currentVersion);
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("version_code", parms.getVersion_code());
            obj.put("version_name", parms.getVersion_name());
            obj.put("white_list", parms.getWhite_list());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                try {
                    if (httpResult != null && httpResult.getJsonObject() != null) {
                        JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                        int success = jSONObjectProxy.getIntOrNull("success");
                        String message = jSONObjectProxy.getStringOrNull("message");
                        JSONObjectProxy data = jSONObjectProxy.getJSONObjectOrNull("data");
                        if (success == 0) {
                            if (data != null) {
                                updateRespone = new Gson().fromJson(data.toString(), new TypeToken<UpdateRespone>() {
                                }.getType());
                                if (updateRespone != null && !StringUtils.isEmpty(updateRespone.getDownload_url()) && !StringUtils.isEmpty(updateRespone.getVersion_name()) && !StringUtils.isEmpty(updateRespone.getRelease_note()) && !StringUtils.isEmpty(updateRespone.getPackage_size())) {
                                    is_latest = false;
                                    tv_red_remind_version.setVisibility(View.VISIBLE);
                                    tv_version_num.setVisibility(View.VISIBLE);
                                    tv_version_num.setText(updateRespone.getVersion_name());
                                }
                            } else {
                                is_latest = true;
                                tv_red_remind_version.setVisibility(View.GONE);
                                tv_version_num.setVisibility(View.GONE);
                            }
                        } else {
                            showShortToast(message);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0).edit().putLong(ConstSysConfig.SOFTWARE_UPDATE, System.currentTimeMillis()).commit();
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), "更新失败", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.version_update);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.setShow_progressbar(false);
        httpTask.executes(httpSetting);
    }

}