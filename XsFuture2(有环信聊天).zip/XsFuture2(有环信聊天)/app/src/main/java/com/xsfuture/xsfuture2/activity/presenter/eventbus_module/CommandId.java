package com.xsfuture.xsfuture2.activity.presenter.eventbus_module;

/**
 * Created by Kevin on 2017/6/14.
 */

public class CommandId {
    public static final int COMMAND_ID_1 = 1;//刷新
    public static final int COMMAND_ID_2 = 2;//重新获取数据
}
