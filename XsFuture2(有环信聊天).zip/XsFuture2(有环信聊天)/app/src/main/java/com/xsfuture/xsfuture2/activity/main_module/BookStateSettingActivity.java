package com.xsfuture.xsfuture2.activity.main_module;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.view.CheckSwitchButton;

import org.json.JSONException;

public class BookStateSettingActivity extends BaseActivity {

    private RelativeLayout rel_archive_book;
    private RelativeLayout rel_delete_book;
    private CheckSwitchButton mCheckSwithcButton;
    private TextView tv_permissions;

    private final int action_type_for_delete = 0;
    private final int action_type_for_archive = 1;
    private boolean is_private = false;
    private String book_name;
    private int post_id;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_book_state_setting);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleText("读书设置");
        setTitleLeftBtn(R.string.back, new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initExtraData();
        initView();
    }

    private void initExtraData() {
        book_name = "《" + getIntent().getStringExtra("book_name") + "》";
        post_id = getIntent().getIntExtra("post_id", 0);
    }

    private void initView() {
        tv_permissions = (TextView) findViewById(R.id.tv_permissions);
        mCheckSwithcButton = (CheckSwitchButton) findViewById(R.id.mCheckSwithcButton);
        mCheckSwithcButton.setChecked(true);
        is_private = false;
        mCheckSwithcButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    is_private = false;
                    tv_permissions.setText("公开");
                } else {
                    is_private = true;
                    tv_permissions.setText("私人");
                }
            }
        });
        rel_archive_book = (RelativeLayout) findViewById(R.id.rel_archive_book);
        rel_archive_book.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                showConfirmDialog("完结读书", book_name, action_type_for_archive);
            }
        });
        rel_delete_book = (RelativeLayout) findViewById(R.id.rel_delete_book);
        rel_delete_book.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                showConfirmDialog("删除读书", book_name, action_type_for_delete);
            }
        });
    }

    private void showConfirmDialog(String title_msg, String content_msg, final int action_type) {
        final AlertDialog dlg = new AlertDialog.Builder(getCurrentActivity()).create();
        dlg.show();
        Window window = dlg.getWindow();
        window.setContentView(R.layout.view_dialog);
        TextView title = (TextView) window.findViewById(R.id.title);
        title.setText(title_msg);
        TextView content = (TextView) window.findViewById(R.id.content);
        content.setText(content_msg);
        Button ok = (Button) window.findViewById(R.id.ok);
        Button cancle = (Button) window.findViewById(R.id.cancle);
        ok.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                switch (action_type) {
                    case action_type_for_archive:
                        archiveBook();
                        break;
                    case action_type_for_delete:
                        deleteBook();
                        break;
                    default:
                        break;
                }
                dlg.dismiss();
            }
        });
        cancle.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                dlg.dismiss();
            }
        });
        window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }

    private void archiveBook() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("post_id", post_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        Intent intent = new Intent(getCurrentActivity(), MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_post_post_archive);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    private void deleteBook() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("post_id", post_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        Intent intent = new Intent(getCurrentActivity(), MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_post_del_post);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

}