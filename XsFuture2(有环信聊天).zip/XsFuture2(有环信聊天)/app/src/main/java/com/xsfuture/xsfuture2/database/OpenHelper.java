package com.xsfuture.xsfuture2.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class OpenHelper extends SQLiteOpenHelper {

    public OpenHelper(Context context, String name, CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        CacheFileTableDBHelper.create(db);//缓存文件http_task
        UserInfoDBHelper.create(db);//用户表
        DraftInfoDBHelper.create(db);//读后感草稿表
//        ConversationListInfoDBHelper.create(db);//聊天会话列表
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < newVersion) {
            CacheFileTableDBHelper.upgrade(db, oldVersion, newVersion);
            UserInfoDBHelper.upgrade(db, oldVersion, newVersion);
            DraftInfoDBHelper.upgrade(db, oldVersion, newVersion);
//            ConversationListInfoDBHelper.upgrade(db, oldVersion, newVersion);
        }
    }

}
