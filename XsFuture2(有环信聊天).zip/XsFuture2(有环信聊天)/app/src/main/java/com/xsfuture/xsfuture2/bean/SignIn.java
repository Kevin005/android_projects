package com.xsfuture.xsfuture2.bean;

public class SignIn {
    private int sign_in_id;
    private String sign_time;
    private int user_id;
    private int post_id;

    public int getSign_in_id() {
        return sign_in_id;
    }

    public void setSign_in_id(int sign_in_id) {
        this.sign_in_id = sign_in_id;
    }

    public String getSign_time() {
        return sign_time;
    }

    public void setSign_time(String sign_time) {
        this.sign_time = sign_time;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getPost_id() {
        return post_id;
    }

    public void setPost_id(int post_id) {
        this.post_id = post_id;
    }


}
