package com.xsfuture.xsfuture2.http;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;

import com.xsfuture.xsfuture2.R;

import java.util.concurrent.atomic.AtomicInteger;

public class HttpState {

	private LayoutParams layoutParams;
	private LayoutParams layoutParamsIn;
	private ViewGroup modal;
	private Activity myActivity;
	private AtomicInteger cnt;
	private ImageView imageView;
	private ViewGroup rootFrameLayout;

	public HttpState(Activity myactivity) {
		cnt = new AtomicInteger(0);
		myActivity = myactivity;
		layoutParams = new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		layoutParamsIn = new LayoutParams(LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT);
		layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
		layoutParamsIn.addRule(RelativeLayout.CENTER_IN_PARENT);
	}

	@SuppressWarnings("deprecation")
	public ViewGroup getModal() {
		if (modal == null) {
			modal = new RelativeLayout(myActivity);
			modal.setOnTouchListener(new View.OnTouchListener() {

				@Override
				public boolean onTouch(View v, MotionEvent event) {
					// TODO Auto-generated method stub
					return true;
				}
			});
			ColorDrawable colordrawable = new ColorDrawable(Color.argb(0, 0, 0, 0));
			colordrawable.setAlpha(100);
			modal.setBackgroundDrawable(colordrawable);
			/*
			 * if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB){
			 * modal.setBackground(colordrawable); }else{
			 * modal.setBackgroundDrawable(colordrawable); }
			 */

		}
		return modal;
	}

	private ViewGroup getRootFrameLayout() {
		if (rootFrameLayout == null) {
			rootFrameLayout = (ViewGroup) myActivity.getWindow().peekDecorView();
			if (rootFrameLayout == null) {
				try {
					Thread.sleep(50l);
				} catch (InterruptedException interruptedexception) {
				}
				rootFrameLayout = getRootFrameLayout();
			}
		}
		return rootFrameLayout;
	}

	private void createNewProgressBar() {
		if (modal != null) {
			modal.removeView(imageView);
			imageView = new ImageView(myActivity);
			imageView.setImageResource(R.drawable.bg_loding);
			Animation anim = AnimationUtils.loadAnimation(myActivity, R.anim.loding_animation);
			imageView.setAnimation(anim);
			modal.addView(imageView, layoutParams);
		}
	}

	private void addModal() {
		rootFrameLayout = getRootFrameLayout();
		modal = getModal();
		createNewProgressBar();
		rootFrameLayout.post(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				rootFrameLayout.addView(modal, layoutParamsIn);
				rootFrameLayout.invalidate();
			}
		});
	}

	public boolean show() {
		cnt.incrementAndGet();
		if (cnt.intValue() > 1) {
			return false;
		} else {
			addModal();
			return true;
		}
	}

	public boolean remove() {
		cnt.decrementAndGet();
		if (cnt.intValue() <= 0) {
			removeModal();
			return true;
		} else {
			return false;
		}
	}

	private void removeModal() {
		if (rootFrameLayout != null && modal != null)
			rootFrameLayout.post(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					rootFrameLayout.removeView(modal);
					rootFrameLayout.invalidate();
				}

			});
	}
}
