package com.xsfuture.xsfuture2.activity.main_module;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.StringUtils;

import org.json.JSONException;

public class CommentBackActivity extends BaseActivity {
    private EditText edt_send_msg;
    private Button btn_send_msg;
    private RelativeLayout rel_comment_back;

    private int reader_response_id;
    private String remind_sb;
    private int comment_id;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_comment_back);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        return super.dispatchTouchEvent(event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_BUTTON_PRESS){

        }
        return super.onTouchEvent(event);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            // 透明状态栏
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        initExtra();
        initView();
    }

    private void initExtra() {
        reader_response_id = getIntent().getIntExtra("reader_response_id", -1);
        remind_sb = getIntent().getStringExtra("remind_sb");
        comment_id = getIntent().getIntExtra("comment_id", 0);
    }

    private void initView() {
        edt_send_msg = (EditText) findViewById(R.id.edt_send_msg);
        if (!StringUtils.isEmpty(remind_sb)) {
            edt_send_msg.setText(remind_sb);
            edt_send_msg.setSelection(edt_send_msg.getText().length());
        }
        btn_send_msg = (Button) findViewById(R.id.btn_send_msg);
        btn_send_msg.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check()) {
                    commentBack();
                }
            }
        });
        rel_comment_back = (RelativeLayout) findViewById(R.id.rel_comment_back);
        rel_comment_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private boolean check() {
        String edtStrin = edt_send_msg.getText().toString();
        if (StringUtils.isEmpty(edtStrin)) {
            Toast.makeText(getCurrentActivity(), "沒有写评论内容哦", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void commentBack() {

        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("reader_response_id", reader_response_id);
            obj.put("content", edt_send_msg.getText().toString());
            if (comment_id != 0) {
                obj.put("reply_id", comment_id);
            } else {
                obj.put("reply_id", "");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONObjectProxy data = jSONObjectProxy.getJSONObjectOrNull("data");
                    if (success == 0 && data != null) {
                        Intent intent = new Intent();
                        intent.putExtra("content", edt_send_msg.getText().toString());
                        setResult(RESULT_OK, intent); //intent为A传来的带有Bundle的intent，当然也可以自己定义新的Bundle
                        finish();
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_comment_create);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

}