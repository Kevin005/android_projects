package com.xsfuture.xsfuture2.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;

/**
 * Created by Administrator on 2016/12/2.
 */
public class BitmapUtils {
    public static Bitmap getBitmap(String path) {
        if (!StringUtils.isEmpty(path)) {
            File file = new File(path);
            if (file.exists()) {
                return BitmapFactory.decodeFile(path);
            }
        }
        return null;
    }
}
