package com.xsfuture.xsfuture2.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

import com.xsfuture.xsfuture2.R;

/**
 * 联合组件
 * 设置男性图标{@link GenderSelectorImage#setManMark()}
 * 设置女性图标{@link GenderSelectorImage#setWomanMark()}
 */
public class GenderSelectorImage extends ImageView {

    public GenderSelectorImage(Context paramContext) {
        super(paramContext);
    }

    public GenderSelectorImage(Context paramContext, AttributeSet paramAttributeSet) {
        super(paramContext, paramAttributeSet);
    }

    public GenderSelectorImage(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
        super(paramContext, paramAttributeSet, paramInt);
    }

    public void setManMark() {
        setImageResource(R.drawable.man_mark);
    }

    public void setWomanMark() {
        setImageResource(R.drawable.woman_mark);
    }

}
