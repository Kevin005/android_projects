package com.xsfuture.xsfuture2.activity.me_module;

import android.app.Dialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.config.ConstSysConfig;

import java.math.BigDecimal;

public class VersionUpdateActivity extends BaseActivity {
    private Dialog dialog;
    private DownLoadBroadcastReceiver receiver;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_version_update);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleText("版本升级");
        setTitleLeftBtn(R.string.back, new OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initView();
        try {
            registerReceiver();
            initExtra();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initExtra() throws Exception {
        String release_note = getIntent().getStringExtra("release_note");
        int package_size = getIntent().getIntExtra("package_size", 0);
        boolean is_force = getIntent().getBooleanExtra("is_force", false);
        String download_url = getIntent().getStringExtra("download_url");
        showUpdateVersionDialog(release_note, package_size, is_force, download_url);
    }

    private void initView() {
        TextView tv_version_name = (TextView) findViewById(R.id.tv_version_name);
        tv_version_name.setText("当前版本 " + getVersion());
    }

    /**
     * 获取版本号
     *
     * @return 当前应用的版本号
     */
    public String getVersion() {
        String version = "";
        try {
            PackageManager manager = this.getPackageManager();
            PackageInfo packageInfo = manager.getPackageInfo(getCurrentActivity().getPackageName(), 0);
            version = packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return version;
    }

    private void showUpdateVersionDialog(String decription, int page_byte, boolean isforce, final String downloadUrl) throws Exception {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this, R.style.AlertDialogCustom);
        View contentView = LayoutInflater.from(this).inflate(R.layout.item_version, null);
        LinearLayout layout_soft = (LinearLayout) contentView.findViewById(R.id.layout_soft);
        TextView tv_force_download = (TextView) contentView.findViewById(R.id.tv_download);
        TextView tv_un_update = (TextView) contentView.findViewById(R.id.tv_un_update);
        TextView tv_cancel = (TextView) contentView.findViewById(R.id.tv_cancel);
        TextView tv_decription = (TextView) contentView.findViewById(R.id.tv_decription_text);
        TextView size = (TextView) contentView.findViewById(R.id.tv_net_tips);
        tv_decription.setText(decription);
        float size_km = (page_byte / 1024.0f) / 1024.0f;
        String pagesize = "*更新包的大小为%1$sMB,建议在wifi环境下更新,书豪请无视*";
        BigDecimal b = new BigDecimal(size_km);
        float f1 = b.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
        String p_size = String.format(pagesize, f1);
        size.setText(p_size);

        if (isforce) {
            //强制更新
            layout_soft.setVisibility(View.GONE);
//            alertDialog.setCancelable(false);
        } else {
            //非强制更新
            layout_soft.setVisibility(View.VISIBLE);
//            alertDialog.setCancelable(false);
        }

        tv_force_download.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //下载
                dialog.dismiss();
                try {
                    download(downloadUrl);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        tv_un_update.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //暂不升级
                dialog.dismiss();
            }
        });
        tv_cancel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //不再提示
                dialog.dismiss();
            }
        });
        alertDialog.setView(contentView);
        dialog = alertDialog.create();
        dialog.show();
    }

    public void download(String downloadUrl) throws Exception {
        DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
        request.setDescription("更新APP");
        request.allowScanningByMediaScanner();// 设置可以被扫描到
        request.setVisibleInDownloadsUi(true);// 设置下载可见
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);//下载完成后通知栏任然可见
        String fileName = downloadUrl.substring(downloadUrl.lastIndexOf("/"));// 解析fileName
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);// 设置下载位置，sdcard/Download/fileName
        long refernece = manager.enqueue(request);// 加入下载并取得下载ID
        getSharedPreferences(ConstSysConfig.UPDATE_PLATFORM, 0).edit().putLong("plato", refernece).commit();//保存此次下载ID
    }

    private class DownLoadBroadcastReceiver extends BroadcastReceiver {
        public void onReceive(Context context, Intent intent) {
            long myDwonloadID = intent.getLongExtra(
                    DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            long refernece = context.getSharedPreferences(ConstSysConfig.UPDATE_PLATFORM, 0).getLong("plato", 0);
            if (refernece == myDwonloadID) {
                getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0).edit().putLong(ConstSysConfig.SOFTWARE_UPDATE, System.currentTimeMillis()).commit();
                DownloadManager dManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
                Intent install = new Intent(Intent.ACTION_VIEW);
                Uri downloadFileUri = dManager.getUriForDownloadedFile(myDwonloadID);
                install.setDataAndType(downloadFileUri, "application/vnd.android.package-archive");
                install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(install);
            }
        }
    }

    private void registerReceiver() {
        if (receiver == null) {
            receiver = new DownLoadBroadcastReceiver();
        }
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.DOWNLOAD_COMPLETE");
        intentFilter.addAction("android.intent.action.DOWNLOAD_NOTIFICATION_CLICKED");
        registerReceiver(receiver, intentFilter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (receiver != null) {
            unregisterReceiver(receiver);
        }
    }


}