package com.xsfuture.xsfuture2.activity.main_module;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.ReadingBookJournalEntryDetailsAdapter;
import com.xsfuture.xsfuture2.bean.CommentsItemInfo;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.database.UserInfoDBHelper;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.DateUtils;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.view.RichtextLinearlayout;
import com.xsfuture.xsfuture2.view.xlistview.XListView;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class ReadingBookJournalEntryDetailsActiviy extends BaseActivity implements XListView.IXListViewListener {
    private XListView xlistview_detail;
    private ReadingBookJournalEntryDetailsAdapter adatper;

    private int time_stamp;
    private int readed_page_number;
    private String content;
    private int favor_total;
    private int comment_total;
    private int reader_response_id;
    private boolean is_favored;
    //listivew
    private int current_page = 0;
    private int page_size = 50;
    private final int COMMENTBACK_RESULT_FLAG = 1;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_reading_book_journal_entry_detail);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        initData();
        setTitleLeftBtn(R.string.back, new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initView();
    }

    private void initData() {
        time_stamp = getIntent().getIntExtra("time_stamp", 0);
        readed_page_number = getIntent().getIntExtra("readed_page_number", 0);
        content = getIntent().getStringExtra("content");
        favor_total = getIntent().getIntExtra("favor_total", 0);
        comment_total = getIntent().getIntExtra("comment_total", 0);
        is_favored = getIntent().getBooleanExtra("is_favored", false);
        reader_response_id = getIntent().getIntExtra("reader_response_id", 0);
    }

    private void initView() {
        xlistview_detail = (XListView) findViewById(R.id.xlistview_detail);
        xlistview_detail.setPullRefreshEnable(false);
        xlistview_detail.setPullLoadEnable(false);
        xlistview_detail.setXListViewListener(this);
        View headerView = addListViewHeader();
        xlistview_detail.addHeaderView(headerView);
        adatper = new ReadingBookJournalEntryDetailsAdapter(getCurrentActivity());
        xlistview_detail.setAdapter(adatper);
        getComments();
    }

    private TextView tv_favor_total;
    private ImageView img_favor;
    private TextView tv_comment_total;

    private View addListViewHeader() {
        View headView = LayoutInflater.from(this).inflate(R.layout.headerview_reading_book_journal_entry_detail, null);
        //get id
        TextView response_date = (TextView) headView.findViewById(R.id.response_date);
        TextView response_pagenum = (TextView) headView.findViewById(R.id.response_pagenum);
        RichtextLinearlayout myline_reader_reponse = (RichtextLinearlayout) headView.findViewById(R.id.myline_reader_reponse);
        tv_favor_total = (TextView) headView.findViewById(R.id.tv_favor_total);
        tv_comment_total = (TextView) headView.findViewById(R.id.tv_comment_total);
        //set id
        response_date.setText(DateUtils.TimeStamp2Date(String.valueOf(time_stamp)));
        response_pagenum.setText(readed_page_number + "页");
        myline_reader_reponse.actionAddView(content);
        tv_favor_total.setText(String.valueOf(favor_total));
        tv_comment_total.setText(String.valueOf(comment_total));
        LinearLayout line_comment = (LinearLayout) headView.findViewById(R.id.line_comment);
        line_comment.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getCurrentActivity(), CommentBackActivity.class);
                intent.putExtra("reader_response_id", reader_response_id);
                intent.putExtra("remind_sb", "");
                startActivityForResult(intent, COMMENTBACK_RESULT_FLAG);
            }
        });
        LinearLayout line_favor = (LinearLayout) headView.findViewById(R.id.line_favor);
        line_favor.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                favorOn();
            }
        });
        img_favor = (ImageView) headView.findViewById(R.id.img_favor);
        setFavorImage();
        return headView;
    }

    private void setFavorImage() {
        if (img_favor != null) {
            if (is_favored) {
                img_favor.setImageResource(R.drawable.favored);
                tv_favor_total.setTextColor(getResources().getColor(R.color.main_color));
            } else {
                img_favor.setImageResource(R.drawable.favor);
                tv_favor_total.setTextColor(getResources().getColor(R.color.item_text_color));
            }
        }
    }

    private synchronized void getComments() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("reader_response_id", reader_response_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                onXListViewStop();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        JSONArrayPoxy array = jSONObjectProxy.getJSONArrayOrNull("data");
                        if (array != null) {
                            Gson gson = new Gson();
                            List<CommentsItemInfo> datas = gson.fromJson(array.toString(),
                                    new TypeToken<List<CommentsItemInfo>>() {
                                    }.getType());
                            if (datas != null && datas.size() > 0 && current_page > 0) {
                                if (datas.size() < page_size) {
                                    xlistview_detail.setPullLoadEnable(false);
                                } else {
                                    xlistview_detail.setPullLoadEnable(true);
                                }
                                adatper.addData(datas);
                                current_page++;
                            } else if (datas != null && datas.size() > 0 && current_page == 0) {
                                if (datas.size() < page_size) {
                                    xlistview_detail.setPullLoadEnable(false);
                                } else {
                                    xlistview_detail.setPullLoadEnable(true);
                                }
                                adatper.setData(datas);
                                current_page++;
                            } else if (datas != null && datas.size() <= 0) {
                                xlistview_detail.setPullLoadEnable(false);
                            }
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_comment_get_comment_list + "?offset=" + current_page + "&limit="
                + page_size + "&order=desc");
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    @Override
    public void onRefresh() {
    }

    @Override
    public void onLoadMore() {
        getComments();
    }

    @Override
    public void onXListViewStop() {
        xlistview_detail.stopLoadMore();
        xlistview_detail.stopRefresh();
    }

    private void favorOn() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("reader_response_id", reader_response_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                onXListViewStop();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        JSONObjectProxy obj = jSONObjectProxy.getJSONObjectOrNull("data");
                        if (obj == null) {
                            Toast.makeText(getCurrentActivity(), "已经点赞了哦", Toast.LENGTH_SHORT).show();
                        } else {
                            is_refresh = true;
                            is_favored = true;
                            setFavorImage();
                            tv_favor_total.setText(String.valueOf(Integer.valueOf(tv_favor_total.getText().toString()) + 1));
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_favor_on);
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    private void favorUnOn() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("reader_response_id", reader_response_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                onXListViewStop();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        JSONObjectProxy obj = jSONObjectProxy.getJSONObjectOrNull("data");
                        if (obj == null) {
                            Toast.makeText(getCurrentActivity(), "已经取消点赞了哦", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_favor_un_on);
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (RESULT_OK == resultCode) {
            switch (requestCode) {
                case COMMENTBACK_RESULT_FLAG:
                    String content = data.getStringExtra("content");
                    CommentsItemInfo info = new CommentsItemInfo();
                    info.setTime_stamp(System.currentTimeMillis());
                    info.setContent(content);
                    UserInfo user_info = UserInfoDBHelper.getUser(getUser_id(), getCurrentActivity());
                    info.setGender(user_info.getGender());
                    info.setNick_name(user_info.getNick_name());
                    info.setUser_image(user_info.getImage());
                    List<CommentsItemInfo> infos = new ArrayList<CommentsItemInfo>();
                    infos.add(0, info);
                    infos.addAll(adatper.getData());
                    adatper.setData(infos);
                    tv_comment_total.setText(String.valueOf(Integer.valueOf(tv_comment_total.getText().toString()) + 1));
                    is_refresh = true;
                    break;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private boolean is_refresh = false;

    @Override
    public void finish() {
        super.finish();
        if (is_refresh) {
            is_refresh = false;
//            setResult(RESULT_OK);
        }
    }
}