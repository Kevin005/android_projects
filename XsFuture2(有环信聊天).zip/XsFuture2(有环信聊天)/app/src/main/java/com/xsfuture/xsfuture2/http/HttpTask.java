package com.xsfuture.xsfuture2.http;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Build.VERSION_CODES;
import android.os.Environment;
import android.widget.Toast;

import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.bean.CacheFileItem;
import com.xsfuture.xsfuture2.cache.ImageCache;
import com.xsfuture.xsfuture2.cache.JsonCache;
import com.xsfuture.xsfuture2.config.Configuration;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.database.CacheFileTableDBHelper;
import com.xsfuture.xsfuture2.util.Directory;
import com.xsfuture.xsfuture2.util.FileGuider;
import com.xsfuture.xsfuture2.util.FileService;
import com.xsfuture.xsfuture2.util.IOUtil;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.AbstractHttpMessage;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

public abstract class HttpTask extends AsyncTask<HttpSetting, Integer, HttpResult> implements StopController {

    public static final int attempts = Integer.parseInt(Configuration.getProperty(Configuration.ATTEMPTS));

    private ActivityHandlerInterface ahi;
    private HttpResponse res;
    private boolean connectionRetry; //
    private boolean stop;
    private boolean show_progressbar;
    private IOUtil.ProgressListener ioProgressListener;

    public HttpTask(ActivityHandlerInterface ah) {
        ahi = ah;
        connectionRetry = false;
        show_progressbar = true;
        res = null;
        stop = false;
        ioProgressListener = new IOUtil.ProgressListener() {
            public void notify(int progess, int max) {
                publishProgress(progess, max);
            }
        };
    }

    public void executes(HttpSetting httpSetting) {
        if (Build.VERSION.SDK_INT > VERSION_CODES.GINGERBREAD_MR1)
            executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, httpSetting);
        else
            execute(httpSetting);
    }

    @Override
    protected void onPreExecute() {
        showModal();
        onStart();
    }

    @Override
    protected HttpResult doInBackground(HttpSetting... params) {
        HttpSetting httpSetting = params[0];
        HttpResult httpResult = null;
        try {
            httpResult = executeHttp(httpSetting);
        } catch (Exception e) {

        }
        return httpResult;
    }

    @Override
    protected void onProgressUpdate(Integer... progress) {
        if (progress != null && progress.length == 2)
            onProgress(progress[0], progress[1]);
    }

    @SuppressLint("NewApi")
    @Override
    protected void onPostExecute(HttpResult result) {
        hideModal();
        if (ahi != null && ahi.getCurrentActivity() != null) {
            if (result != null && result.getJsonObject() != null) {
                Integer success = result.getJsonObject().getIntOrNull("success");
                if (success != null) {
                    if (success == 2001) {
                        String message = result.getJsonObject().getStringOrNull("message");
                        Toast.makeText(ahi.getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
//						ahi.go_to_login();//TODO
                    } else {
                        hideModal();
                        if (Build.VERSION.SDK_INT >= VERSION_CODES.JELLY_BEAN_MR2) {
                            if (ahi != null && !ahi.getCurrentActivity().isDestroyed()) {
                                onEnd(result);
                            }
                        } else {
                            onEnd(result);
                        }
                    }
                } else {
                    HttpError httpError = new HttpError();
                    httpError.setErrorCode(HttpError.RequestError);
                    httpError.setMessage(ahi.getCurrentActivity().getString(R.string.request_error));
                    onError(httpError);
                }
            } else {
                HttpError httpError = new HttpError();
                httpError.setErrorCode(HttpError.NONetworkError);
                httpError.setMessage("");
                onError(httpError);
            }
        }
    }

    private void showModal() {
        try {
            if (ahi != null && show_progressbar) {
                HttpState state = ahi.getHttpState();
                if (state == null) {
                    state = new HttpState(ahi.getCurrentActivity());
                    ahi.AddHttpState(state);
                }
                state.show();
            }
        } catch (Exception e) {
            if (Log.E) {
                Log.e("HttpTask showModal", e.toString());
            }
        }
    }

    private void hideModal() {
        if (ahi != null && show_progressbar) {
            HttpState state = ahi.getHttpState();
            if (state != null) {
                if (state.remove())
                    ahi.RemoveHttpState();
            }
        }
    }

    private HttpResult executeHttp(HttpSetting httpSetting) {
        initUrl(httpSetting);
        HttpResult httpResult = new HttpResult(ahi.getCurrentActivity());
        httpResult.setType(httpSetting.getType());
        if (httpSetting.getCacheMode() == ConstHttpProp.CACHE_MODE_AUTO
                || httpSetting.getCacheMode() == ConstHttpProp.CACHE_MODE_ONLY_CACHE) {
            switch (httpSetting.getType()) {
                case ConstHttpProp.TYPE_JSON:
                    JSONObjectProxy json = JsonCache.getJson(httpSetting.getMd5());
                    if (json != null) {
                        httpResult.setJsonObject(json);
                        return httpResult;
                    }
                    break;
                case ConstHttpProp.TYPE_IMAGE:
                    Bitmap bitmap = ImageCache.getBitmap(httpSetting.getMd5());
                    if (bitmap == null) {
                        httpResult.setBitmap(bitmap);
                        return httpResult;
                    }
            }
            if (httpSetting.getCacheMode() == ConstHttpProp.CACHE_MODE_AUTO) {
                File file = findCachesFileByMd5(httpSetting);
                if (file != null) {
                    if (httpSetting.getLocalFileCacheTime() != 0L
                            && CacheFileTableDBHelper.isExpired(ahi.getCurrentActivity(), file)) {
                        switch (httpSetting.getType()) {
                            case ConstHttpProp.TYPE_JSON:
                                try {
                                    FileInputStream fileinputstream = new FileInputStream(file);
                                    String content = IOUtil.readAsString(fileinputstream, "UTF-8");
                                    JSONObject jsonobject = new JSONObject(content);
                                    JSONObjectProxy jsonobjectproxy = new JSONObjectProxy(jsonobject);
                                    httpResult.setJsonObject(jsonobjectproxy);
                                    return httpResult;
                                } catch (Exception e) {
                                    if (Log.E) {
                                        Log.e("HttpTask jsonContent", e.toString());
                                    }
                                }
                                break;
                            case ConstHttpProp.TYPE_IMAGE:
                                httpResult.setLength(file.length());
                                Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(),
                                        getBitmapOpt(httpResult.getLength()));
                                httpResult.setBitmap(bitmap);
                                return httpResult;
                        }
                    }
                }
            }

        }
        for (int i = 0; i < attempts; i++) {
            switch (httpSetting.getHttp_type()) {
                case HttpSetting.HTTP_GET:
                    httpGet(httpSetting);
                    break;
                case HttpSetting.HTTP_POST:
                    httpPost(httpSetting);
                    break;
                case HttpSetting.HTTP_PUT:
                    httpPut(httpSetting);
                    break;
                case HttpSetting.HTTP_DELETE:
                    httpDelete(httpSetting);
                    break;
                default:
                    httpGet(httpSetting);

            }

            if (res != null) {
                if (httpSetting.getType() == ConstHttpProp.TYPE_JSON) {
                    jsonContent(httpSetting, httpResult);
                } else if (httpSetting.getType() == ConstHttpProp.TYPE_IMAGE) {
                    imageContent(httpSetting, httpResult);
                } else if (httpSetting.getType() == ConstHttpProp.TYPE_FILE) {
                    fileContent(httpSetting, httpResult);
                }
            }
            if (!connectionRetry)
                break;
        }
        Log.e("HTTP_BACK", httpSetting.getFunctionId()+"+++"+httpResult.getJsonObject().toString());//TODO delete
        save(httpSetting, httpResult);
        return httpResult;

    }

    private void initUrl(HttpSetting httpSetting) {
        if (httpSetting.getFunctionId() != null) {
            String url = httpSetting.getUrl() + httpSetting.getFunctionId();
            httpSetting.setUrl(url);
        }
    }

    private void save(HttpSetting httpSetting, HttpResult httpResult) {
        Directory directory = null;
        boolean flag = false;
        switch (httpSetting.getType()) {
            case ConstHttpProp.TYPE_JSON:
                if (httpResult != null && httpResult.getJsonObject() != null
                        && httpResult.getJsonObject().getIntOrNull("success") == 0) {
                    String json_md5 = httpSetting.getMd5();
                    JsonCache.putJson(json_md5, httpResult.getJsonObject());
                    if (httpSetting.getCacheMode() == ConstHttpProp.CACHE_MODE_AUTO) {
                        directory = FileService.getDirectory(ConstHttpProp.TYPE_JSON);
                        if (directory != null) {
                            String jsonFilename = (new StringBuilder(json_md5)).append(".json").toString();
                            flag = FileService.saveToSDCard(FileService.getDirectory(2), jsonFilename, httpResult
                                    .getJsonObject().toString().getBytes());
                            if (flag) {
                                CacheFileItem cachefile = new CacheFileItem(jsonFilename,
                                        httpSetting.getLocalFileCacheTime());
                                cachefile.setDirectory(directory);
                                CacheFileTableDBHelper.insertOrUpdate(ahi.getCurrentActivity(), cachefile);
                            }
                        }
                    }
                }
                break;
            case ConstHttpProp.TYPE_IMAGE:
                if (httpResult != null && httpResult.getBitmap() != null) {
                    String image_md5 = httpSetting.getMd5();
                    String imageFilename = (new StringBuilder(image_md5)).append(".image").toString();
                    ImageCache.putBitmap(image_md5, httpResult.getBitmap());
                    if (httpSetting.getCacheMode() == ConstHttpProp.CACHE_MODE_AUTO && httpResult.getInputData() != null) {
                        byte bytes[] = httpResult.getInputData();
                        flag = FileService.saveToSDCard(directory, imageFilename, bytes);
                        httpResult.setInputData(null);
                        if (flag) {
                            CacheFileItem cachefile = new CacheFileItem(imageFilename, httpSetting.getLocalFileCacheTime());
                            cachefile.setDirectory(directory);
                            CacheFileTableDBHelper.insertOrUpdate(ahi.getCurrentActivity(), cachefile);
                        }
                    }
                }
                break;
            default:
                break;
        }

    }

    /*
     * json
     */
    private void jsonContent(HttpSetting httpSetting, HttpResult httpResult) {
        try {
            BufferedReader result_buffer = new BufferedReader(new InputStreamReader(res.getEntity().getContent(),
                    "UTF-8"));
            StringBuffer localStringBuffer = new StringBuffer();
            String result;
            while (true) {
                String str4 = result_buffer.readLine();
                if (str4 != null) {
                    localStringBuffer.append(str4);

                } else {
                    result = localStringBuffer.toString().trim();
                    break;
                }
            }
            if (result.indexOf('{') >= 0) {
                String s2 = result.substring(result.indexOf('{'));
                JSONObject json = (JSONObject) new JSONTokener(s2).nextValue();
                JSONObjectProxy jsonobjectproxy = new JSONObjectProxy(json);
                httpResult.setJsonObject(jsonobjectproxy);
            }
        } catch (UnsupportedEncodingException e) {
            if (Log.E) {
                Log.e("HttpTask jsonContent", e.toString());
            }
            httpResult.setJsonObject(null);
            connectionRetry = true;
        } catch (IllegalStateException e) {
            if (Log.E) {
                Log.e("HttpTask jsonContent", e.toString());
            }
            httpResult.setJsonObject(null);
            connectionRetry = true;
        } catch (IOException e) {
            if (Log.E) {
                Log.e("HttpTask jsonContent", e.toString());
            }
            httpResult.setJsonObject(null);
            connectionRetry = true;
        } catch (JSONException e) {
            if (Log.E) {
                Log.e("HttpTask jsonContent", e.toString());
            }
            httpResult.setJsonObject(null);
            connectionRetry = true;
        }
    }

    /*
     * image
     */
    private void imageContent(HttpSetting httpSetting, HttpResult httpResult) {
        try {
            HttpEntity httpEntity = res.getEntity();
            InputStream inputStream = httpEntity.getContent();
            byte inputData[] = IOUtil.readAsBytes(inputStream, ioProgressListener);
            Bitmap bitmap = BitmapFactory.decodeByteArray(inputData, 0, inputData.length,
                    getBitmapOpt(inputData.length));
            httpResult.setInputData(inputData);
            httpResult.setBitmap(bitmap);
        } catch (Exception e) {
            if (Log.E) {
                Log.e("HttpTask imageContent", e.toString());
            }
            httpResult.setBitmap(null);
            connectionRetry = true;
        }
    }

    /*
     * file
     */
    private void fileContent(HttpSetting httpSetting, HttpResult httpResult) {
        FileGuider fileguider = httpSetting.getSavePath();
        long l = res.getEntity().getContentLength();
        fileguider.setAvailableSize(l);
        try {
            FileOutputStream fileoutputstream = FileService.openFileOutput(fileguider, ahi.getCurrentActivity());
            InputStream inputStream = httpResult.getInputStream();
            IOUtil.readAsFile(inputStream, fileoutputstream, ioProgressListener, this);
            File file = Environment.getExternalStorageDirectory();
            File file1 = new File(file, fileguider.getFileName());
            if (isStop()) {
                file1.delete();
                httpResult.setSaveFile(null);
            } else {
                httpResult.setSaveFile(file1);
            }
        } catch (Exception e) {
            if (Log.E) {
                Log.e("HttpTask fileContent", e.toString());
            }
            httpResult.setSaveFile(null);
            connectionRetry = true;
        }
    }

    /*
     * get
     */
    private void httpGet(HttpSetting httpSetting) {
        connectionRetry = false;
        HttpGet mHttpGet = new HttpGet(httpSetting.getUrl());
        setClientHttpHead(mHttpGet);
        BasicHttpParams httpParams = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(httpParams, httpSetting.getConnectTimeout());
        HttpConnectionParams.setSoTimeout(httpParams, httpSetting.getReadTimeout());
        HttpConnectionParams.setSocketBufferSize(httpParams, 8192);
        DefaultHttpClient mHttpClient = new DefaultHttpClient(httpParams);
        try {
            res = mHttpClient.execute(mHttpGet);
        } catch (ClientProtocolException e) {
            if (Log.E) {
                Log.e("HttpTask httpGet", e.toString());
            }
            connectionRetry = true;
        } catch (IOException e) {
            if (Log.E) {
                Log.e("HttpTask httpGet", e.toString());
            }
            connectionRetry = true;
        }
    }

    /*
     * post
     */
    private void httpPost(HttpSetting httpSetting) {
        connectionRetry = false;
        HttpPost mHttpPost = new HttpPost(httpSetting.getUrl());
        setClientHttpHead(mHttpPost);

        if (httpSetting.getJsonParams() != null) {
            String content = httpSetting.getJsonParams();
            HttpEntity he;
            try {
                he = new StringEntity(content, "utf-8");
                mHttpPost.setEntity(he);
            } catch (UnsupportedEncodingException e) {
                connectionRetry = true;
            }

        }

        try {

            BasicHttpParams httpParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(httpParams, httpSetting.getConnectTimeout());
            HttpConnectionParams.setSoTimeout(httpParams, httpSetting.getReadTimeout());
            DefaultHttpClient mHttpClient = new DefaultHttpClient(httpParams);
            res = mHttpClient.execute(mHttpPost);

        } catch (ClientProtocolException e) {
            if (Log.E) {
                Log.e("HttpTask httpPost", e.toString());
            }
            connectionRetry = true;
        } catch (IOException e) {
            if (Log.E) {
                Log.e("HttpTask httpPost", e.toString());
            }
            connectionRetry = true;
        }
    }

    /*
     * put
     */
    private void httpPut(HttpSetting httpSetting) {
        connectionRetry = false;
        HttpPut mHttpPut = new HttpPut(httpSetting.getUrl());
        setClientHttpHead(mHttpPut);

        if (httpSetting.getJsonParams() != null) {
            String content = httpSetting.getJsonParams();
            HttpEntity he;
            try {
                he = new StringEntity(content, "utf-8");
                mHttpPut.setEntity(he);
            } catch (UnsupportedEncodingException e) {
                connectionRetry = true;
            }

        }

        try {

            BasicHttpParams httpParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(httpParams, httpSetting.getConnectTimeout());
            HttpConnectionParams.setSoTimeout(httpParams, httpSetting.getReadTimeout());
            DefaultHttpClient mHttpClient = new DefaultHttpClient(httpParams);
            res = mHttpClient.execute(mHttpPut);

        } catch (ClientProtocolException e) {
            if (Log.E) {
                Log.e("HttpTask httpPost", e.toString());
            }
            connectionRetry = true;
        } catch (IOException e) {
            if (Log.E) {
                Log.e("HttpTask httpPost", e.toString());
            }
            connectionRetry = true;
        }
    }

    /*
     * delete
     */
    private void httpDelete(HttpSetting httpSetting) {
        connectionRetry = false;
        HttpDelete mHttpDelete = new HttpDelete(httpSetting.getUrl());
        setClientHttpHead(mHttpDelete);
        BasicHttpParams httpParams = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(httpParams, httpSetting.getConnectTimeout());
        HttpConnectionParams.setSoTimeout(httpParams, httpSetting.getReadTimeout());
        HttpConnectionParams.setSocketBufferSize(httpParams, 8192);
        DefaultHttpClient mHttpClient = new DefaultHttpClient(httpParams);
        try {
            res = mHttpClient.execute(mHttpDelete);
        } catch (ClientProtocolException e) {
            if (Log.E) {
                Log.e("HttpTask httpGet", e.toString());
            }
            connectionRetry = true;
        } catch (IOException e) {
            if (Log.E) {
                Log.e("HttpTask httpGet", e.toString());
            }
            connectionRetry = true;
        }
    }

    /*
     * 设置http头部信息
     */
    public void setClientHttpHead(AbstractHttpMessage httpMessage) {
//		String s3 = String.valueOf(DPIUtils.getWidth());
//		StringBuilder stringbuilder = (new StringBuilder(s3)).append("x");
//		String s4 = stringbuilder.append(DPIUtils.getHeight()).toString();
//		httpMessage.setHeader("screenSize", s4);
//		httpMessage.setHeader("platform", "android");
//		httpMessage.setHeader("clientVer", SystemUtil.getSoftwareVersionName(ahi.getCurrentActivity()));
//		httpMessage.setHeader("protocolVer", SystemUtil.getSoftwareVersionCode(ahi.getCurrentActivity()) + "");
//		httpMessage.setHeader("osversion", android.os.Build.VERSION.RELEASE);
//		httpMessage.setHeader("manufacturer", android.os.Build.MANUFACTURER);
//		httpMessage.setHeader("model", android.os.Build.MODEL);
//		httpMessage.setHeader("X-Device-Id", DeviceUuidTool.getDeviceId(ahi.getCurrentActivity()));
        httpMessage.setHeader("Content-Type", "application/json;charset=utf-8");
//		httpMessage.setHeader("Accept", "application/json;charset=utf-8");
//		httpMessage.setHeader("X-Patient-Id", ahi.getPatient_id());
        httpMessage.setHeader("X-AccessToken", ahi.getUser_token());
//		httpMessage.setHeader("sub_version", SystemUtil.getChannelId(ahi.getCurrentActivity()));
    }

    public BitmapFactory.Options getBitmapOpt(long length) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        if (length > ConstHttpProp.IMAGE_MAX_SIZE) {
            options.inSampleSize = 2;
        }
        return options;
    }

    private File findCachesFileByMd5(final HttpSetting httpSetting) {
        Directory directory = null;
        switch (httpSetting.getType()) {
            case ConstHttpProp.TYPE_JSON:
                directory = FileService.getDirectory(ConstHttpProp.TYPE_JSON);
                break;
            case ConstHttpProp.TYPE_IMAGE:
                directory = FileService.getDirectory(ConstHttpProp.TYPE_IMAGE);
                break;
        }
        File file;
        if (directory == null) {
            file = null;
        } else {
            File file1 = directory.getDir();
            File afile[] = file1.listFiles(new FilenameFilter() {

                @Override
                public boolean accept(File dir, String filename) {
                    String md5 = httpSetting.getMd5();
                    boolean isPointedType;
                    if (md5 == null)
                        isPointedType = false;
                    else
                        isPointedType = filename.startsWith(md5);
                    return isPointedType;
                }

            });
            if (afile != null && afile.length > 0) {
                file = afile[0];
            } else {
                file = null;
            }
        }
        return file;
    }

    @Override
    public boolean isStop() {
        return stop;
    }

    @Override
    public void stop() {
        stop = true;
    }

    public boolean isShow_progressbar() {
        return show_progressbar;
    }

    public void setShow_progressbar(boolean show_progressbar) {
        this.show_progressbar = show_progressbar;
    }

    public abstract void onStart();

    public abstract void onEnd(HttpResult httpResult);

    public abstract void onError(HttpError httpError);

    public abstract void onProgress(int i, int j);

}
