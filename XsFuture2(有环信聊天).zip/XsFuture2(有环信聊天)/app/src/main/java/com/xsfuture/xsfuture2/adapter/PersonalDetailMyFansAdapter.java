package com.xsfuture.xsfuture2.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.base.ActivityHandlerInterface;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.activity.main_module.PersonalDetailsActivity;
import com.xsfuture.xsfuture2.bean.UserInfo;
import com.xsfuture.xsfuture2.view.CircularImage;

import java.util.ArrayList;
import java.util.List;


public class PersonalDetailMyFansAdapter extends BaseAdapter {

    private List<UserInfo> data;
    private LayoutInflater inflater;
    private ActivityHandlerInterface context;

    public PersonalDetailMyFansAdapter(ActivityHandlerInterface c) {
        context = c;
        inflater = LayoutInflater.from(context.getCurrentActivity());
        data = new ArrayList<UserInfo>();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public UserInfo getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void setData(List<UserInfo> infos) {
        if (data == null) {
            data = new ArrayList<UserInfo>();
        } else {
            data.clear();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    public void addData(List<UserInfo> infos) {
        if (data == null) {
            data = new ArrayList<UserInfo>();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        final UserInfo item = data.get(position);
        holder = new ViewHolder();
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_personal_detail_fans, null);
            holder.user_icon = (CircularImage) convertView.findViewById(R.id.user_icon);
            holder.name = (TextView) convertView.findViewById(R.id.name);
            holder.line_people = (LinearLayout) convertView.findViewById(R.id.line_people);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        Glide.with(context.getCurrentActivity())
                .load(item.getImage())
                .placeholder(R.drawable.avatar)
                .error(R.drawable.avatar)
                .skipMemoryCache(false )//跳过内存缓存
                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                .into(holder.user_icon);

        holder.name.setText(item.getNick_name());
        holder.line_people.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context.getCurrentActivity(), PersonalDetailsActivity.class);
                intent.putExtra("user_id", item.getUser_id());
                intent.putExtra("user_name", item.getUser_name());
                intent.putExtra("nick_name", item.getNick_name());
                intent.putExtra("user_image", item.getImage());
                context.getCurrentActivity().startActivity(intent);
            }
        });
        return convertView;
    }

    public class ViewHolder {
        public CircularImage user_icon;
        public TextView name;
        public LinearLayout line_people;
    }
}
