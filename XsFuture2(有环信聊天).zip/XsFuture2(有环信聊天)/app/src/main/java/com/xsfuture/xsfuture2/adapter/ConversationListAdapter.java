package com.xsfuture.xsfuture2.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.bean.ConversationItemInfo;

import java.util.ArrayList;
import java.util.List;

public class ConversationListAdapter extends BaseAdapter {

    private List<ConversationItemInfo> data;
    private LayoutInflater inflater;
    private Activity context;

    public ConversationListAdapter(Activity c) {
        context = c;
        inflater = LayoutInflater.from(context);
        data = new ArrayList<ConversationItemInfo>();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public ConversationItemInfo getItem(int position) {
        return data.get(position - 1);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void setData(List<ConversationItemInfo> infos) {
        if (data == null) {
            data = new ArrayList<ConversationItemInfo>();
        } else {
            data.clear();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    public void addData(List<ConversationItemInfo> infos) {
        if (data == null) {
            data = new ArrayList<ConversationItemInfo>();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        final ConversationItemInfo cvInfo = data.get(position);
        holder = new ViewHolder();
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_fragment_conversation_list, null);
            holder.imgToAvatarUrl = (ImageView) convertView.findViewById(R.id.img_to_avatar_url);
            holder.tvToUserName = (TextView) convertView.findViewById(R.id.tv_to_user_name);
            holder.tvLastMsg = (TextView) convertView.findViewById(R.id.tv_last_msg);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.tvToUserName.setText(cvInfo.getTo_user_name());
        holder.tvLastMsg.setText(cvInfo.getEm_conversation_last_msg());
        Glide.with(context)
                .load(cvInfo.getTo_user_avatar_url())
                .placeholder(R.drawable.book_def)
                .error(R.drawable.book_def)
                .skipMemoryCache(false)//跳过内存缓存
                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                .into(holder.imgToAvatarUrl);
        return convertView;
    }

    public class ViewHolder {
        public ImageView imgToAvatarUrl;
        public TextView tvToUserName;
        public TextView tvLastMsg;
    }
}
