package com.xsfuture.xsfuture2.activity.me_module;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.StringUtils;

import org.json.JSONException;

/**
 * Created by Kevin on 2016/12/26.
 */

public class FeedBackActivity extends BaseActivity {
    private EditText edt_content;
    private EditText edt_email;
    private Button btn_send;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.activity_feed_back);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleText("意见反馈");
        setTitleLeftBtn(R.string.back, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initView();
    }

    protected void initView() {
        btn_send = (Button) findViewById(R.id.btn_send);
        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check()) {
                    feedback();
                }
            }
        });
        edt_content = (EditText) findViewById(R.id.edt_content);
        edt_email = (EditText) findViewById(R.id.edt_email);
    }

    private boolean check() {
        if (StringUtils.isEmpty(edt_content.getText().toString())) {
            showShortToast("请先填写意见反馈");
            return false;
        }
        return true;
    }

    public void feedback() {
        JSONObjectProxy obj = new JSONObjectProxy();
        try {
            obj.put("email", StringUtils.isEmpty(edt_email.getText().toString()) ? "" : edt_email.getText().toString());
            obj.put("content", edt_content.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONObjectProxy data = jSONObjectProxy.getJSONObjectOrNull("data");
                    if (success == 0) {
                        showShortToast("我们会尽快处理您的反馈");
                        finish();
                    }
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        showShortToast(R.string.request_error);
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setJsonParams(obj.toString());
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_feedback);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpSetting.setHttp_type(HttpSetting.HTTP_POST);
        httpTask.executes(httpSetting);
    }
}
