package com.xsfuture.xsfuture2.util;

import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JSONObjectProxy extends JSONObject {
	private JSONObject jsonObject;

	public JSONObjectProxy() {
		JSONObject localJSONObject = new JSONObject();
		this.jsonObject = localJSONObject;
	}

	public JSONObjectProxy(JSONObject paramJSONObject) {
		this.jsonObject = paramJSONObject;
	}

	public JSONObject accumulate(String paramString, Object paramObject)
			throws JSONException {
		return this.jsonObject.accumulate(paramString, paramObject);
	}

	public boolean equals(Object paramObject) {
		return this.jsonObject.equals(paramObject);
	}

	public Object get(String paramString) throws JSONException {
		return this.jsonObject.get(paramString);
	}

	public boolean getBoolean(String paramString) throws JSONException {
		return this.jsonObject.getBoolean(paramString);
	}

	public String getString(String paramString) throws JSONException {
		return this.jsonObject.getString(paramString);
	}

	public double getDouble(String paramString) throws JSONException {
		return this.jsonObject.getDouble(paramString);
	}

	public int getInt(String paramString) throws JSONException {
		return this.jsonObject.getInt(paramString);
	}

	public long getLong(String paramString) throws JSONException {
		return this.jsonObject.getLong(paramString);
	}

	public JSONArrayPoxy getJSONArray(String paramString) throws JSONException {
		JSONArray localJSONArray = this.jsonObject.getJSONArray(paramString);
		return new JSONArrayPoxy(localJSONArray);
	}

	public JSONObjectProxy getJSONObject(String paramString)
			throws JSONException {
		JSONObject localJSONObject = this.jsonObject.getJSONObject(paramString);
		return new JSONObjectProxy(localJSONObject);
	}

	public Boolean getBooleanOrNull(String paramString) {
		Boolean b = false;
		try {
			b = this.jsonObject.getBoolean(paramString);
		} catch (JSONException localJSONException) {
			b = false;
		}
		return b;
	}

	public Integer getIntOrNull(String paramString) {
		Integer c = null;
		try {
			c = this.jsonObject.getInt(paramString);
		} catch (JSONException localJSONException) {
			c = null;
		}
		return c;
	}

	public Long getLongOrNull(String paramString) {
		Long l = null;
		try {
			l = this.jsonObject.getLong(paramString);
		} catch (JSONException localJSONException) {
			l = null;
		}
		return l;
	}

	public String getStringOrNull(String key) {
		String str = null;
		try {
			if(jsonObject.isNull(key))
				return null;
			else
				str = this.jsonObject.getString(key);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			str = null;
		}
		return str;
	}

	public Double getDoubleOrNull(String paramString) {
		Double d = null;
		try {
			d = jsonObject.getDouble(paramString);
		} catch (JSONException localJSONException) {
			d = null;
		}
		return d;
	}

	public JSONArrayPoxy getJSONArrayOrNull(String paramString) {
		JSONArrayPoxy localJSONArrayPoxy;
		try {
			JSONArray localJSONArray = this.jsonObject
					.getJSONArray(paramString);
			localJSONArrayPoxy = new JSONArrayPoxy(localJSONArray);
			return localJSONArrayPoxy;
		} catch (JSONException localJSONException) {
			localJSONArrayPoxy = null;
		}
		return localJSONArrayPoxy;
	}

	public JSONObjectProxy getJSONObjectOrNull(String paramString) {
		JSONObjectProxy localJSONObjectProxy;
		try {
			JSONObject localJSONObject = this.jsonObject
					.getJSONObject(paramString);
			localJSONObjectProxy = new JSONObjectProxy(localJSONObject);
			return localJSONObjectProxy;
		} catch (JSONException localJSONException) {
			localJSONObjectProxy = null;
		}
		return localJSONObjectProxy;
	}

	public boolean has(String paramString) {
		return jsonObject.has(paramString);
	}

	public int hashCode() {
		return jsonObject.hashCode();
	}

	public boolean isNull(String paramString) {
		return jsonObject.isNull(paramString);
	}

	public Iterator<String> keys() {
		return jsonObject.keys();
	}

	public int length() {
		return this.jsonObject.length();
	}

	public JSONArray names() {
		return jsonObject.names();
	}

	public Object opt(String paramString) {
		return jsonObject.opt(paramString);
	}

	public boolean optBoolean(String paramString) {
		return jsonObject.optBoolean(paramString);
	}

	public boolean optBoolean(String paramString, boolean paramBoolean) {
		return jsonObject.optBoolean(paramString, paramBoolean);
	}

	public double optDouble(String paramString) {
		return jsonObject.optDouble(paramString);
	}

	public double optDouble(String paramString, double paramDouble) {
		return jsonObject.optDouble(paramString, paramDouble);
	}

	public int optInt(String paramString) {
		return jsonObject.optInt(paramString);
	}

	public int optInt(String paramString, int paramInt) {
		return jsonObject.optInt(paramString, paramInt);
	}

	public JSONArray optJSONArray(String paramString) {
		return jsonObject.optJSONArray(paramString);
	}

	public JSONObject optJSONObject(String paramString) {
		return jsonObject.optJSONObject(paramString);
	}

	public long optLong(String paramString) {
		return jsonObject.optLong(paramString);
	}

	public long optLong(String paramString, long paramLong) {
		return jsonObject.optLong(paramString, paramLong);
	}

	public String optString(String paramString) {
		return jsonObject.optString(paramString);
	}

	public String optString(String paramString1, String paramString2) {
		return jsonObject.optString(paramString1, paramString2);
	}

	public JSONObject put(String paramString, double paramDouble)
			throws JSONException {
		return jsonObject.put(paramString, paramDouble);
	}

	public JSONObject put(String paramString, int paramInt)
			throws JSONException {
		return jsonObject.put(paramString, paramInt);
	}

	public JSONObject put(String paramString, long paramLong)
			throws JSONException {
		return jsonObject.put(paramString, paramLong);
	}

	public JSONObject put(String paramString, Object paramObject)
			throws JSONException {
		return jsonObject.put(paramString, paramObject);
	}

	public JSONObject put(String paramString, boolean paramBoolean)
			throws JSONException {
		return jsonObject.put(paramString, paramBoolean);
	}

	public JSONObject putOpt(String paramString, Object paramObject)
			throws JSONException {
		return jsonObject.putOpt(paramString, paramObject);
	}

	public Object remove(String paramString) {
		return jsonObject.remove(paramString);
	}

	public JSONArray toJSONArray(JSONArray paramJSONArray) throws JSONException {
		return jsonObject.toJSONArray(paramJSONArray);
	}

	public String toString() {
		return jsonObject.toString();
	}

	public String toString(int paramInt) throws JSONException {
		return jsonObject.toString(paramInt);
	}
}
