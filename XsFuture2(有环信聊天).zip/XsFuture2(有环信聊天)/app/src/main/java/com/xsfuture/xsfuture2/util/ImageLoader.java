package com.xsfuture.xsfuture2.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.xsfuture.xsfuture2.bean.ImageInfo;
import com.xsfuture.xsfuture2.cache.ImageCache;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

public class ImageLoader {

    private static ConcurrentHashMap<String, ArrayList<ImageView>> imageViewsMap;
    private static ConcurrentHashMap<String, String> sDownloadingSet;
    public static final int success = 1;
    public static final int fail = 2;

    static {
        sDownloadingSet = new ConcurrentHashMap<String, String>();
        imageViewsMap = new ConcurrentHashMap<String, ArrayList<ImageView>>();
    }

    private Context context;
    private boolean isCompress;

    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {

            switch (msg.what) {
                case success: {
                    ImageInfo image = (ImageInfo) msg.obj;
                    if (image != null) {
                        String new_url = image.getUrl();
                        if (!isCompress) {
                            if (!new_url.contains("big")) {
                                new_url = image.getUrl().substring(0, image.getUrl().lastIndexOf("/")) + "/big" + image.getUrl().substring(image.getUrl().lastIndexOf("/") + 1);
                            }
                        }
                        sDownloadingSet.remove(new_url);
                        ArrayList<ImageView> imageViews = imageViewsMap.get(new_url);
                        if (imageViews != null && imageViews.size() > 0) {
                            for (ImageView imageView : imageViews) {
                                if (new_url.equals(imageView.getTag())) {// view与url匹配,防止图片显示错乱
                                    Bitmap bitmap = ImageCache.getBitmap(new_url);
                                    if (bitmap != null) {
                                        if (image.getSpecify() > 0) {// 指定宽高
                                            setImageView(imageView, image.getWidth(), image.getHeight(), bitmap);
                                        } else {
                                            setImageView(imageView, bitmap);
                                        }

                                    } else {
                                        // 本地读取
                                        try {
                                            bitmap = FileService.getImage(isCompress, image, context);
                                            if (bitmap != null) {
                                                ImageCache.putBitmap(new_url, bitmap);

                                                if (image.getSpecify() > 0) {
                                                    setImageView(imageView, image.getWidth(), image.getHeight(), bitmap);
                                                } else {
                                                    setImageView(imageView, bitmap);
                                                }
                                                return;
                                            }
                                        } catch (Exception e) {
                                            // TODO Auto-generated catch block
                                            if (Log.E)
                                                Log.e("ImageLoader Handler", e.toString());
                                        }
                                    }
                                }
                            }
                        }
                        imageViewsMap.remove(new_url);
                    }
                    break;
                }
                case fail: {
                    ImageInfo image = (ImageInfo) msg.obj;
                    if (image != null && image.getUrl() != null) {
                        sDownloadingSet.remove(image.getUrl());
                        imageViewsMap.remove(image.getUrl());
                    }
                    break;
                }
                default:
                    break;
            }
        }

        ;
    };

    public ImageLoader(Context context) {
        this.context = context;
        isCompress = true;
    }

    public ImageLoader(Context context, boolean isCompress) {
        this.isCompress = isCompress;
        this.context = context;
    }

    // 图片绑定，未指定宽高
    public void displayImage(ImageView imageView, String url, String path, int resId, boolean isCompression) {

        if (imageView == null) {
            return;
        } else {
            if (path != null && (new File(path)).exists()) {// 存在本地文件，直接本地加载
                Bitmap bitmap = ImageCache.getBitmap(path);
                if (bitmap != null) {
                    setImageView(imageView, bitmap);
                } else {
                    ImageInfo image = null;
                    boolean isLocal = false;
                    if (StringUtils.isEmpty(url)) {
                        image = new ImageInfo(path);
                        isLocal = true;
                    } else {
                        image = new ImageInfo(url);
                    }
                    ImageSize imageSize = getImageViewSize(imageView, 0, 0);
                    image.setSpecify(0);
                    image.setWidth(imageSize.width);
                    image.setHeight(imageSize.height);
                    // 本地读取
                    try {
                        bitmap = FileService.getImage(image, context, isLocal);
                        if (bitmap != null) {
                            if (url != null) {
                                ImageCache.putBitmap(url, bitmap);
                                setImageView(imageView, bitmap);
                            } else {
                                ImageCache.putBitmap(path, bitmap);
                                imageView.setImageBitmap(bitmap);
                            }
                            return;
                        }
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        if (Log.E)
                            Log.e("ImageLoader displayImage", e.toString());
                    }
                }
            } else if (url != null && !url.trim().equals("")) {
                // cache 读取
                String new_url = url;
                if (!isCompression) {
                    new_url = url.substring(0, url.lastIndexOf("/")) + "/big" + url.substring(url.lastIndexOf("/") + 1);
                }
                Bitmap bitmap = ImageCache.getBitmap(new_url);
                if (bitmap != null) {
                    setImageView(imageView, bitmap);

                } else {
                    ImageInfo image = new ImageInfo(url);
                    ImageSize imageSize = getImageViewSize(imageView, 0, 0);
                    image.setSpecify(0);
                    image.setWidth(imageSize.width);
                    image.setHeight(imageSize.height);

                    // 本地读取
                    try {
                        bitmap = FileService.getImage(isCompression, image, context);
                        if (bitmap != null) {
                            ImageCache.putBitmap(new_url, bitmap);
                            setImageView(imageView, bitmap);
                            return;
                        }
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        if (Log.E)
                            Log.e("ImageLoader displayImage", e.toString());
                    }
                    if (resId > 0) {
                        imageView.setImageResource(resId);// 设置默认图片
                    }
                    imageView.setTag(new_url);
                    ArrayList<ImageView> imageViews = imageViewsMap.get(new_url);
                    if (imageViews != null) {
                        imageViews.add(imageView);
                    } else {
                        imageViews = new ArrayList<ImageView>();
                        imageViews.add(imageView);
                        imageViewsMap.put(new_url, imageViews);
                    }

                    if (sDownloadingSet.contains(new_url)) {// 当前已经再下载，防止重复下载
                        return;
                    } else {
                        sDownloadingSet.put(new_url, new_url);
                    }
                    // 跨线成调用
                    image.setUrl(url);
                    Thread t1 = new Thread(new ImageLoaderRunnable(image, mHandler, context, isCompression));
                    t1.start();
                }
            } else {
                if (resId > 0) {
                    imageView.setImageResource(resId);// 设置默认图片
                }
            }
        }
    }

    // 图片绑定，未指定宽高，显示缩略图
    public void displayImage(ImageView imageView, String url, String path, int resId) {
        displayImage(imageView, url, path, resId, true);
    }

    // 图片绑定，未指定宽高,显示原图
    public void displayImageNoCompress(ImageView imageView, String url, String path, int resId) {
        displayImage(imageView, url, path, resId, false);
    }

    // 图片绑定,指定宽高
    public void displayImage(ImageView imageView, int width, int height, String url, String path, int resId) {
        if (imageView == null) {
            return;
        } else {
            if (path != null && (new File(path)).exists()) {// 存在本地文件，直接本地加载
                Bitmap bitmap = ImageCache.getBitmap(path);
                if (bitmap != null) {
                    setImageView(imageView, width, height, bitmap);
                } else {
                    ImageInfo image = new ImageInfo(url);
                    ImageSize imageSize = getImageViewSize(imageView, 0, 0);
                    image.setSpecify(0);
                    image.setWidth(imageSize.width);
                    image.setHeight(imageSize.height);
                    // 本地读取
                    try {
                        bitmap = FileService.getImage(image, context);
                        if (bitmap != null) {
                            ImageCache.putBitmap(url, bitmap);
                            setImageView(imageView, width, height, bitmap);
                            return;
                        }
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        if (Log.E)
                            Log.e("ImageLoader displayImage", e.toString());
                    }
                }
            } else if (url != null && !url.trim().equals("")) {
                // cache 读取
                Bitmap bitmap = ImageCache.getBitmap(url);
                if (bitmap != null) {
                    setImageView(imageView, width, height, bitmap);
                } else {
                    ImageInfo image = new ImageInfo(url);
                    ImageSize imageSize = getImageViewSize(imageView, width, height);
                    image.setSpecify(1);
                    image.setWidth(imageSize.width);
                    image.setHeight(imageSize.height);
                    // 本地读取
                    try {
                        bitmap = FileService.getImage(image, context);
                        if (bitmap != null) {
                            ImageCache.putBitmap(url, bitmap);
                            setImageView(imageView, width, height, bitmap);
                            return;
                        }
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        if (Log.E)
                            Log.e("ImageLoader displayImage", e.toString());
                    }
                    if (resId > 0) {
                        imageView.setImageResource(resId);// 设置默认图片
                    }
                    imageView.setTag(url);
                    ArrayList<ImageView> imageViews = imageViewsMap.get(url);
                    if (imageViews != null) {
                        imageViews.add(imageView);
                    } else {
                        imageViews = new ArrayList<ImageView>();
                        imageViews.add(imageView);
                        imageViewsMap.put(url, imageViews);
                    }

                    if (sDownloadingSet.contains(url)) {// 当前已经再下载，防止重复下载
                        return;
                    } else {
                        sDownloadingSet.put(url, url);
                    }
                    // 跨线成调用
                    Thread t1 = new Thread(new ImageLoaderRunnable(image, mHandler, context));
                    t1.start();
                }
            } else {
                if (resId > 0) {
                    imageView.setImageResource(resId);// 设置默认图片
                }
            }
        }
    }

    private class ImageSize {
        int width;
        int height;
    }

    /**
     * 根据ImageView获得适当的压缩的宽和高
     *
     * @param imageView
     * @return
     */
    private ImageSize getImageViewSize(ImageView imageView, int pwidth, int pheight) {
        ImageSize imageSize = new ImageSize();
        final DisplayMetrics displayMetrics = imageView.getContext().getResources().getDisplayMetrics();

        if (pwidth > 0 && pheight > 0) {
            imageSize.width = pwidth;
            imageSize.height = pheight;
            return imageSize;
        } else if (pwidth > 0) {
            imageSize.width = pwidth;
            imageSize.height = 0;// 高度自适应
            return imageSize;
        } else if (pheight > 0) {
            imageSize.width = 0;// 宽度自适应
            imageSize.height = pheight;
            return imageSize;
        } else {
            int width = imageView.getLayoutParams().width == ViewGroup.LayoutParams.WRAP_CONTENT ? 0 : imageView
                    .getWidth();
            if (width <= 0)
                width = imageView.getLayoutParams().width; // Get layout width
            // parameter
            if (width <= 0)
                width = getImageViewFieldValue(imageView, "mMaxWidth"); // Check
            // maxWidth
            // parameter
            if (width <= 0)
                width = displayMetrics.widthPixels;
            int height = imageView.getLayoutParams().height == ViewGroup.LayoutParams.WRAP_CONTENT ? 0 : imageView
                    .getHeight();

            if (height <= 0)
                height = imageView.getLayoutParams().height; // Get layout
            // height
            // parameter
            if (height <= 0)
                height = getImageViewFieldValue(imageView, "mMaxHeight"); // Check
            // maxHeight
            // parameter
            if (height <= 0)
                height = displayMetrics.heightPixels;
            imageSize.width = width;
            imageSize.height = height;
            return imageSize;
        }
    }

    /**
     * 反射获得ImageView设置的最大宽度和高度
     *
     * @param object
     * @param fieldName
     * @return
     */
    private static int getImageViewFieldValue(Object object, String fieldName) {
        int value = 0;
        try {
            Field field = ImageView.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            int fieldValue = (Integer) field.get(object);
            if (fieldValue > 0 && fieldValue < Integer.MAX_VALUE) {
                value = fieldValue;
            }
        } catch (Exception e) {
        }
        return value;
    }

    // 未设定宽高时，动态的设定ImageView的宽度和高度,保持图片的宽高比例，防止图片失真
    private void setImageView(ImageView imageView, Bitmap bitmap) {
        if (bitmap != null) {

            int width = imageView.getLayoutParams().width == ViewGroup.LayoutParams.WRAP_CONTENT ? 0 : imageView
                    .getWidth();
            int height = imageView.getLayoutParams().height == ViewGroup.LayoutParams.WRAP_CONTENT ? 0 : imageView
                    .getHeight();
            int max_width = getImageViewFieldValue(imageView, "mMaxWidth");
            int max_height = getImageViewFieldValue(imageView, "mMaxHeight");

            if (width > 0 && height > 0) {// 定高定宽，直接缩放
                imageView.setImageBitmap(bitmap);
            } else if (width > 0) {// 宽度固定
                int resize_height = (int) (width * bitmap.getHeight() * 1.0 / bitmap.getWidth());
                if (max_height > 0 && resize_height > max_height) {// 此时按照最大高度缩放
                    int resize_width = (int) (max_height * bitmap.getWidth() * 1.0 / bitmap.getHeight());
                    imageView.getLayoutParams().width = resize_width;
                    imageView.getLayoutParams().height = max_height;
                } else {
                    imageView.getLayoutParams().width = width;
                    imageView.getLayoutParams().height = resize_height;
                }
            } else if (height > 0) {// 高度固定
                int resize_width = (int) (height * bitmap.getWidth() * 1.0 / bitmap.getHeight());
                if (max_width > 0 && resize_width > max_width) {// 此时按照最大宽度缩放
                    int resize_height = (int) (max_width * bitmap.getHeight() * 1.0 / bitmap.getWidth());
                    imageView.getLayoutParams().width = max_width;
                    imageView.getLayoutParams().height = resize_height;
                } else {
                    imageView.getLayoutParams().width = resize_width;
                    imageView.getLayoutParams().height = height;
                }
            } else {
                imageView.setImageBitmap(bitmap);
            }

        }
    }

    // 指定宽高,以指定的宽高未依据，忽略样式中设定的宽高
    private void setImageView(ImageView imageView, int specified_widht, int specified_height, Bitmap bitmap) {
        if (bitmap != null) {
            if (specified_widht > 0 && specified_height > 0) {
                imageView.getLayoutParams().width = specified_widht;
                imageView.getLayoutParams().height = specified_height;
                imageView.setImageBitmap(bitmap);
            } else if (specified_widht > 0) {// 指定宽度，为指定高度
                int resize_height = (int) (specified_widht * bitmap.getHeight() * 1.0 / bitmap.getWidth());
                imageView.getLayoutParams().width = specified_widht;
                imageView.getLayoutParams().height = resize_height;
                imageView.setImageBitmap(bitmap);
            } else if (specified_height > 0) {// 指定高度，未指定宽度
                int resize_width = (int) (specified_height * bitmap.getWidth() * 1.0 / bitmap.getHeight());
                imageView.getLayoutParams().width = resize_width;
                imageView.getLayoutParams().height = specified_height;
            } else {
                imageView.setImageBitmap(bitmap);
            }
        }
    }
}
