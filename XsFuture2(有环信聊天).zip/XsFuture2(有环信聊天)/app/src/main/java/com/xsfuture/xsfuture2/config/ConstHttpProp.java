package com.xsfuture.xsfuture2.config;

public class ConstHttpProp {
    //release
    public static final String base_url = "http://115.28.56.168:8000/";
    public static final String img_base_url = "http://115.28.56.168:8000";
//    debug
//    public static final String base_url = "http://115.28.56.168:8888/";
//    public static final String img_base_url = "http://115.28.56.168:8888";

    public static final String douban_api_url = "https://api.douban.com/v2/";//豆瓣图书api
    public static final int TYPE_FILE = 500;
    public static final int TYPE_IMAGE = 5000;
    public static final int TYPE_JSON = 1000;

    public static final long IMAGE_MAX_SIZE = 0x10000L; //

    public static final int CACHE_MODE_AUTO = 0; // cache + file
    public static final int CACHE_MODE_ONLY_CACHE = 1;// cache
    public static final int CACHE_MODE_NO = 2; // no

    public static final int INTERNAL_TYPE_FILE = 1;
    public static final int INTERNAL_TYPE_CACHE = 2;

    public static final int STORAGE_UNKNOWN = -1;
    public static final int STORAGE_INTERNAL = 1;
    public static final int STORAGE_EXTERNAL = 2;
}
