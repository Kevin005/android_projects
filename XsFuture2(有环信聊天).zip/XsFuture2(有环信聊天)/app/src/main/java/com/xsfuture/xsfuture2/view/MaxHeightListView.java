package com.xsfuture.xsfuture2.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

/**
 * 占比最高屏的ListView
 */
public class MaxHeightListView extends ListView {

    public MaxHeightListView(Context context) {
        super(context);
    }

    public MaxHeightListView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MaxHeightListView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        /** int型占32位，前两位是模式AT_MOST为最多，后三十位代表组件大小  */
        int expandSpec = MeasureSpec.makeMeasureSpec(Integer.MAX_VALUE >> 2,MeasureSpec.AT_MOST);
        super.onMeasure(widthMeasureSpec, expandSpec);
    }

}
