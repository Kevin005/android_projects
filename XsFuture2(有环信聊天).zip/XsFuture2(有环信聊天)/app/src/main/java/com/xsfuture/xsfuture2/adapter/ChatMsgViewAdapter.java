package com.xsfuture.xsfuture2.adapter;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.bean.ChatMsgInfo;

import java.util.ArrayList;
import java.util.List;

public class ChatMsgViewAdapter extends BaseAdapter {
    private final String TAG = ChatMsgViewAdapter.class.getName();
    private List<ChatMsgInfo> data;
    private Context context;

    public interface IMsgViewType {
        int IMVT_COM_MSG = 0;
        int IMVT_TO_MSG = 1;
    }

    private LayoutInflater mInflater;
    private MediaPlayer mMediaPlayer = new MediaPlayer();

    public ChatMsgViewAdapter(Context context) {
        this.context = context;
        mInflater = LayoutInflater.from(context);
    }

    public int getCount() {
        if (data != null && data.size() > 0) {
            return data.size();
        }
        return 0;
    }

    public Object getItem(int position) {
        return data.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public int getItemViewType(int position) {
        ChatMsgInfo entity = data.get(position);
        if (entity.getMsgType()) {
            return IMsgViewType.IMVT_COM_MSG;
        } else {
            return IMsgViewType.IMVT_TO_MSG;
        }
    }

    public void setData(List<ChatMsgInfo> infos) {
        if (data == null) {
            data = new ArrayList<ChatMsgInfo>();
        } else {
            data.clear();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    public void addData(List<ChatMsgInfo> infos) {
        if (data == null) {
            data = new ArrayList<ChatMsgInfo>();
        }
        data.addAll(infos);
        notifyDataSetChanged();
    }

    public void addData(ChatMsgInfo info) {
        if (data == null) {
            data = new ArrayList<ChatMsgInfo>();
        }
        data.add(info);
        notifyDataSetChanged();
    }

    public int getViewTypeCount() {
        return 2;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        final ChatMsgInfo entity = data.get(position);
        boolean isComMsg = entity.getMsgType();
        ViewHolder viewHolder = null;
        if (convertView == null) {
            if (isComMsg) {
                convertView = mInflater.inflate(R.layout.item_chatting_msg_text_left, null);
            } else {
                convertView = mInflater.inflate(R.layout.item_chatting_msg_text_right, null);
            }
            viewHolder = new ViewHolder();
            viewHolder.tvSendTime = (TextView) convertView.findViewById(R.id.tv_sendtime);
            viewHolder.tvUserName = (TextView) convertView.findViewById(R.id.tv_username);
            viewHolder.tvContent = (TextView) convertView.findViewById(R.id.tv_chatcontent);
            viewHolder.tvTime = (TextView) convertView.findViewById(R.id.tv_time);
            viewHolder.isComMsg = isComMsg;
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.tvSendTime.setText(entity.getDate());
        if (entity.getText().contains(".amr")) {
            viewHolder.tvContent.setText("");
            viewHolder.tvContent.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.chatto_voice_playing, 0);
            viewHolder.tvTime.setText(entity.getTime());
        } else {
            viewHolder.tvContent.setText(entity.getText());
            viewHolder.tvContent.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
            viewHolder.tvTime.setText("");
        }
        viewHolder.tvContent.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (entity.getText().contains(".amr")) {
                    playMusic(android.os.Environment.getExternalStorageDirectory() + "/" + entity.getText());
                }
            }
        });
        viewHolder.tvUserName.setText(entity.getName());
        return convertView;
    }

    static class ViewHolder {
        public TextView tvSendTime;
        public TextView tvUserName;
        public TextView tvContent;
        public TextView tvTime;
        public boolean isComMsg = true;
    }

    /**
     * @param name
     * @Description
     */
    private void playMusic(String name) {
        try {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.stop();
            }
            mMediaPlayer.reset();
            mMediaPlayer.setDataSource(name);
            mMediaPlayer.prepare();
            mMediaPlayer.start();
            mMediaPlayer.setOnCompletionListener(new OnCompletionListener() {
                public void onCompletion(MediaPlayer mp) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
