package com.xsfuture.xsfuture2.bean;

public class MyReaderResponseDetails {
    private int reader_response_id;
    private int user_id;
    private boolean is_signed;//是否已经打卡
    private String content;
    private String push_time;
    private int readed_page_number;// 已经读过的页数
    private int favor;// 点赞数
    private int post_id;
    private String book_name;
    private String book_image;
    private String author;
    private double progress;
    private int readed_days;
    private int time_stamp;
    private String page_total;
    private int rr_favor_total;
    private int rr_comment_total;
    private boolean is_favored;
    private int info_type;// *特殊标识*标识数据源item类型

    public boolean is_favored() {
        return is_favored;
    }

    public void setIs_favored(boolean is_favored) {
        this.is_favored = is_favored;
    }
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
    public int getRr_favor_total() {
        return rr_favor_total;
    }

    public void setRr_favor_total(int rr_favor_total) {
        this.rr_favor_total = rr_favor_total;
    }

    public int getRr_comment_total() {
        return rr_comment_total;
    }

    public void setRr_comment_total(int rr_comment_total) {
        this.rr_comment_total = rr_comment_total;
    }

    public String getBook_image() {
        return book_image;
    }

    public void setBook_image(String book_image) {
        this.book_image = book_image;
    }

    public boolean is_signed() {
        return is_signed;
    }

    public void setIs_signed(boolean is_signed) {
        this.is_signed = is_signed;
    }

    public int getReaded_days() {
        return readed_days;
    }

    public void setReaded_days(int readed_days) {
        this.readed_days = readed_days;
    }

    public int getTime_stamp() {
        return time_stamp;
    }

    public void setTime_stamp(int time_stamp) {
        this.time_stamp = time_stamp;
    }

    public String getPage_total() {
        return page_total;
    }

    public void setPage_total(String page_total) {
        this.page_total = page_total;
    }


    public int getFavor() {
        return favor;
    }

    public void setFavor(int favor) {
        this.favor = favor;
    }

    public int getReader_response_id() {
        return reader_response_id;
    }

    public void setReader_response_id(int reader_response_id) {
        this.reader_response_id = reader_response_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPush_time() {
        return push_time;
    }

    public void setPush_time(String push_time) {
        this.push_time = push_time;
    }

    public int getReaded_page_number() {
        return readed_page_number;
    }

    public void setReaded_page_number(int readed_page_number) {
        this.readed_page_number = readed_page_number;
    }

    public int getPost_id() {
        return post_id;
    }

    public void setPost_id(int post_id) {
        this.post_id = post_id;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public double getProgress() {
        return progress;
    }

    public void setProgress(double progress) {
        this.progress = progress;
    }

    public int getInfo_type() {
        return info_type;
    }

    public void setInfo_type(int info_type) {
        this.info_type = info_type;
    }


}
