package com.xsfuture.xsfuture2.util;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

import com.xsfuture.xsfuture2.config.ConstSysConfig;

public class SystemUtil {
    public static final String CHANNEL_ID = "channelId";

    public static String getNetworkTypeName(Context context) {
        TelephonyManager telephonymanager;
        String s;
        NetworkInfo anetworkinfo[];
        int i;
        ConnectivityManager connectivitymanager = (ConnectivityManager) context.getSystemService("connectivity");
        telephonymanager = (TelephonyManager) context.getSystemService("phone");
        s = null;
        anetworkinfo = connectivitymanager.getAllNetworkInfo();
        i = 0;

        for (i = 0; i < anetworkinfo.length; i++) {
            if (anetworkinfo[i].isConnected())
                if (anetworkinfo[i].getTypeName().toUpperCase().contains("MOBILE")
                        || (anetworkinfo[i].getTypeName().toUpperCase().contains("WIFI"))) {
                    s = String.valueOf(telephonymanager.getNetworkType());
                    break;
                }
        }

        if (i >= anetworkinfo.length)
            s = "UNKNOWN";
        return s;
    }

    private static PackageInfo getPackageInfo(Context context) {
        PackageInfo packageinfo;
        PackageManager packagemanager = context.getPackageManager();
        String s = context.getPackageName();
        try {
            packageinfo = packagemanager.getPackageInfo(s, 0);
        } catch (NameNotFoundException e) {
            if (Log.E)
                Log.e("StatisticsReportUtil.getPackageInfo", e.toString());
            packageinfo = null;
        }
        return packageinfo;
    }

    public static int getSoftwareVersionCode(Context context) {
        PackageInfo packageinfo = getPackageInfo(context);
        int i;
        if (packageinfo == null)
            i = 0;
        else
            i = packageinfo.versionCode;
        return i;
    }

    public static String getSoftwareVersionName(Context context) {
        PackageInfo packageinfo = getPackageInfo(context);
        String s;
        if (packageinfo == null)
            s = "";
        else
            s = packageinfo.versionName;
        return s;
    }

    /**
     * 检测Sdcard是否存在
     *
     * @return
     */
    public static boolean isExitsSdcard() {
        if (android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED))
            return true;
        else
            return false;
    }

    /**
     * 检测网络是否可用
     *
     * @param context
     * @return
     */
    public static boolean isNetWorkConnected(Context context) {
        if (context != null) {
            ConnectivityManager mConnectivityManager = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo();
            if (mNetworkInfo != null) {
                return mNetworkInfo.isAvailable();
            }
        }

        return false;
    }

    // 获取渠道id，用于统计app
    public static String getChannelId(Context context) {
        ApplicationInfo appInfo;
        String channelId = "yydys";// 默认app是官网渠道
        try {
            appInfo = context.getPackageManager().getApplicationInfo(context.getPackageName(),
                    PackageManager.GET_META_DATA);
            if (null != appInfo) {
                channelId = appInfo.metaData.getString(CHANNEL_ID);
            }
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
        return channelId;
    }

    public static boolean isLogin(Context context) {
        String tokenStr = context.getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0).getString("token", "");
        if (StringUtils.isEmpty(tokenStr)) {
            return false;
        }
        return true;
    }


    public static String getChannelCode(Context context) {
        String code = getMetaData(context, "CHANNEL");
        if (code != null) {
            return code;
        }
        return "";
    }


    private static String getMetaData(Context context, String key) {
        try {
            ApplicationInfo ai = context.getPackageManager().getApplicationInfo(
                    context.getPackageName(), PackageManager.GET_META_DATA);
            Object value = ai.metaData.get(key);
            if (value != null) {
                return value.toString();
            }
        } catch (Exception e) {
            //
        }
        return null;
    }
}
