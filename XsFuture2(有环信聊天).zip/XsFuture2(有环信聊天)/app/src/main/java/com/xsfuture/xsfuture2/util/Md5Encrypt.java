package com.xsfuture.xsfuture2.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Md5Encrypt {

	private static final char DIGITS[] = {
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
		'a', 'b', 'c', 'd', 'e', 'f'
	};
	public static char[] encodeHex(byte abyte[])
	{
		int i = abyte.length;
		int j = 0;
		char ac[] = new char[i];
		while(j<i)
		{
			int i1 = (abyte[j] & 0xf0) >>> 4;
			ac[j] = DIGITS[i1];
			j++;
		}
		return ac;
	}
	
	 public static String toHexString(byte[] paramArrayOfByte)
	  {
	    StringBuilder localStringBuilder = new StringBuilder(2 * paramArrayOfByte.length);
	    int l = paramArrayOfByte.length;
	    for (int i = 0; i<l; i++)
	    {
	      localStringBuilder.append(DIGITS[((0xF0 & paramArrayOfByte[i]) >>> 4)]);
	      localStringBuilder.append(DIGITS[(0x0F & paramArrayOfByte[i])]);
	    }
	    return localStringBuilder.toString();
	  }
	 
	public static String md5(String s)
	{
		MessageDigest messagedigest;
		char ac[];
		try
		{
			messagedigest = MessageDigest.getInstance("MD5");
			messagedigest.reset();
		}
		catch (NoSuchAlgorithmException nosuchalgorithmexception)
		{
			throw new IllegalStateException("System doesn't support MD5 algorithm.");
		}
		try
		{
			byte abyte0[] = s.getBytes("utf-8");
			messagedigest.update(abyte0);
		}
		catch (UnsupportedEncodingException unsupportedencodingexception)
		{
			throw new IllegalStateException("System doesn't support your  EncodingException.");
		}
		ac = encodeHex(messagedigest.digest());
		return new String(ac);
	}
	
	public final static String getMessageDigest(byte[] buffer) {
		try {
			MessageDigest mdTemp = MessageDigest.getInstance("MD5");
			mdTemp.update(buffer);
			byte[] md = mdTemp.digest();
			int j = md.length;
			char str[] = new char[j * 2];
			int k = 0;
			for (int i = 0; i < j; i++) {
				byte byte0 = md[i];
				str[k++] = DIGITS[byte0 >>> 4 & 0xf];
				str[k++] = DIGITS[byte0 & 0xf];
			}
			return new String(str);
		} catch (Exception e) {
			return null;
		}
	}
}
