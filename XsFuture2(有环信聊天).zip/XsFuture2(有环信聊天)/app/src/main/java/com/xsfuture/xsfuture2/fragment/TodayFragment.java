package com.xsfuture.xsfuture2.fragment;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.TodayDetailsAdapter;
import com.xsfuture.xsfuture2.bean.EventBusInfo;
import com.xsfuture.xsfuture2.bean.TodayMainInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.base.FrameMainActivity;
import com.xsfuture.xsfuture2.activity.presenter.eventbus_module.CommandId;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.util.SystemUtil;
import com.xsfuture.xsfuture2.view.SwipeRefreshView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

public class TodayFragment extends BaseFragment {
    private final String TAG = TodayFragment.class.getSimpleName();
    private SwipeRefreshView sf_today_details;
    private ListView lv_today_details;
    private TodayDetailsAdapter adapter;

    private List<TodayMainInfo> today_infos;

    @Override
    protected View setCurrentContentView(LayoutInflater inflater, ViewGroup container) {
        View view = inflater.inflate(R.layout.fragment_today, container, false);
        setCurrentActivity((FrameMainActivity) getActivity());
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBusInfo info) {
        if (info.getIntentId().equals(TAG)) {
            if (info.getCommandId() == CommandId.COMMAND_ID_1) {
                if (SystemUtil.isLogin(getCurrentActivity())) {
                    loadReading(false);
                } else {
                    setNullView();
                }
            }
        }
    }

    @Override
    protected void init(View view, Bundle savedInstanceState) {
        initData();
        initView(view);
    }

    private void initData() {
        if (today_infos == null) {
            today_infos = new ArrayList<TodayMainInfo>();
        }
    }

    private void initView(View view) {
        sf_today_details = (SwipeRefreshView) view.findViewById(R.id.sf_today_details);
        sf_today_details.initTheme();
        sf_today_details.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (SystemUtil.isLogin(getCurrentActivity())) {
                    loadReading(false);
                } else {
                    sf_today_details.stopAllRoll();
                }
            }
        });
        sf_today_details.setOnLoadListener(new SwipeRefreshView.OnLoadListener() {
            @Override
            public void onLoad() {
                sf_today_details.stopAllRoll();
            }
        });
        lv_today_details = (ListView) view.findViewById(R.id.lv_today_details);
        adapter = new TodayDetailsAdapter(getCurrentActivity());
        lv_today_details.setAdapter(adapter);
        if (SystemUtil.isLogin(getCurrentActivity())) {//已登陆
            loadReading(false);
        } else {
            setNullView();
        }
    }

    private void setNullView() {
        sf_today_details.stopAllRoll();
        TodayMainInfo info1 = new TodayMainInfo();
        info1.setInfo_type(1);
        info1.setPlan_is_null(true);
        today_infos.add(info1);// 设置正在读的书view
        adapter.setData(today_infos);
    }

    private synchronized void loadReading(final boolean is_show) {
        today_infos.clear();
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                sf_today_details.stopAllRoll();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    JSONObjectProxy data = jSONObjectProxy.getJSONObjectOrNull("data");
                    if (success == 0 && data != null) {
                        JSONArrayPoxy booksPlan = data.getJSONArrayOrNull("books_plan");
                        List<TodayMainInfo> infos = new Gson().fromJson(booksPlan.toString(), new TypeToken<List<TodayMainInfo>>() {
                        }.getType());
                        if (infos != null) {
                            if (infos.size() > 0) {
                                for (TodayMainInfo readingInfo : infos) {
                                    readingInfo.setInfo_type(1);
                                    readingInfo.setPlan_is_null(false);
                                    today_infos.add(readingInfo);// 设置正在读的书view
                                }
                            } else {
                                TodayMainInfo readingInfo = new TodayMainInfo();
                                readingInfo.setInfo_type(1);
                                readingInfo.setPlan_is_null(true);
                                today_infos.add(readingInfo);// 设置正在读的书view
                            }
                            adapter.setData(today_infos);
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(HttpError httpError) {
                adapter.setData(today_infos);
                if (httpError != null) {
                    sf_today_details.stopAllRoll();
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(is_show);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.post_todayplan);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpTask.executes(httpSetting);
    }
}
