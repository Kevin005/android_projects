package com.xsfuture.xsfuture2.activity.me_module;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.xsfuture.xsfuture2.base.BaseActivity;
import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.adapter.ReaderResponseMessageAdapter;
import com.xsfuture.xsfuture2.bean.ReaderResponseMessageInfo;
import com.xsfuture.xsfuture2.config.ConstFuncId;
import com.xsfuture.xsfuture2.config.ConstHttpProp;
import com.xsfuture.xsfuture2.http.HttpError;
import com.xsfuture.xsfuture2.http.HttpResult;
import com.xsfuture.xsfuture2.http.HttpSetting;
import com.xsfuture.xsfuture2.http.HttpTask;
import com.xsfuture.xsfuture2.activity.presenter.PushTestReceiverPresenter;
import com.xsfuture.xsfuture2.util.JSONArrayPoxy;
import com.xsfuture.xsfuture2.util.JSONObjectProxy;
import com.xsfuture.xsfuture2.view.xlistview.XListView;

import java.util.List;

public class ReaderResponseMessageActivity extends BaseActivity implements XListView.IXListViewListener {
    private XListView xlv_message;
    private ReaderResponseMessageAdapter adapter;

    private int current_page = 0;
    private int page_size = 15;

    @Override
    protected void setCurrentContentView() {
        setContentView(R.layout.item_reader_response_message);
    }

    @Override
    protected void init(Bundle savedInstanceState) {
        setTitleText("读后感消息");
        setTitleLeftBtn(R.string.back, new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        PushTestReceiverPresenter.getInstance().setReadedMessage(getCurrentActivity());
        initView();
    }

    private void initView() {
        xlv_message = (XListView) findViewById(R.id.xlv_message);
        xlv_message.setPullLoadEnable(false);
        xlv_message.setPullRefreshEnable(true);
        xlv_message.setXListViewListener(this);
        adapter = new ReaderResponseMessageAdapter(getCurrentActivity());
        xlv_message.setAdapter(adapter);
        getMessageList();
    }

    private void getMessageList() {
        HttpTask httpTask = new HttpTask(getCurrentActivity()) {

            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(HttpResult httpResult) {
                onXListViewStop();
                if (httpResult != null && httpResult.getJsonObject() != null) {
                    JSONObjectProxy jSONObjectProxy = httpResult.getJsonObject();
                    int success = jSONObjectProxy.getIntOrNull("success");
                    String message = jSONObjectProxy.getStringOrNull("message");
                    if (success == 0) {
                        JSONArrayPoxy array = jSONObjectProxy.getJSONArrayOrNull("data");
                        if (array != null) {
                            Gson gson = new Gson();
                            List<ReaderResponseMessageInfo> datas = gson.fromJson(array.toString(),
                                    new TypeToken<List<ReaderResponseMessageInfo>>() {
                                    }.getType());
                            if (datas != null && datas.size() > 0 && current_page > 0) {
                                adapter.addData(datas);
                                current_page++;
                                xlv_message.setPullLoadEnable(true);
                            } else if (datas != null && datas.size() > 0 && current_page == 0) {
                                adapter.setData(datas);
                                current_page++;
                                xlv_message.setPullLoadEnable(true);
                            } else if (datas != null && datas.size() <= 0) {
                                xlv_message.setPullLoadEnable(false);
                            }
                        }
                    } else {
                        Toast.makeText(getCurrentActivity(), message, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(HttpError httpError) {
                if (httpError != null) {
                    if (httpError.getErrorCode() == HttpError.NONetworkError) {
                        Toast.makeText(getCurrentActivity(), R.string.request_error, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onProgress(int i, int j) {
            }

        };
        httpTask.setShow_progressbar(false);
        HttpSetting httpSetting = new HttpSetting();
        httpSetting.setFunctionId(ConstFuncId.xiaoshi_message_list + "?offset=" + current_page + "&limit=" + page_size);
        httpSetting.setUrl(ConstHttpProp.base_url);
        httpSetting.setHttp_type(HttpSetting.HTTP_GET);
        httpSetting.setType(ConstHttpProp.TYPE_JSON);
        httpTask.executes(httpSetting);
    }

    @Override
    public void onRefresh() {
        current_page = 0;
        getMessageList();
    }

    @Override
    public void onLoadMore() {
        getMessageList();
    }

    @Override
    public void onXListViewStop() {
        xlv_message.stopRefresh();
        xlv_message.stopLoadMore();
    }
}