package com.xsfuture.xsfuture2.base;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.xsfuture.xsfuture2.R;
import com.xsfuture.xsfuture2.config.ConstSysConfig;
import com.xsfuture.xsfuture2.http.HttpState;
import com.xsfuture.xsfuture2.util.DPIUtils;

public abstract class FrameMainActivity extends FragmentActivity implements ActivityHandlerInterface {
    protected Handler handler;
    private Fragment currentFragment;

    protected Button left_btn;
    protected Button right_btn;
    private TextView title;

    protected abstract void setCurrentContentView();

    protected abstract void init(Bundle savedInstanceState);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        initData();
        super.onCreate(savedInstanceState);
        if (DPIUtils.getDensity() == 0) {
            DPIUtils.setDensity(getResources().getDisplayMetrics().density);
        }
        if (DPIUtils.getDisplay() == null) {
            DPIUtils.setDefaultDisplay(getWindowManager().getDefaultDisplay());
        }
        setCurrentContentView();
        initTitleBar();
        init(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        XsfutureApplication.getInstance().setAhi(FrameMainActivity.this);
    }

    private void initTitleBar() {
        title = (TextView) findViewById(R.id.title_text);
        left_btn = (Button) findViewById(R.id.left_btn);
        right_btn = (Button) findViewById(R.id.right_btn);
    }

    /**
     * 设置左键文字与事件
     *
     * @param listener
     */
    public void setTitleLeftBtn(int stringId, View.OnClickListener listener) {
        // 先将该按钮设为可见
        left_btn.setVisibility(View.VISIBLE);

        if (stringId == R.string.back) {
            left_btn.setCompoundDrawables(getBtnCompoundDrawable(R.drawable.arrow_back), null, null, null);
        }
        // 设置按钮字符
        // left_btn.setText(stringId);
        // 设置点击事件
        left_btn.setOnClickListener(listener);
    }

    /**
     * 设置右键文字与事件
     *
     * @param stringId
     * @param listener
     */
    public void setTitleBtnRight(int stringId, View.OnClickListener listener) {
        // 先将该按钮设为可见
        right_btn.setVisibility(View.VISIBLE);
        // 设置按钮字符
        right_btn.setText(stringId);
        // 设置点击事件
        right_btn.setOnClickListener(listener);
    }

    public void setTitleBtnRightVisibility(int visibility) {
        right_btn.setVisibility(visibility);
    }

    /**
     * 设置右键类型与事件，用于非文字的图标按钮
     *
     * @param listener
     */
    public void setImageTitleBtnRight(int imageId, View.OnClickListener listener) {
        // 先将该按钮设为可见
        right_btn.setVisibility(View.VISIBLE);

        Drawable drawable = getResources().getDrawable(imageId);
        drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
        right_btn.setCompoundDrawables(drawable, null, null, null);

        // 设置点击事件
        right_btn.setOnClickListener(listener);
    }

    /**
     * 设置标题文字
     *
     * @param s
     */
    public void setTitleText(String s) {
        title.setText(s);
    }

    public void setTitleText(int id) {
        title.setText(id);
    }

    /**
     * 获取按钮的CompoundDrawable，以设置按钮图片
     *
     * @param id
     * @return
     */
    private Drawable getBtnCompoundDrawable(int id) {

        Drawable icon = getResources().getDrawable(id);
        icon.setBounds(0, 0, icon.getMinimumWidth(), icon.getMinimumHeight());

        return icon;
    }

    private void initData() {
        handler = new Handler();
        DPIUtils.setDensity(getResources().getDisplayMetrics().density);
        DPIUtils.setDefaultDisplay(getWindowManager().getDefaultDisplay());
    }

    @Override
    public Handler getHandler() {
        return handler;
    }

    @Override
    public FrameMainActivity getCurrentActivity() {
        return this;
    }

    @Override
    public HttpState getHttpState() {
        return BaseActivity.stateMap.get(this);
    }

    @Override
    public void AddHttpState(HttpState state) {
        BaseActivity.stateMap.put(this, state);
    }

    @Override
    public void RemoveHttpState() {
        BaseActivity.stateMap.remove(this);
    }

    public Fragment getCurrentFragment() {
        return currentFragment;
    }

    public void setCurrentFragment(Fragment currentFragment) {
        this.currentFragment = currentFragment;
    }

    @Override
    public int getUser_id() {
        return getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0).getInt("userId", 0);
    }

    @Override
    public String getUser_token() {
        return getSharedPreferences(ConstSysConfig.SYS_CUST_CLIENT, 0).getString("token", "");
    }

    public void post(Runnable action) {
        final Runnable ar = action;

        handler.post(new Runnable() {

            @Override
            public void run() {
                if (!isFinishing())
                    ar.run();
            }

        });
    }

    public void post(final Runnable action, int i) {
        long l = i;
        final Runnable ar = action;
        handler.postDelayed(new Runnable() {

            @Override
            public void run() {
                if (!isFinishing())
                    ar.run();
            }

        }, l);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            home.addCategory(Intent.CATEGORY_HOME);
            startActivity(home);
            return true;
        } else {
            return super.onKeyDown(keyCode, event);
        }
    }

}
