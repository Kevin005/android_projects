package com.xsfuture.xsfuture2.bean;

/**
 * Created by Kevin on 2017/6/7.
 */

public class ConversationItemInfo {
    private int id;
    private int my_user_id;
    private String em_id;
    private String em_conversation_last_msg;
    private String from_user_name;
    private String from_user_phone;//is my phone num
    private String from_user_avatar_url;
    private String to_user_name;
    private String to_user_phone;//is send to user phone num
    private String to_user_avatar_url;

    public String getFrom_user_phone() {
        return from_user_phone;
    }

    public void setFrom_user_phone(String from_user_phone) {
        this.from_user_phone = from_user_phone;
    }

    public String getTo_user_phone() {
        return to_user_phone;
    }

    public void setTo_user_phone(String to_user_phone) {
        this.to_user_phone = to_user_phone;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMy_user_id() {
        return my_user_id;
    }

    public void setMy_user_id(int my_user_id) {
        this.my_user_id = my_user_id;
    }

    public String getEm_id() {
        return em_id;
    }

    public void setEm_id(String em_id) {
        this.em_id = em_id;
    }

    public String getEm_conversation_last_msg() {
        return em_conversation_last_msg;
    }

    public void setEm_conversation_last_msg(String em_conversation_last_msg) {
        this.em_conversation_last_msg = em_conversation_last_msg;
    }

    public String getFrom_user_name() {
        return from_user_name;
    }

    public void setFrom_user_name(String from_user_name) {
        this.from_user_name = from_user_name;
    }

    public String getFrom_user_avatar_url() {
        return from_user_avatar_url;
    }

    public void setFrom_user_avatar_url(String from_user_avatar_url) {
        this.from_user_avatar_url = from_user_avatar_url;
    }

    public String getTo_user_name() {
        return to_user_name;
    }

    public void setTo_user_name(String to_user_name) {
        this.to_user_name = to_user_name;
    }

    public String getTo_user_avatar_url() {
        return to_user_avatar_url;
    }

    public void setTo_user_avatar_url(String to_user_avatar_url) {
        this.to_user_avatar_url = to_user_avatar_url;
    }
}
